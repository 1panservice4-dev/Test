/* Stage 6: Orthodox Chess VS Chess Tetris. Server and browser share exactly this engine.
   WHITE is always first. Host picks WHITE army, joining player uses opposite BLACK army.
   Orthodox army: FIDE movement, castling, en passant, promotion and king safety.
   Tetris army: V7.2 bounded/jumping moves, one square per piece, same king safety,
   and extra line victory (full rank outside its first 3 home ranks OR entire file).
*/
(function(root, factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;root.HybridChess=api;})(typeof globalThis!=='undefined'?globalThis:this,function(){
'use strict';
const START='rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1';
const CUSTOM={
 p:[[-1,-1],[0,-1],[1,-1],[-1,0],[1,0],[-1,1],[0,1],[1,1]],
 n:[[-1,-2],[0,-2],[1,-2],[-2,-1],[0,-1],[2,-1],[-2,0],[-1,0],[1,0],[2,0],[-2,1],[0,1],[2,1],[-1,2],[0,2],[1,2]],
 b:[[-1,-2],[1,-2],[-2,-1],[-1,-1],[0,-1],[1,-1],[2,-1],[-1,0],[1,0],[-2,1],[-1,1],[0,1],[1,1],[2,1],[-1,2],[1,2]],
 q:[[0,-2],[-1,-1],[0,-1],[1,-1],[-2,0],[-1,0],[1,0],[2,0],[-1,1],[0,1],[1,1],[0,2]],
 r:[],k:[[-1,-1],[0,-1],[1,-1],[-1,0],[1,0],[-1,1],[0,1],[1,1]]
};for(let n=1;n<=3;n++)CUSTOM.r.push([n,0],[-n,0],[0,n],[0,-n]);
const ORTHO={n:[-33,-31,-18,-14,14,18,31,33],b:[-17,-15,15,17],r:[-16,-1,1,16],q:[-17,-16,-15,-1,1,15,16,17],k:[-17,-16,-15,-1,1,15,16,17]};
const on=i=>i>=0&&i<128&&!(i&0x88);
const side=p=>!p||p==='.'?0:(p===p.toUpperCase()?1:-1);
const sq=i=>'abcdefgh'[i&7]+(8-(i>>4));
const idx=s=>{if(!/^[a-h][1-8]$/.test(s))return -1;return (8-Number(s[1]))*16+'abcdefgh'.indexOf(s[0]);};
const faction=(s,who)=>who===1?s.whiteFaction:s.blackFaction;
function initial(whiteFaction='classic',blackFaction=whiteFaction==='classic'?'tetris':'classic'){
 if(!['classic','tetris'].includes(whiteFaction)||!['classic','tetris'].includes(blackFaction))throw Error('Invalid faction');
 const b=Array(128).fill('.');START.split(' ')[0].split('/').forEach((r,y)=>{let x=0;for(const p of r){if(/[1-8]/.test(p))x+=Number(p);else b[y*16+x++]=p;}});
 return {b,t:1,c:15,ep:-1,half:0,full:1,whiteFaction,blackFaction};
}
function customDest(f,p){const x=f&7,y=f>>4;return (CUSTOM[p]||[]).flatMap(([dx,dy])=>{const xx=x+dx,yy=y+dy;return xx>=0&&xx<8&&yy>=0&&yy<8?[yy*16+xx]:[]});}
function attacks(s,f,target){const p=s.b[f],who=side(p);if(!who||!on(target))return false;const k=p.toLowerCase();
 if(faction(s,who)==='tetris')return customDest(f,k).includes(target);
 if(k==='p')return target===f-16*who-1||target===f-16*who+1;
 for(const d of ORTHO[k]||[]){for(let t=f+d;on(t);t+=d){if(t===target)return true;if(s.b[t]!=='.'||k==='n'||k==='k')break;}}
 return false;
}
function attacked(s,target,who){if(!on(target))return false;for(let f=0;f<128;f++)if(on(f)&&side(s.b[f])===who&&attacks(s,f,target))return true;return false;}
function inCheck(s,who=s.t){const k=s.b.indexOf(who===1?'K':'k');return k<0||attacked(s,k,-who);}
function apply(s,m){const [f,t,q='',flag='']=m;const b=s.b.slice(),p=b[f],captured=b[t];let c=s.c;
 b[f]='.';b[t]=q?(s.t===1?q.toUpperCase():q):p;
 if(flag==='ep')b[t+16*s.t]='.';
 if(flag==='castle'){const rf=t>f?f+3:f-4,rt=t>f?f+1:f-1;b[rt]=b[rf];b[rf]='.';}
 if(p==='K')c&=~3;if(p==='k')c&=~12;
 const bits={119:1,112:2,7:4,0:8};if(p.toLowerCase()==='r')c&=~(bits[f]||0);if(captured.toLowerCase()==='r')c&=~(bits[t]||0);
 return {b,t:-s.t,c,ep:p.toLowerCase()==='p'&&faction(s,s.t)==='classic'&&Math.abs(t-f)===32?(t+f)/2:-1,half:p.toLowerCase()==='p'||captured!=='.'||flag==='ep'?0:s.half+1,full:s.full+(s.t===-1?1:0),whiteFaction:s.whiteFaction,blackFaction:s.blackFaction};
}
function pseudo(s){const out=[];
 for(let f=0;f<128;f++){
  if(!on(f)||side(s.b[f])!==s.t)continue;
  const k=s.b[f].toLowerCase(),isTetris=faction(s,s.t)==='tetris';
  const add=(t,flag='')=>{if(!on(t)||side(s.b[t])===s.t||s.b[t].toLowerCase()==='k')return;
   if(k==='p'&&(t>>4===0||t>>4===7)){for(const q of ['q','r','b','n'])out.push([f,t,q,flag]);}
   else out.push([f,t,'',flag]);};
  if(isTetris){for(const t of customDest(f,k))add(t);}
  else if(k==='p'){
   const t=f-16*s.t;
   if(on(t)&&s.b[t]==='.'){add(t);const u=t-16*s.t;if(f>>4===(s.t===1?6:1)&&s.b[u]==='.')add(u);}
   for(const d of [-1,1]){const u=t+d;if(!on(u))continue;
    if(side(s.b[u])===-s.t)add(u);
    else if(u===s.ep&&s.b[u]==='.'&&s.b[u+16*s.t]===(s.t===1?'p':'P'))add(u,'ep');}
  }else{
   for(const d of ORTHO[k]||[])for(let t=f+d;on(t);t+=d){if(side(s.b[t])===s.t)break;add(t);if(s.b[t]!=='.'||k==='n'||k==='k')break;}
  }
  if(k==='k'){
   const home=s.t===1?116:4,rook=s.t===1?'R':'r',bits=s.t===1?[1,2]:[4,8];
   if(f===home&&!inCheck(s)){
    if((s.c&bits[0])&&s.b[f+3]===rook&&s.b[f+1]==='.'&&s.b[f+2]==='.'&&!attacked(s,f+1,-s.t)&&!attacked(s,f+2,-s.t))add(f+2,'castle');
    if((s.c&bits[1])&&s.b[f-4]===rook&&s.b[f-1]==='.'&&s.b[f-2]==='.'&&s.b[f-3]==='.'&&!attacked(s,f-1,-s.t)&&!attacked(s,f-2,-s.t))add(f-2,'castle');
   }
  }
 }
 return out;
}
const legal=s=>pseudo(s).filter(m=>!inCheck(apply(s,m),s.t));
function lineWin(s,who){if(faction(s,who)!=='tetris')return null;const owns=i=>side(s.b[i])===who;
 const rows=who===1?[0,1,2,3,4]:[3,4,5,6,7];
 for(const r of rows)if(Array.from({length:8},(_,c)=>r*16+c).every(owns))return {kind:'row',index:r};
 for(let c=0;c<8;c++)if(Array.from({length:8},(_,r)=>r*16+c).every(owns))return {kind:'column',index:c};
 return null;
}
function key(s){let z='';for(let i=0;i<128;i++)if(on(i))z+=s.b[i];return z+'|'+s.t+'|'+s.c+'|'+s.ep+'|'+s.whiteFaction+'|'+s.blackFaction;}
function insufficient(s){let n=0;for(let i=0;i<128;i++)if(on(i)&&s.b[i]!=='.'&&s.b[i].toLowerCase()!=='k')n++;return n===0;}
function outcome(s,history=[]){const won=-s.t,ln=lineWin(s,won);if(ln)return {done:true,winner:won,reason:'line',line:ln};const poss=legal(s);
 if(!poss.length){const check=inCheck(s);return {done:true,winner:check?won:0,reason:check?'checkmate':'stalemate',line:null};}
 if(insufficient(s))return {done:true,winner:0,reason:'insufficient',line:null};
 if(s.half>=150)return {done:true,winner:0,reason:'75move',line:null};
 if(history.filter(x=>x===key(s)).length>=5)return {done:true,winner:0,reason:'fivefold',line:null};
 return {done:false,winner:null,reason:'',line:null};
}
const moveKey=m=>sq(m[0])+sq(m[1])+m[2];
function parseMove(s,u){return legal(s).find(m=>moveKey(m)===u)||null;}
function notation(s,m){const p=s.b[m[0]],cap=s.b[m[1]]!=='.'||m[3]==='ep';return m[3]==='castle'?(m[1]>m[0]?'O-O':'O-O-O'):(p.toUpperCase()==='P'?'':p.toUpperCase())+sq(m[0])+(cap?'×':'–')+sq(m[1])+(m[2]?'='+m[2].toUpperCase():'');}
return {START,CUSTOM,initial,on,side,sq,idx,faction,customDest,attacked,inCheck,pseudo,legal,apply,lineWin,key,insufficient,outcome,moveKey,parseMove,notation};
});
