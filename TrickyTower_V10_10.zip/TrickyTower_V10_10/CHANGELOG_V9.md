# V9.0 — Stage 05 · Tetris Battle

- 신규 독립 서버 엔진 `battle_engine.js`, 공개방/WebSocket 서버 `battle_server.js`, 클라이언트 `battle.html` 추가.
- 10x20 물리 없는 일반 테트리스, 4색 AP, 1000HP, 5종 특수 타일, 시간별 확률, 2인 온라인 대전.
- 내/상대 보드 동일 y좌표·크기로 정렬. 60FPS 렌더링 목표 및 서버 기준 약 30Hz 전송, FPS/Hz/RTT HUD.
- 서버가 블록 충돌/착지, 색 AP, 공격, 체력, 승자 계산. 30초 재접속 유예 + 경기 일시정지.
- 기존 V8.5 stage 1/2 physics, stage 3 chess, stage 4 ability chess HTML/scripts and corresponding server protocols preserved.
- `npm test`에 신규 5스테이지 게임 규칙과 실제 2인 WebSocket 검사 추가.
