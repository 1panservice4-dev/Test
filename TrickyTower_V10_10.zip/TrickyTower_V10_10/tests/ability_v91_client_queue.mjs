import assert from 'node:assert/strict';
import vm from 'node:vm';
import fs from 'node:fs';
import path from 'node:path';
const s=fs.readFileSync(path.join(import.meta.dirname,'..','ability_transport.js'),'utf8');
const sockets=[];
class WSocket{
 static OPEN=1;static CONNECTING=0;
 constructor(){this.readyState=0;this.bufferedAmount=0;this.handlers={};this.messages=[];sockets.push(this)}
 addEventListener(ev,cb){(this.handlers[ev]??=[]).push(cb)}
 send(s){if(this.readyState!==1)throw Error('closed');this.messages.push(JSON.parse(s));this.bufferedAmount+=s.length}
 trigger(ev,data={}){if(ev==='open')this.readyState=1;for(const cb of this.handlers[ev]||[])cb(data)}
 close(){this.readyState=3;this.trigger('close')}
}
const window={};
const context=vm.createContext({WebSocket:WSocket,window,URLSearchParams,location:{search:'?room=ABC123&seat=xyz&mode=ability2&role=host',protocol:'http:',host:'localhost'},setInterval,clearInterval,setTimeout,clearTimeout,crypto:{randomUUID:()=>String(Math.random()).slice(2)},Date,console,Math});
vm.runInContext(s,context);
const peer=new window.Peer('host-ABC123'),ws=sockets[0];ws.trigger('open');
assert.equal(ws.messages[0].type,'peer_register');
ws.bufferedAmount=999999;
for(let i=0;i<50;i++)assert.equal(peer._send({type:'peer_data',channel:'c1',data:{messageType:'STATE_UPDATE',priority:'state',stateKey:'authority',version:i}}),true);
assert.equal(peer._send({type:'peer_data',channel:'c1',data:{messageType:'COMMAND',priority:'critical',packetId:'move-id',version:99}}),true);
assert.equal(peer._states.size,1);assert.equal(peer._urgent.size,1);
ws.bufferedAmount=0;peer._flushOutgoing();
assert.equal(ws.messages[1].data.packetId,'move-id');assert.equal(ws.messages[2].data.version,49);
peer.destroy();
console.log('PASS stage4 browser queue: 50 redundant states coalesced; command prioritized; socket queue cleaned on disconnect.');
