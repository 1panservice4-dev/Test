import asyncio,json,urllib.request,os,uuid,random
import websockets
BASE='http://127.0.0.1:8787';WS='ws://127.0.0.1:8787'
def api(path,obj):
 req=urllib.request.Request(BASE+path,json.dumps(obj).encode(),headers={'Content-Type':'application/json'})
 return json.load(urllib.request.urlopen(req,timeout=8))
async def recv(ws,kind=None,timeout=5):
 for i in range(30):
  m=json.loads(await asyncio.wait_for(ws.recv(),timeout))
  if kind is None or m.get('type')==kind:return m
 raise AssertionError('missing '+str(kind))
async def connect(room,seat,peerId):
 w=await websockets.connect(f'{WS}/ability-ws?room={room}&seat={seat}',max_size=2500000)
 await recv(w,'ability_ready')
 await w.send(json.dumps({'type':'peer_register','peerId':peerId}))
 await recv(w,'peer_registered')
 return w
async def main():
 for size in (2,4):
  owner=api('/api/ability/create',{'max':size,'name':f'Test {size}','variant':'brawl'})
  room=owner['roomId'];assert len(room)==6
  hostId=f'chaos-chess-v20-37-{"two" if size==2 else "four"}-{room}'
  host=await connect(room,owner['seatToken'],hostId)
  rooms=json.load(urllib.request.urlopen(BASE+'/api/ability/rooms'))['rooms']; assert any(x['id']==room for x in rooms)
  guests=[]
  for i in range(size-1):
   seat=api('/api/ability/join',{'roomId':room});assert seat['role']=='guest'
   g=await connect(room,seat['seatToken'],f'guest-test-{size}-{i}-{uuid.uuid4().hex[:6]}');guests.append(g)
  rooms=json.load(urllib.request.urlopen(BASE+'/api/ability/rooms'))['rooms'];assert not any(x['id']==room for x in rooms)
  for i,g in enumerate(guests):
   cid=f'link-{size}-{i}'
   await g.send(json.dumps({'type':'peer_dial','to':hostId,'channel':cid,'metadata':{'connectionId':cid}}))
   incoming=await recv(host,'peer_incoming'); assert incoming['channel']==cid
   await recv(g,'peer_channel_ready');await recv(host,'peer_channel_ready')
   data={'type':'stateSnapshot','seq':i,'board':'Q'*int(400000 if size==4 else 5000)}
   await host.send(json.dumps({'type':'peer_data','channel':cid,'data':data}))
   delivered=await recv(g,'peer_channel_data');assert delivered['data']==data
   await g.send(json.dumps({'type':'peer_data','channel':cid,'data':{'move':'e2e4','from':i}}))
   delivered=await recv(host,'peer_channel_data');assert delivered['data']['move']=='e2e4'
   print(f'[{size}P] peer channel',cid,'messages transmitted')
  # one forbidden late join to full room
  try:
   api('/api/ability/join',{'roomId':room})
   assert False,'overcapacity joined'
  except urllib.error.HTTPError as e:assert e.code==409
  for g in guests:await g.close()
  await host.close()
 print('TRANSPORT STRESS/PUBLIC LOBBY: PASS')
asyncio.run(main())
