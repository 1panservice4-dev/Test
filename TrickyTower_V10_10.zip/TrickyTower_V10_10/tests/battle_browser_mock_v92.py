from playwright.sync_api import sync_playwright
from pathlib import Path
html=(Path(__file__).resolve().parent.parent/'battle.html').read_text()
errors=[]
ws_stub='''Object.defineProperty(window,'sessionStorage',{configurable:true,value:{getItem:()=>null,setItem:()=>{},removeItem:()=>{}}});window._sent=[];window.WebSocket=class{static OPEN=1;constructor(url){this.url=url;this.readyState=1;queueMicrotask(()=>{if(this.onopen)this.onopen()})}send(data){window._sent.push(JSON.parse(data))}close(){this.readyState=3;if(this.onclose)this.onclose()}}'''
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
 for width,height,is_mobile in [(1440,960,False),(390,844,True)]:
  ctx=b.new_context(viewport={'width':width,'height':height},is_mobile=is_mobile,has_touch=is_mobile)
  page=ctx.new_page();page.on('pageerror',lambda e:errors.append(str(e)))
  page.evaluate('() => {'+ws_stub+'}')
  page.set_content(html,wait_until='load')
  room={'id':'abc','name':'테트리스 배틀 테스트','state':'playing','players':[{'id':'a','name':'플레이어A','ready':True,'connected':True},{'id':'b','name':'플레이어B','ready':True,'connected':True}]}
  rows=[','.join(['' for _ in range(10)]) for y in range(20)]
  def player(color,special,hp):
   return {'rows':rows,'active':{'kind':'T','tiles':[[3,1,color,special],[4,1,color,special],[5,1,color,special],[4,0,color,special]]},'next':'Z','hold':'L','hp':hp,'ap':[4,2,1,8],'lines':2,'topouts':0,'falls':1,'events':[{'id':1,'text':'BATTLE START'}],'seq':1}
  state={'type':'battle_state','roomId':'abc','startAt':0,'serverAt':13000,'state':'playing','paused':False,'seconds':13,'probability':.07,'winner':None,'reason':'','players':[player('R','heal',850),player('G','bomb',700)]}
  page.evaluate('(r) => onMessage({type:"battle_joined",room:r,seatId:"a",seatToken:"tok",position:0})',room)
  page.evaluate('(s) => onMessage(s)',state)
  page.wait_for_timeout(120)
  mine=page.locator('#myBoard').bounding_box();other=page.locator('#opBoard').bounding_box()
  assert abs(mine['y']-other['y'])<1 and abs(mine['height']-other['height'])<1 and abs(mine['width']-other['width'])<1,(mine,other)
  assert page.locator('#match').is_visible()
  page.keyboard.press('Space')
  assert page.evaluate('() => _sent.some(m => m.type==="battle_input" && m.action==="drop")')
  page.evaluate('''async s => {for(let i=0;i<30;i++){onMessage(s);await new Promise(r=>setTimeout(r,34))}}''',state)
  assert 'FPS' in page.locator('#fps').inner_text()
  assert 'Hz' in page.locator('#hz').inner_text()
  assert not errors,errors
  print('PASS browser mock',width,'aligned boards, uniform 4-tile specials, drop input, FPS',page.locator('#fps').inner_text(),'SYNC',page.locator('#hz').inner_text())
  ctx.close()
 b.close()
print('PASS Chromium desktop and mobile injected state tests, no JS page errors')
