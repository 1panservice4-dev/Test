import asyncio
from pathlib import Path
from playwright.async_api import async_playwright
ROOT=Path('/mnt/data/Chess_Tetris_V6')
async def run():
 async with async_playwright() as pw:
  browser=await pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
  page=await browser.new_page(viewport={'width':1280,'height':900},device_scale_factor=1)
  errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
  await page.set_content((ROOT/'Chess_Tetris_V6_Standalone.html').read_text(),wait_until='load')
  await page.screenshot(path=str(ROOT/'preview_v6_lobby.png'),full_page=True)
  await page.locator('#localChoice').click()
  assert await page.locator('#board button.sq').count()==64
  assert await page.locator('#movementGuide .move-card').count()==6
  await page.locator('button.sq[aria-label="e2 P"]').click()
  for sq in ['d3','e3','f3']:
   assert 'target' in await page.locator(f'button.sq[aria-label="{sq} ."]').get_attribute('class')
  assert 'target' not in await page.locator('button.sq[aria-label="e4 ."]').get_attribute('class')
  await page.screenshot(path=str(ROOT/'preview_v6_moves.png'),full_page=True)
  await page.locator('button.sq[aria-label="e3 ."]').click()
  assert '빨강 차례' in await page.locator('#turnText').inner_text()
  assert '♚' in await page.locator('button.sq[aria-label="e1 K"]').inner_html()
  assert '♚' not in await page.locator('button.sq[aria-label="d1 Q"]').inner_html()
  await page.screenshot(path=str(ROOT/'preview_v6_game.png'),full_page=True)
  await page.locator('button.sq[aria-label="e7 p"]').click()
  await page.locator('button.sq[aria-label="e6 ."]').click()
  await page.locator('button.sq[aria-label="a1 R"]').click()
  assert 'target' in await page.locator('button.sq[aria-label="a3 ."]').get_attribute('class'), 'I rook must jump over friendly a2 pawn'
  await page.screenshot(path=str(ROOT/'preview_v6_rook_jumps.png'),full_page=True)
  assert not errors,errors
  print('BROWSER MOCK DESKTOP PASS 64 squares + 6 rules preview + pawn moves + turn swap + king shape. JS errors:',errors)
  phone=await browser.new_page(viewport={'width':390,'height':844},device_scale_factor=1)
  merr=[];phone.on('pageerror',lambda e:merr.append(str(e)))
  await phone.set_content((ROOT/'Chess_Tetris_V6_Standalone.html').read_text(),wait_until='load')
  await phone.locator('#localChoice').click()
  assert await phone.locator('#board button.sq').count()==64
  await phone.screenshot(path=str(ROOT/'preview_v6_mobile.png'),full_page=True)
  assert not merr,merr
  print('BROWSER MOCK MOBILE PASS, JS errors:',merr)
  await browser.close()
asyncio.run(run())
