"""Stage 5 60Hz browser integration without localhost permission. Production HTML and frame merging."""
from playwright.sync_api import sync_playwright
from pathlib import Path
html=(Path(__file__).resolve().parent.parent/'battle.html').read_text()
errors=[]
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
 ctx=b.new_context(viewport={'width':1440,'height':960})
 page=ctx.new_page();page.on('pageerror',lambda e:errors.append(str(e)))
 page.evaluate('''() => {Object.defineProperty(window,'sessionStorage',{configurable:true,value:{getItem:()=>null,setItem:()=>{},removeItem:()=>{}}});window._sent=[];window.WebSocket=class{static OPEN=1;constructor(){this.readyState=1;queueMicrotask(()=>this.onopen?.())}send(t){window._sent.push(JSON.parse(t))}}}''')
 page.set_content(html,wait_until='load')
 room={'id':'60hz-test','state':'playing','name':'속도 검증','players':[{'id':'a','name':'A','ready':True,'connected':True},{'id':'b','name':'B','ready':True,'connected':True}]}
 rows=[','.join(['']*10) for _ in range(20)]
 def pl(x=3):return {'rows':rows,'active':{'kind':'I','tiles':[[x,1,'R',''],[x+1,1,'R',''],[x+2,1,'R',''],[x+3,1,'R','']]},'next':'I','hold':None,'hp':1000,'ap':[0,0,0,0],'lines':0,'topouts':0,'falls':0,'seq':0,'events':[]}
 frame={'type':'battle_state','frameId':1,'full':True,'roomId':'60hz-test','startAt':1,'serverAt':1000,'state':'playing','paused':False,'seconds':0,'probability':.07,'winner':None,'reason':'','players':[pl(),pl()]}
 page.evaluate('(r) => onMessage({type:"battle_joined",room:r,position:0,seatId:"a",seatToken:"tok"})',room)
 page.evaluate('(m) => onMessage(m)',frame)
 assert page.evaluate('() => latest.players[0].rows.length===20')
 page.evaluate('''async ()=>{
  for(let j=2;j<=95;j++){
   const part={...latest,frameId:j,full:false,players:latest.players.map((s,i)=>({
    active:{kind:'I',tiles:[[3,1+Math.floor(j/20),'R',''],[4,1+Math.floor(j/20),'R',''],[5,1+Math.floor(j/20),'R',''],[6,1+Math.floor(j/20),'R','']]},
    hp:s.hp,ap:s.ap,seq:s.seq,lines:s.lines,topouts:s.topouts,falls:s.falls,next:s.next,hold:s.hold
   }))};
   onMessage(part);
   await new Promise(r=>setTimeout(r,16));
  }
 }''')
 data=page.evaluate('''()=>({fps:document.getElementById('fps').textContent,hz:document.getElementById('hz').textContent,frames:hzFrames,rows:latest.players[0].rows.length,active:latest.players[0].active.tiles[0],boardCache:boardCache.get(myCtx)?.rows===latest.players[0].rows,match:!document.getElementById('match').hidden})''')
 assert int(data['hz'].split()[0])>=45,data
 assert data['rows']==20 and data['boardCache'] and data['match'],data
 # The special-effect keyframe must still trigger visual effects after deltas.
 keyframe={**frame,'frameId':96,'full':True,'players':[pl(),pl()]}
 keyframe['players'][0]['events']=[{'id':1,'text':'테스트 폭발','kind':'bomb','owner':0,'x':4,'y':15,'removed':3}]
 page.evaluate('(m)=>onMessage(m)',keyframe)
 assert page.evaluate('()=>fxBoard.some(f=>f.kind==="bomb")')
 # A stale reordered packet should not overwrite newer state.
 old={**frame,'frameId':40,'full':True}
 page.evaluate('(m)=>onMessage(m)',old)
 assert page.evaluate('()=>lastFrameId===96')
 page.evaluate('''(f)=>{onMessage({...f,frameId:97,full:true,state:'finished',winner:0,reason:'상대 HP 0'})}''',frame)
 assert page.locator('#resultTitle').inner_text()=='승리'
 assert not errors,errors
 print('PASS simulated 60Hz browser stream / merge / stat HUD / static canvas cache / special FX / stale-order rejection / winner one banner:',data)
 b.close()
