import assert from 'node:assert/strict';
import {spawn} from 'node:child_process';
import {setTimeout as sleep} from 'node:timers/promises';
const port=25000+Math.floor(Math.random()*15000),base=`http://127.0.0.1:${port}`;
const server=spawn(process.execPath,['server.js'],{cwd:new URL('..',import.meta.url).pathname,env:{...process.env,PORT:String(port)},stdio:['ignore','pipe','pipe']});
let logs='';server.stdout.on('data',b=>logs+=b);server.stderr.on('data',b=>logs+=b);
class Client{
 constructor(name){this.name=name;this.events=[];this.listeners=[];this.ws=null}
 async connect(){this.ws=new WebSocket(`ws://127.0.0.1:${port}/battle-ws`);this.ws.onmessage=e=>{const m=JSON.parse(e.data);this.events.push(m);for(const fn of [...this.listeners])fn()};await new Promise((ok,bad)=>{this.ws.addEventListener('open',ok,{once:true});this.ws.addEventListener('error',bad,{once:true})})}
 send(o){this.ws.send(JSON.stringify(o))}
 async take(check,ms=7000){let idx=this.events.findIndex(check);if(idx>=0)return this.events.splice(idx,1)[0];return new Promise((ok,bad)=>{const t=setTimeout(()=>{this.listeners=this.listeners.filter(x=>x!==wake);bad(Error(this.name+' timeout '+this.events.slice(-3).map(x=>x.type)))},ms);const wake=()=>{const i=this.events.findIndex(check);if(i<0)return;clearTimeout(t);this.listeners=this.listeners.filter(x=>x!==wake);ok(this.events.splice(i,1)[0])};this.listeners.push(wake)})}
 close(){this.ws.close()}
}
try{
 let ok=false;for(let i=0;i<90;i++){try{let r=await fetch(base+'/health');if(r.ok){assert.equal((await r.json()).version,'10.10.0');ok=true;break}}catch{}await sleep(60)}assert(ok,'server did not start '+logs);
 const a=new Client('A'),b=new Client('B'),c=new Client('C'),d=new Client('D');await Promise.all([a.connect(),b.connect(),c.connect(),d.connect()]);
 for(const p of [a,b,c,d])await p.take(m=>m.type==='battle_hello');
 a.send({type:'battle_create',roomName:'3P 공개방',name:'A',max:3});const ja=await a.take(m=>m.type==='battle_joined');
 assert.equal(ja.room.max,3);assert.equal(ja.position,0);
 b.send({type:'battle_list'});const list=await b.take(m=>m.type==='battle_rooms'&&m.rooms.some(x=>x.id===ja.room.id));assert(list.rooms.some(x=>x.max===3));
 b.send({type:'battle_join',roomId:ja.room.id,name:'B'});const jb=await b.take(m=>m.type==='battle_joined');assert.equal(jb.position,1);
 c.send({type:'battle_join',roomId:ja.room.id,name:'C'});const jc=await c.take(m=>m.type==='battle_joined');assert.equal(jc.position,2);
 d.send({type:'battle_join',roomId:ja.room.id,name:'D'});await d.take(m=>m.type==='battle_error');
 console.log('PASS 3P public create / list / join / reject fourth');
 for(const p of [a,b,c])p.send({type:'battle_ready',ready:true});
 for(const p of [a,b,c])await p.take(m=>m.type==='battle_start');
 for(const p of [a,b,c]){const snap=await p.take(m=>m.type==='battle_state'&&m.full&&m.state==='playing',7500);assert.equal(snap.players.length,3);assert.equal(snap.maxHp,2000);assert(snap.players.every(v=>v.rows.length===20))}
 console.log('PASS 3P synchronized countdown and all 3 grids initialized at 2000 HP');
 a.events.length=0;await sleep(1250);const count=a.events.filter(m=>m.type==='battle_state').length;
 assert(count>47&&count<88,'should be close to 60Hz, observed '+count);console.log('PASS 3P 60Hz cadence',count,'messages / 1.25s');
 for(const [i,p] of [a,b,c].entries()){
  p.send({type:'battle_input',action:'drop',seq:1});const snap=await p.take(m=>m.type==='battle_state'&&m.players?.[i]?.seq===1&&m.players[i].falls>=1);
  assert.equal(snap.players.length,3);
 }
 console.log('PASS independent 3P inputs and server reconciliation');
 a.close();const paused=await b.take(m=>m.type==='battle_state'&&m.paused===true);assert(paused);
 const resumed=new Client('A-resume');await resumed.connect();await resumed.take(m=>m.type==='battle_hello');
 resumed.send({type:'battle_resume',roomId:ja.room.id,seatToken:ja.seatToken});const rs=await resumed.take(m=>m.type==='battle_joined');assert.equal(rs.position,0);
 await b.take(m=>m.type==='battle_state'&&m.paused===false);console.log('PASS 3P disconnect + seat resume + unpause');
 c.send({type:'battle_leave'});let after=await b.take(m=>m.type==='battle_state'&&m.players?.[2]?.hp===0);assert.equal(after.state,'playing');
 assert.equal(after.players[0].hp,2000);assert.equal(after.players[1].hp,2000);
 console.log('PASS 3P first exit means elimination, other two continue');
 b.send({type:'battle_leave'});const final=await resumed.take(m=>m.type==='battle_state'&&m.state==='finished');assert.equal(final.winner,0);
 console.log('PASS 3P second elimination declares final survivor winner');
 [b,c,d,resumed].forEach(p=>p.close());
 console.log('STAGE 5 3P ONLINE V10.5 ALL PASS');
}finally{server.kill('SIGTERM')}
