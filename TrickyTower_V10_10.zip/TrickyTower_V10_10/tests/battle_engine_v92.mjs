import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
const require=createRequire(import.meta.url),e=require('../battle_engine.js');
const test=(name,fn)=>{fn();console.log('PASS',name)};
const g=(rng=()=>.97)=>{const x=e.newGame(0,rng);x.state='playing';x.clock=0;return x};
const c=(color='R',sp=null,id=null)=>({c:color,s:sp,id});
const full=(arr)=>{assert.equal(arr.length,10);return arr};
test('10 columns × 20 rows stay exact',()=>{const x=g();assert.equal(x.players[0].grid.length,20);assert(x.players[0].grid.every(row=>row.length===10))});
test('exact special probability boundaries remain unchanged',()=>{for(const [t,v] of [[0,.07],[29.9,.07],[30,.15],[44.9,.15],[45,.25],[74.9,.25],[75,.45],[104.9,.45],[105,.70],[129.9,.70],[130,1]])assert.equal(e.probability(t),v)});
test('ordinary tetromino has four same-color cells, no special',()=>{const x=g(()=>.97),p=e.makePiece(x,'T');assert.equal(p.tiles.length,4);assert.equal(new Set(p.tiles.map(t=>t.c)).size,1);assert(p.tiles.every(t=>t.s===null));assert.equal(new Set(p.tiles.map(t=>t.id)).size,1)});
test('special tetromino has same color, same special and id on all 4 tiles',()=>{const x=g(()=>.01);const p=e.makePiece(x,'L');assert.equal(p.tiles.length,4);assert.deepEqual(new Set(p.tiles.map(t=>t.c)),new Set(['R']));assert.deepEqual(new Set(p.tiles.map(t=>t.s)),new Set(['heal']));assert.equal(new Set(p.tiles.map(t=>t.id)).size,1)});
test('at 130s special chance 100% on every 4-cell tetromino',()=>{const x=g(()=>.99);x.clock=130000;for(let i=0;i<30;i++){const p=e.makePiece(x,'I');assert.equal(p.tiles.length,4);assert(p.tiles.every(t=>t.s!==null));assert.equal(new Set(p.tiles.map(t=>t.s)).size,1)}});
test('generated special always one of six types and uniform on rotation',()=>{for(let i=0;i<6;i++){const r=[.56,0,(i+.02)/6];let j=0;const x=g();x.clock=130000;x.rng=()=>r[j++%r.length];const p=e.makePiece(x,'J');assert.equal(new Set(p.tiles.map(t=>t.s)).size,1);assert.equal(p.tiles[0].s,e.SPECIALS[i]);assert.equal(new Set(e.rotatedTiles(p.tiles,3).map(t=>t.s)).size,1)}});
test('uniform color AP awards 10R -> exactly one 100-damage hit',()=>{const x=g(),p=x.players[0];p.grid[19]=full(Array.from({length:10},()=>c('R')));e.checkRows(x,0);assert.deepEqual(p.ap,[0,0,0,0]);assert.equal(x.players[1].hp,900)});
test('different-color AP still applies on a row composed of several single-color pieces',()=>{const x=g(),p=x.players[0];p.grid[19]=full([...Array.from({length:4},()=>c('R')), ...Array.from({length:2},()=>c('Y')),c('B'),...Array.from({length:3},()=>c('G'))]);e.checkRows(x,0);assert.deepEqual(p.ap,[4,1,2,3])});
test('healing triggers only on cleared line and once even if 4 cells share piece',()=>{
 const x=g(),p=x.players[0];p.hp=800;p.active={kind:'O',id:101,x:2,y:15,rotation:0,tiles:[{x:0,y:0,c:'G',s:'heal',id:101},{x:1,y:0,c:'G',s:'heal',id:101},{x:0,y:1,c:'G',s:'heal',id:101},{x:1,y:1,c:'G',s:'heal',id:101}]};
 e.lock(x,0);assert.equal(p.hp,800); // landing alone never heals
 p.grid[19]=full([c('R'),c('R'),c('G','heal',101),c('G','heal',101),...Array.from({length:6},()=>c('B'))]);p.grid[18][2]=c('G','heal',101);
 e.checkRows(x,0);assert.equal(p.hp,875);assert.equal(p.grid[19][2].s,null);p.grid[19]=full(Array.from({length:10},()=>c('G')));e.checkRows(x,0);assert.equal(p.hp,875);
});
test('healing caps HP at 1000',()=>{const x=g(),p=x.players[0];p.hp=980;p.grid[19]=full([c('R','heal',12),...Array.from({length:9},()=>c('R'))]);e.checkRows(x,0);assert.equal(p.hp,1000)});
test('damage never triggers on landing and triggers once only on cleared line',()=>{
 const x=g(),p=x.players[0];p.active={kind:'I',id:301,x:2,y:15,rotation:0,tiles:[{x:0,y:0,c:'R',s:'damage',id:301},{x:1,y:0,c:'R',s:'damage',id:301}]};e.lock(x,0);assert.equal(x.players[1].hp,1000);
 p.grid[19]=full([c('R','damage',301),c('R','damage',301),...Array.from({length:8},()=>c('B'))]);e.checkRows(x,0);assert.equal(x.players[1].hp,950);
});
test('bomb does nothing on landing, activates once on row clear and 3x3 AP does not double-count row tiles',()=>{
 const x=g(),p=x.players[0];p.active={kind:'O',id:401,x:1,y:12,rotation:0,tiles:[{x:0,y:0,c:'R',s:'bomb',id:401}]};e.lock(x,0);assert.equal(p.grid[12][1].s,'bomb');assert.equal(p.ap[0],0);
 p.grid[19]=full(Array.from({length:10},(_,i)=>c('R',i===4||i===5?'bomb':null,i===4||i===5?401:null)));
 for(let i=3;i<=6;i++)p.grid[18][i]=c('G');e.checkRows(x,0);
 // 10R row triggers 100 damage; bomb center at x4 removes only x3..x5 on row18 = 3G.
 assert.equal(x.players[1].hp,900);assert.deepEqual(p.ap,[0,0,0,3]);assert.equal(p.grid[19][6]?.c,'G');
});
test('double awards exactly 2x AP regardless of 2 special tiles / separate pieces',()=>{const x=g(),p=x.players[0];p.grid[19]=full(Array.from({length:10},(_,i)=>c('R',i===1||i===2?'double':null,i===1||i===2?5:null)));e.checkRows(x,0);assert.equal(x.players[1].hp,800);assert.deepEqual(p.ap,[0,0,0,0])});
test('sand is the only special activated on landing and clears all rows touched by its piece',()=>{
 const x=g(),p=x.players[0];p.grid[18][0]=c('G');p.grid[19][0]=c('Y');p.active={kind:'O',id:501,x:2,y:18,rotation:0,tiles:[{x:0,y:0,c:'R',s:'sand',id:501},{x:1,y:0,c:'R',s:'sand',id:501},{x:0,y:1,c:'R',s:'sand',id:501},{x:1,y:1,c:'R',s:'sand',id:501}]};e.lock(x,0);assert.equal(p.lines,2);assert.equal(p.grid[19][0],null);assert.deepEqual(p.ap,[4,0,1,1]);
});
test('specials destroyed by bomb outside a completed line do not activate',()=>{
 const x=g(),p=x.players[0];p.grid[18][4]=c('R','damage',4010);p.grid[19]=full(Array.from({length:10},(_,i)=>c('Y',i===4?'bomb':null,i===4?4001:null)));e.checkRows(x,0);
 assert.equal(x.players[1].hp,900); // 10Y creates 100 damage, discarded damage tile not triggered
});
test('top-out remains 500 damage without grid physics',()=>{const x=g(),p=x.players[0];p.grid[19][0]=c('R');for(let j=0;j<2;j++){p.active={kind:'O',x:3,y:-1,rotation:0,tiles:[{x:0,y:0,c:'R',s:null}]};e.lock(x,0);assert.equal(p.hp,(1-j)*500);assert.equal(p.grid[19][0],null)}assert.equal(x.winner,1)});
test('rotations, wall collision, soft drop, hard drop, hold retain old gameplay',()=>{const x=g();e.spawn(x,0);const p=x.players[0];for(let i=0;i<20;i++)e.input(x,0,'left');assert(e.tilesFor(p).every(t=>t.x>=0&&t.x<10));e.input(x,0,'rotate');assert(e.tilesFor(p).every(t=>t.x>=0&&t.x<10));e.input(x,0,'drop');assert.equal(p.falls,1);assert(p.active);e.input(x,0,'hold');assert(p.hold)});
test('pause, server ticks and 10x20 invariant across 3000 frames',()=>{const x=e.newGame(1000,Math.random);e.tick(x,1500);let y=x.players[0].active.y;e.setPaused(x,true,1600);e.tick(x,15000);assert.equal(x.players[0].active.y,y);e.setPaused(x,false,15600);assert.equal(x.startAt,15000);for(let i=0;i<3000;i++){e.tick(x,15600+i*33);if(x.state==='playing'){let actions=['left','right','rotate','down','drop','hold'];e.input(x,i%2,actions[Math.floor(Math.random()*actions.length)])}for(const p of x.players){assert(p.grid.length===20&&p.grid.every(row=>row.length===10));assert(p.hp>=0&&p.hp<=1000);assert(p.active===null||new Set(p.active.tiles.map(t=>t.c)).size===1);assert(p.active===null||new Set(p.active.tiles.map(t=>t.s)).size===1)}if(x.state==='finished')break}});
console.log('BATTLE ENGINE V9.2 ALL PASS');
