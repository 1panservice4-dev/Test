from playwright.sync_api import sync_playwright
from pathlib import Path
root=Path(__file__).resolve().parent.parent
html=(root/'battle.html').read_text()
errors=[]
with sync_playwright() as p:
 browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
 for seat in [0,1]:
  ctx=browser.new_context(viewport={'width':1280,'height':900},device_scale_factor=1)
  page=ctx.new_page();page.on('pageerror',lambda err:errors.append(str(err)))
  page.evaluate('''() => {Object.defineProperty(window,'sessionStorage',{configurable:true,value:{getItem:()=>null,setItem:()=>{},removeItem:()=>{}}});window.WebSocket=class{static OPEN=1;constructor(){this.readyState=1;queueMicrotask(()=>this.onopen?.())}send(){}}}''')
  page.set_content(html,wait_until='load')
  r={'id':'grey-room','name':'회색 지대 테스트','state':'playing','players':[{'id':'a','name':'A','ready':True,'connected':True},{'id':'b','name':'B','ready':True,'connected':True}]}
  def pl(hp,owner):
   rows=[','.join(['']*10) for _ in range(20)]
   if owner==1:
    row=['X']*10;row[3]='';rows[19]=','.join(row)
   if owner==0:
    row=['']*10;row[4]='Rz';rows[18]=','.join(row)
   return {'rows':rows,'active':None,'next':'T','hold':None,'hp':hp,'ap':[4,2,1,3],'lines':1,'topouts':0,'falls':2,'events':[],'seq':0}
  state={'type':'battle_state','roomId':'grey-room','frameId':5,'full':True,'startAt':1000,'serverAt':5000,'state':'playing','paused':False,'seconds':4,'probability':.07,'winner':None,'reason':'','players':[pl(1000,0),pl(1000,1)]}
  event={'id':1,'text':'회색 지대 발동','kind':'garbage','owner':0,'target':1,'gap':3,'rows':1,'x':4.5,'y':19}
  for i in [0,1]:state['players'][i]['events']=[event]
  page.evaluate('(data)=>onMessage({type:"battle_joined",room:data.room,seatId:data.seat===0?"a":"b",seatToken:"tok",position:data.seat})',{'room':r,'seat':seat})
  page.evaluate('(s)=>onMessage(s)',state)
  page.wait_for_timeout(150)
  val=page.evaluate('''() => ({
    board:!!document.querySelector('#myBoard'), fxCount:fxBoard.filter(e=>e.kind==='garbage').length,
    attackCount:fxFlying.filter(e=>e.label==='방해 줄 +1').length,
    gray:decode(latest.players[1].rows)[19].map(x=>x?.c||'').join(''),
    hasGuide:document.querySelector('.guide').textContent.includes('회색 지대'),
    special: SPECIAL.grey,
    rowsCount:decode(latest.players[1].rows).length
   })''')
  assert val['fxCount']==1 and val['attackCount']==1 and val['rowsCount']==20 and val['hasGuide'] and val['special']=='▦',val
  assert val['gray'].count('X')==9,val
  page.evaluate('(s)=>onMessage(s)',state)
  after=page.evaluate('''()=>({fx:fxBoard.length,fly:fxFlying.length})''')
  assert after['fx']==val['fxCount'] and after['fly']==val['attackCount'],(val,after)
  assert page.evaluate('''()=>document.querySelector('#matchStatus').textContent.includes('LIVE')''')
  if seat==0:page.screenshot(path='/mnt/data/Tricky_Tower_V10_3_GreyZone_Preview.png',full_page=True)
  print('PASS Chromium seat',seat,'garbage effect, cached 10x20 gray board, no repeat:',val)
  ctx.close()
 browser.close()
assert not errors,errors
print('PASS V10.3 gray zone visual rendering and event dedup, no JS page errors')
