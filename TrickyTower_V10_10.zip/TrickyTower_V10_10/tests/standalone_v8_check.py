import asyncio
from pathlib import Path
from playwright.async_api import async_playwright
async def main():
 s=Path('/mnt/data/Tricky_Tower_DUEL_V8_4Stages/Tricky_Tower_V8_4Stages_Local_Standalone.html').read_text()
 async with async_playwright() as pw:
  browser=await pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
  p=await browser.new_page(viewport={'width':1280,'height':880});err=[];p.on('pageerror',lambda x:err.append(str(x)))
  await p.set_content(s,wait_until='domcontentloaded',timeout=60000)
  print('STAGE CARDS',await p.locator('.stage-chooser-card').count())
  await p.locator('#quickStage4').click(timeout=15000)
  await asyncio.sleep(3)
  print('OVERLAY',await p.locator('#abilityStandaloneOverlay').get_attribute('hidden'))
  print('IFRAME',len(p.frames),'URL',p.frames[-1].url)
  print('CHESS SQUARES', await p.frames[-1].locator('.square').count())
  print('2P/4P choice', await p.frames[-1].locator('#entryTwoBtn').count(), await p.frames[-1].locator('#entryFourBtn').count())
  await p.screenshot(path='/mnt/data/V8_Standalone_Fourth_Stage.png')
  await p.locator('#backFromAbility').click()
  print('BACK',await p.locator('#abilityStandaloneOverlay').get_attribute('hidden'))
  print('JS ERRORS',err[:5]);await browser.close()
asyncio.run(main())
