import os,time,subprocess,socket
from pathlib import Path
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1]
port=17881
p=subprocess.Popen(['node','server.js'],cwd=ROOT,env={**os.environ,'PORT':str(port)},stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
try:
    for _ in range(80):
        try:
            with socket.create_connection(('127.0.0.1',port),timeout=.2):break
        except OSError:time.sleep(.1)
    else:raise RuntimeError('server unreachable')
    with sync_playwright() as t:
        browser=t.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage','--disable-gpu','--no-first-run'])
        host=browser.new_context(viewport={'width':1280,'height':850})
        guest=browser.new_context(viewport={'width':1280,'height':850})
        p1=host.new_page();p2=guest.new_page()
        err1=[];err2=[]
        p1.on('pageerror',lambda e:err1.append(str(e)));p2.on('pageerror',lambda e:err2.append(str(e)))
        p1.goto(f'http://127.0.0.1:{port}/hybrid.html',wait_until='domcontentloaded')
        p2.goto(f'http://127.0.0.1:{port}/hybrid.html',wait_until='domcontentloaded')
        assert p1.locator('#classicCard').count()==1
        p1.locator('#onlineBtn').click()
        p2.locator('#tetrisCard').click();p2.locator('#onlineBtn').click()
        p1.locator('#createBtn').click()
        p1.locator('#waiting').wait_for(state='visible',timeout=5000)
        p2.locator('#refreshBtn').click()
        p2.locator('#rooms button:not([disabled])').first.click()
        p1.locator('#playing').wait_for(state='visible',timeout=5000)
        p2.locator('#playing').wait_for(state='visible',timeout=5000)
        assert p1.locator('#board button.sq').count()==64
        assert p2.locator('#board button.sq').count()==64
        assert '백 차례' in p1.locator('#turnText').inner_text()
        assert '기본 체스' in p1.locator('#perspective').inner_text()
        assert '흑 진영' in p2.locator('#perspective').inner_text()
        assert '테트리스 체스' in p2.locator('#perspective').inner_text()
        p1.locator('[aria-label^="e2 "]').click()
        p1.locator('[aria-label^="e4 "]').click()
        p1.wait_for_function("document.querySelector('#moveLog').innerText.includes('e2–e4')",timeout=5000)
        p2.wait_for_function("document.querySelector('#moveLog').innerText.includes('e2–e4')",timeout=5000)
        p2.locator('[aria-label^="a8 "]').click();p2.locator('[aria-label^="a5 "]').click()
        p1.wait_for_function("document.querySelector('#moveLog').innerText.includes('a8–a5')",timeout=5000)
        p2.wait_for_function("document.querySelector('#moveLog').innerText.includes('a8–a5')",timeout=5000)
        p1.screenshot(path=str(ROOT/'Stage6_Online_White_Chess.png'),full_page=True)
        p2.screenshot(path=str(ROOT/'Stage6_Online_Black_Tetris.png'),full_page=True)
        assert not err1,err1;assert not err2,err2
        # Local mode reverse faction option and clicked rook jump must both work.
        local=browser.new_context(viewport={'width':1024,'height':800})
        pl=local.new_page();errs=[];pl.on('pageerror',lambda e:errs.append(str(e)))
        pl.goto(f'http://127.0.0.1:{port}/hybrid.html',wait_until='domcontentloaded')
        pl.locator('#tetrisCard').click();pl.locator('#localBtn').click()
        pl.locator('[aria-label^="a1 "]').click();pl.locator('[aria-label^="a4 "]').click()
        assert '흑 차례' in pl.locator('#turnText').inner_text()
        assert '흑 진영' in pl.locator('#perspective').inner_text()
        pl.locator('#undoBtn').click();assert '백 차례' in pl.locator('#turnText').inner_text()
        pl.locator('#restartBtn').click();assert pl.locator('#board button.sq').count()==64
        pl.screenshot(path=str(ROOT/'Stage6_Choice_And_Local.png'),full_page=True)
        assert not errs,errs
        # Legacy main portal has all 6 stages.
        main=host.new_page();main.goto(f'http://127.0.0.1:{port}/',wait_until='domcontentloaded')
        assert main.locator('#quickStage1').count()==1 and main.locator('#quickStage6').count()==1
        assert '6개 스테이지' in main.locator('.stage-picker-heading').inner_text()
        main.screenshot(path=str(ROOT/'Six_Stages_Main_Lobby.png'),full_page=True)
        print('PASS Chromium: 2 real browser contexts, white move e2e4, black tetris rook a8a5, local undo/restart, all six stage cards, no JS errors')
        browser.close()
finally:
    p.terminate()
    try:p.wait(timeout=3)
    except subprocess.TimeoutExpired:p.kill()
