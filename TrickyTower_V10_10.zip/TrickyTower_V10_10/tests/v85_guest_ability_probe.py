import asyncio
from real_game_bridge import api,setup
from playwright.async_api import async_playwright
async def main():
 async with async_playwright() as pw:
  browser=await pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
  h=api('/api/ability/create',{'max':2,'name':'Guest-white setup'});g=api('/api/ability/join',{'roomId':h['roomId']})
  arr=[]
  try:
   for seat in [h,g]:
    data=await setup(browser,seat['roomId'],seat['seatToken'],seat['mode'],seat['role'],seat['variant'])
    p=data[0];p.on('console',lambda msg:print('CONSOLE',msg.type,msg.text[:180]) if msg.type in ('warning','error') else None)
    arr.append(data)
   pages=[x[0] for x in arr]
   async def dump(tag):
    for i,p in enumerate(pages):
     res=await p.evaluate('''()=>({phase:window.__TT_TWO_PHASE__?.(),core:window.__TWO_MULTIPLAYER_CORE__.status(), modals:[...document.querySelectorAll('.modal.show')].map(x=>x.id), cards:[...document.querySelectorAll('#augmentCards .card-choice')].map(x=>x.dataset.ability).slice(0,5),desc:document.querySelector('#augmentDesc')?.textContent.slice(0,200)})''')
     print(tag,i,{'phase':res['phase'],'pendingCommands':res['core'].get('pendingCommands'),'rev':res['core'].get('stateVersion'),'applied':res['core'].get('lastAppliedStateVersion'),'sync':res['core'].get('syncing'),'modals':res['modals'],'cards':res['cards'],'desc':res['desc']},flush=True)
   await asyncio.sleep(3);await dump('before claim')
   await pages[1].evaluate("()=>document.querySelector('#pickWhiteBtn').click()")
   await asyncio.sleep(4);await dump('after claim')
   await pages[0].evaluate("()=>document.querySelector('#augmentCards .card-choice')?.click()")
   await asyncio.sleep(3);await dump('after host choice')
   await pages[1].evaluate("()=>document.querySelector('#augmentCards .card-choice')?.click()")
   await asyncio.sleep(5);await dump('after guest choice')
  finally:
   for p,proxy,_ in arr:
    try:await proxy.cleanup();await p.close()
    except:pass
   await browser.close()
asyncio.run(main())
