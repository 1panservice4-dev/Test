from pathlib import Path
from playwright.sync_api import sync_playwright
html=Path(__file__).resolve().parents[1].joinpath('Tricky_Tower_V7_1_3Stages_Standalone.html').read_text()
with sync_playwright() as p:
 browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
 page=browser.new_page(viewport={'width':1350,'height':850})
 errors=[]
 page.on('pageerror',lambda e:errors.append(str(e)))
 page.set_content(html,wait_until='load')
 for id in ['quickStage1','quickStage2','quickStage3']:
  assert page.locator('#'+id).count()==1, id
 print('PASS integrated standalone three-stage selectors')
 page.locator('#quickStage3').click()
 frame=page.frame_locator('#localChessGameFrame')
 frame.locator('#localChoice').wait_for(timeout=5000)
 frame.locator('#localChoice').click()
 assert frame.locator('#board .sq').count()==64
 assert frame.locator('#perspectiveTag').inner_text().endswith('파랑 아래')
 page.locator('#backFromChess').click()
 assert page.locator('#chessStandaloneOverlay').get_attribute('hidden') is not None
 print('PASS integrated standalone stage 3 launches and returns to lobby')
 if errors:raise AssertionError(errors)
 browser.close()
