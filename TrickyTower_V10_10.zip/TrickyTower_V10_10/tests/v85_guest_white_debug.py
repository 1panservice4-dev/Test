import asyncio
import real_game_bridge as T
from playwright.async_api import async_playwright
async def main():
 async with async_playwright() as pw:
  browser=await pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
  async def one_round(white_host):
   host=T.api('/api/ability/create',{'max':2,'name':'Focus stability'});guest=T.api('/api/ability/join',{'roomId':host['roomId']})
   arr=[]
   try:
    for s in (host,guest):arr.append(await T.setup(browser,s['roomId'],s['seatToken'],s['mode'],s['role'],s['variant']))
    pages=[x[0] for x in arr]
    async def core(i):
     return await pages[i].evaluate('''() => { const c=window.__TWO_MULTIPLAYER_CORE__.status();return {role:c.role,syncing:c.syncing,authenticated:c.authenticated,peerSynced:c.peerSynchronized,revision:c.stateVersion,version:c.lastAppliedStateVersion,turn:document.querySelector('#turnPill')?.textContent,phase:window.__TT_TWO_PHASE__?.(),modals:[...document.querySelectorAll('.modal.show')].map(x=>x.id)} }''')
    async def wait(test,maxsecs=12):
     for j in range(maxsecs*5):
      if await test():return True
      await asyncio.sleep(.2)
     raise AssertionError('Timed out '+str(await core(0))+' / '+str(await core(1)))
    await wait(lambda: both_ready(),12) if False else asyncio.sleep(0)
    await asyncio.sleep(3)
    sel=0 if white_host else 1
    await pages[sel].evaluate("()=>document.querySelector('#pickWhiteBtn').click()")
    await wait(lambda: colors_ready(),10) if False else asyncio.sleep(3)
    for i in range(2):
     await pages[i].evaluate("()=>document.querySelector('#augmentCards .card-choice')?.click()")
     await asyncio.sleep(.7)
    await asyncio.sleep(3)
    for i in range(2):
     c=await core(i);assert c['authenticated'] and not c['syncing'] and c['peerSynced'],('initial',i,c)
    # Existing V8.3 made host permanently syncing=true here. Both focus and pageshow should be harmless now.
    for j in range(3):
     await pages[0].evaluate("()=>{window.dispatchEvent(new Event('focus'));window.dispatchEvent(new Event('pageshow'))}")
     await pages[1].evaluate("()=>window.dispatchEvent(new Event('focus'))")
     await asyncio.sleep(.6)
     for i in range(2):
      c=await core(i);assert not c['syncing'] and c['peerSynced'],('resume deadlock',j,i,c)
    async def click(i,r,c):
     await pages[i].evaluate('''([r,c])=>{const e=document.querySelector(`#board .square[data-r="${r}"][data-c="${c}"]`);if(!e)throw Error('missing square');e.dispatchEvent(new PointerEvent('pointerdown',{bubbles:true,cancelable:true,pointerType:'mouse'}));}''',[r,c]);await asyncio.sleep(.22)
    await click(sel,6,4);await click(sel,4,4)
    await asyncio.sleep(4)
    for idx,(pg,proxy,errs) in enumerate(arr):
     print('DEBUG POST WHITE',idx,await core(idx), 'STATUS',str(await pg.evaluate('''()=>window.__TWO_MULTIPLAYER_CORE__.status()'''))[:1800], 'errors',errs[:2],'proxyerrors',proxy.errors[:3],flush=True)

    for i in range(2):
     c=await core(i); assert c['turn']=='흑' and not c['syncing'],('after white',i,c)
    other=1-sel
    await click(other,1,4);await click(other,3,4)
    await asyncio.sleep(1)
    for i in range(2):
     c=await core(i);assert c['turn']=='백' and not c['syncing'],('after black',i,c)
    await pages[0].evaluate("()=>window.dispatchEvent(new Event('focus'))")
    await asyncio.sleep(.5)
    for i in range(2):assert not (await core(i))['syncing'],('after focus 2',i,await core(i))
    # Simulate a lost completion confirmation on the guest. The watchdog
    # must request a fresh authoritative snapshot and release the lock.
    guest_index=1
    await pages[guest_index].evaluate("""()=>{const c=window.__TWO_MULTIPLAYER_CORE__;c.setSyncing(true,'test-forgotten-sync-complete');c.syncSince=Date.now()-20000;c.lastSyncRecoveryAt=0;}""")
    for attempt in range(32):
     if not (await core(guest_index))['syncing']:break
     await asyncio.sleep(.25)
    for i in range(2):assert not (await core(i))['syncing'],('watchdog recovery failed',i,await core(i))
    print('PASS: 2P host-white' if white_host else 'PASS: 2P guest-white','three focus events and white e2e4 / black e7e5; both unlocked',flush=True)
   finally:
    for p,proxy,e in arr:
     try:await proxy.cleanup();await p.close()
     except:pass
  try:
   # await one_round(True)
   await one_round(False)
  finally:await browser.close()
if __name__=='__main__':asyncio.run(main())
