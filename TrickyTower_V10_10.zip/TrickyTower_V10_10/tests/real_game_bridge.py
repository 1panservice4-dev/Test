import asyncio, json, urllib.request, time, re
from pathlib import Path
import websockets
from playwright.async_api import async_playwright
P=Path(__file__).resolve().parent.parent; BASE='http://127.0.0.1:19854'
def api(path,obj):
 req=urllib.request.Request(BASE+path,json.dumps(obj).encode(),headers={'Content-Type':'application/json'})
 with urllib.request.urlopen(req,timeout=10) as res:return json.load(res)
ORIGINAL=(P/'ability_chess.html').read_text()
TRANSPORT=(P/'ability_transport.js').read_text()
FAKE_WS=r'''<script>
(function(){
 let counter=0;
 class FakeWS {
   static OPEN=1; static CONNECTING=0; static CLOSING=2; static CLOSED=3;
   constructor(url){ this.id='fake-'+(++counter);this.url=url;this.readyState=0;this.bufferedAmount=0;this.listeners={};window.__fakeWS.sockets.set(this.id,this);window.bridgeOpen(this.id,url);}
   addEventListener(event,fn){(this.listeners[event]??=[]).push(fn)}
   removeEventListener(event,fn){this.listeners[event]=(this.listeners[event]||[]).filter(x=>x!==fn)}
   send(text){if(this.readyState!==1)throw Error('not open');window.bridgeSend(this.id,text)}
   close(){if(this.readyState===3)return;this.readyState=3;window.bridgeClose(this.id);this._dispatch('close',{})}
   _dispatch(event,data){if(event==='open')this.readyState=1;if(event==='close')this.readyState=3;
      for(const fn of this.listeners[event]||[])try{fn({type:event,...data})}catch(err){console.error('fakews event error',err)} }
 }
 window.__fakeWS={sockets:new Map(),deliver:(id,event,text)=>{let sock=window.__fakeWS.sockets.get(id);if(sock)sock._dispatch(event,event==='message'?{data:text}:{})}};
 window.WebSocket=FakeWS;
})();
</script>'''
def html_for(room,seat,mode,role,variant='brawl'):
 s=ORIGINAL
 boot=f'''<script>
 window.__PUBLIC_ABILITY_ROOM__={json.dumps(room)};
 window.__PUBLIC_SEAT__={json.dumps(seat)};
 window.__PUBLIC_ABILITY_ROLE__={json.dumps(role)};
 window.__PUBLIC_ABILITY_MODE__={json.dumps(mode)};
 window.__PUBLIC_ABILITY_CONFIG__={{variant:{json.dumps(variant)},abilities:true,clock:0}};
 </script>'''
 # Replace original runtime config script in head (the script immediately preceding transport)
 s=re.sub(r'<script>\s*const q=new URLSearchParams\(location.search\);[\s\S]*?</script>\s*<script src="/ability_transport.js"></script>',boot+'<script>'+TRANSPORT.replace("const room=params.get('room')||'',seat=params.get('seat')||'',mode=params.get('mode')||'',role=params.get('role')||''", "const room=window.__PUBLIC_ABILITY_ROOM__||'',seat=window.__PUBLIC_SEAT__||'',mode=window.__PUBLIC_ABILITY_MODE__||'',role=window.__PUBLIC_ABILITY_ROLE__||''")+'</script>',s,count=1)
 # Avoid undefined `room` in edge cases, and request attempt to real network
 s=s.replace('<head>', '<head>'+FAKE_WS,1)
 s=s.replace('window.__PUBLIC_ABILITY_MODE__='+json.dumps(mode)+';', 'window.__PUBLIC_ABILITY_MODE__='+json.dumps(mode)+';\n document.documentElement.classList.add(\"tt-online-prestart\");')
 return s
class Proxy:
 def __init__(self,page,room,seat):self.page=page;self.room=room;self.seat=seat;self.sockets={};self.tasks=[];self.errors=[]
 async def open(self,src,sockid,url):
  try:
   w=await websockets.connect(f'ws://127.0.0.1:19854/ability-ws?room={self.room}&seat={self.seat}',max_size=4500000,ping_interval=20)
   self.sockets[sockid]=w
   await self.page.evaluate("id=>window.__fakeWS.deliver(id,'open')",sockid)
   async def read():
    try:
     async for msg in w:
      try:
       if '"type":"net_tick"' in msg:continue  # 30Hz is tested directly without the expensive JS bridge
       await self.page.evaluate("(a)=>window.__fakeWS.deliver(a.id,'message',a.text)",{'id':sockid,'text':msg})
      except Exception as e:self.errors.append('deliver:'+str(e)[:80]);break
    except Exception as e:self.errors.append('read:'+str(e)[:80])
    try:await self.page.evaluate("id=>window.__fakeWS.deliver(id,'close')",sockid)
    except:pass
   self.tasks.append(asyncio.create_task(read()))
  except Exception as e:self.errors.append('open:'+str(e))
 async def send(self,src,sockid,msg):
  try:
   w=self.sockets.get(sockid)
   if w:await w.send(msg)
  except Exception as e:self.errors.append('send:'+str(e)[:120])
 async def close(self,src,sockid):
  if sockid in self.sockets:await self.sockets.pop(sockid).close()
 async def cleanup(self):
  for w in self.sockets.values():await w.close()
  for t in self.tasks:t.cancel()
async def setup(browser,room,seat,mode,role,variant='brawl'):
 p=await browser.new_page(viewport={'width':1280,'height':880});errors=[]
 p.on('pageerror',lambda e:errors.append(str(e)))
 proxy=Proxy(p,room,seat)
 await p.expose_binding('bridgeOpen',proxy.open)
 await p.expose_binding('bridgeSend',proxy.send)
 await p.expose_binding('bridgeClose',proxy.close)
 await p.set_content(html_for(room,seat,mode,role,variant),wait_until='load',timeout=60000)
 return p,proxy,errors
async def main():
 async with async_playwright() as pw:
  browser=await pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
  for size in (2,4):
   print('\n=========== PLAYERS',size,'=============')
   host=api('/api/ability/create',{'max':size,'name':f'Live {size}','variant':'brawl'})
   seats=[host]+[api('/api/ability/join',{'roomId':host['roomId']}) for _ in range(size-1)]
   allp=[]
   try:
    for i,seat in enumerate(seats):
     p,proxy,errs=await setup(browser,seat['roomId'],seat['seatToken'],seat['mode'],seat['role'],seat['variant'])
     allp.append((p,proxy,errs))
     print('Created',i,'page errors',errs[:2])
     await asyncio.sleep(0.2)
    await asyncio.sleep(8 if size==2 else 14)
    for i,(page,proxy,errs) in enumerate(allp):
     result=await page.evaluate('''()=>({
       two:window.__CHAOS_MULTIPLAYER_DIAGNOSTICS__?._state?.two,
       four:window.__FOUR_MULTIPLAYER_CORE__?.status?.(),
       title:document.title,
       twoModal:document.getElementById('multiWaitingView')?.style.display,
       fourModal:document.getElementById('fourColorLobbyModal')?.className,
       squareCount:document.querySelectorAll('.square').length,
       peers:window.__fakeWS?.sockets?.size
     })''')
     print('player',i,':',str(result)[:1200], 'errors',errs[:3],'bridge errors',proxy.errors[:3])
     if i==0:await page.screenshot(path=f'/mnt/data/V8_Ability_{size}P_Browser.png')
   finally:
    for page,proxy,errs in allp:
     await proxy.cleanup();await page.close()
  await browser.close()
if __name__=='__main__':
 asyncio.run(main())
