import asyncio
from real_game_bridge import api,setup
from playwright.async_api import async_playwright
async def main():
 async with async_playwright() as pw:
  browser=await pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
  host=api('/api/ability/create',{'max':4,'name':'Four player gameplay regression','variant':'brawl'})
  seats=[host]+[api('/api/ability/join',{'roomId':host['roomId']}) for _ in range(3)]
  arr=[]
  try:
   for idx,s in enumerate(seats):
    arr.append(await setup(browser,s['roomId'],s['seatToken'],s['mode'],s['role'],s['variant']))
    print('LOADED',idx,flush=True)
   await asyncio.sleep(3)
   for idx,color in enumerate(['Red','Blue','Yellow','Green']):
    p=arr[idx][0]
    await p.evaluate('''c=>document.getElementById('fourPick'+c).click()''',color)
    await asyncio.sleep(.45)
   await asyncio.sleep(3)
   for idx,(p,proxy,errs) in enumerate(arr):
    print('BEFORE ABILITY',idx,await p.evaluate("()=>({color:window.__FOUR_MULTIPLAYER_CORE__?.status()?.color, phase:window.__FOUR_MULTIPLAYER_CORE__?.status()?.phase, cards:document.querySelectorAll('#fourAbilityCards .four-ability-card').length})"),flush=True)
    await p.evaluate("()=>document.querySelector('#fourAbilityCards .four-ability-card')?.click()")
    await asyncio.sleep(1.0)
   await asyncio.sleep(6)
   for idx,(p,proxy,errs) in enumerate(arr):
    result=await p.evaluate("()=>({phase:window.__FOUR_MULTIPLAYER_CORE__?.status()?.phase, state:window.__FOUR_MULTIPLAYER_CORE__?.status()?.stateVersion, started:window.__FOUR_MULTIPLAYER_CORE__?.status()?.started, color:window.__FOUR_MULTIPLAYER_CORE__?.status()?.color, modal:[...document.querySelectorAll('.modal.show')].map(x=>x.id), cells:document.querySelectorAll('.four-cell').length})")
    print('GAME',idx,result,'ERR',errs[:2], 'BRIDGE',proxy.errors[:2],flush=True)
    if idx==0: await p.screenshot(path='/mnt/data/V8_4P_Gameplay_Start.png')
  finally:
   for p,proxy,_ in arr:
    try:await proxy.cleanup();await p.close()
    except:pass
   await browser.close()
if __name__=='__main__':asyncio.run(main())
