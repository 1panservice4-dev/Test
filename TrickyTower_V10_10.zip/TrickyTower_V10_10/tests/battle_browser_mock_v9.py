from playwright.sync_api import sync_playwright
from pathlib import Path
html=(Path(__file__).resolve().parent.parent/'battle.html').read_text()
errors=[]
ws_stub='''Object.defineProperty(window,'sessionStorage',{configurable:true,value:{getItem:()=>null,setItem:()=>{},removeItem:()=>{}}});window._sent=[];window.WebSocket=class{static OPEN=1;constructor(url){this.url=url;this.readyState=1;queueMicrotask(()=>{if(this.onopen)this.onopen()})}send(data){window._sent.push(JSON.parse(data))}close(){this.readyState=3;if(this.onclose)this.onclose()}}'''
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
 for width,height,is_mobile,filename in [(1440,960,False,'/mnt/data/Tricky_Tower_V9_Battle_Desktop_Preview.png'),(390,844,True,'/mnt/data/Tricky_Tower_V9_Battle_Mobile_Preview.png')]:
  ctx=b.new_context(viewport={'width':width,'height':height},is_mobile=is_mobile,has_touch=is_mobile)
  page=ctx.new_page();page.on('pageerror',lambda e:errors.append(str(e)))
  page.evaluate("() => {"+ws_stub+"}");page.set_content(html,wait_until='load')
  page.wait_for_timeout(120)
  room={'id':'abc','name':'테트리스 배틀 테스트','state':'playing','players':[{'id':'a','name':'플레이어A','ready':True,'connected':True},{'id':'b','name':'플레이어B','ready':True,'connected':True}]}
  def player(piece, hp, lines,ap):
   return {'rows':[','.join(['' for i in range(10)]) for y in range(20)],'active':{'kind':'T','tiles':[[3,1,'R',''],[4,1,'Y',''],[5,1,'B',''],[4,0,'G','heal']]},'next':piece,'hold':'L','hp':hp,'ap':ap,'lines':lines,'topouts':0,'falls':1,'events':[{'id':1,'text':'BATTLE START'}],'seq':1}
  snapshot={'type':'battle_state','roomId':'abc','startAt':0,'serverAt':13000,'state':'playing','paused':False,'seconds':13,'probability':0.07,'winner':None,'reason':'','players':[player('Z',850,2,[4,2,1,8]),player('I',700,1,[7,2,5,9])]}
  page.evaluate('(r) => onMessage({type:"battle_joined",room:r,seatId:"a",seatToken:"tok",position:0})',room)
  page.evaluate('(s) => onMessage(s)',snapshot)
  page.wait_for_timeout(200)
  my=page.locator('#myBoard').bounding_box();op=page.locator('#opBoard').bounding_box()
  assert abs(my['y']-op['y'])<.5 and abs(my['height']-op['height'])<.5 and abs(my['width']-op['width'])<.5,(my,op)
  page.keyboard.press('Space')
  assert page.evaluate('() => _sent.some(m => m.type==="battle_input"&&m.action==="drop")')
  # feed 30 snapshots in 1000ms and assert Hz shows updates.
  page.evaluate('''async s => {for(let i=0;i<30;i++){onMessage(s);await new Promise(r=>setTimeout(r,34))}}''',snapshot)
  page.wait_for_timeout(200)
  assert 'FPS' in page.locator('#fps').inner_text()
  assert 'Hz' in page.locator('#hz').inner_text()
  assert not errors,errors
  page.screenshot(path=filename,full_page=True)
  print('PASS SCREEN',width, 'my board',my, 'op board',op, 'fps',page.locator('#fps').inner_text(),'hz',page.locator('#hz').inner_text())
  ctx.close()
 b.close()
print('PASS UI browser mock: 2 canvases aligned, correct grid, controls, FPS & Hz HUD, no JS errors')
