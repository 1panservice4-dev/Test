import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
const require=createRequire(import.meta.url),e=require('../battle_engine.js');
const tile=(c='R',s=null,id=null)=>({c,s,id});
const game=(n=3)=>{const g=e.newGame(0,()=>.35,n);g.clock=0;g.state='playing';return g};
const check=(name,fn)=>{fn();console.log('PASS V10.5',name)};
check('legacy 2P starts at 1000 HP; 3P starts at 2000 HP; invalid size rejected',()=>{
 assert.deepEqual(game(2).players.map(x=>x.hp),[1000,1000]);
 assert.deepEqual(game().players.map(x=>x.hp),[2000,2000,2000]);
 assert.throws(()=>e.newGame(0,Math.random,4));
});
check('gray row with the final red tile cannot attack even from previously held 9 AP',()=>{
 for(const n of [2,3]){
  const g=game(n),p=g.players[0];p.ap[0]=9;
  p.grid[19]=Array.from({length:10},(_,i)=>i===3?tile('R',null,444):tile('X'));
  e.checkRows(g,0);
  assert.equal(p.ap[0],9);assert.equal(p.lines,1);
  for(let j=1;j<n;j++)assert.equal(g.players[j].hp,g.maxHp);
  assert(!p.events.some(x=>x.kind==='attack'||x.kind==='ap_gain'));
 }
});
check('offensive special in grey garbage row does not attack',()=>{
 const g=game();g.players[0].grid[19]=Array.from({length:10},(_,i)=>i===1?tile('R','damage',555):tile('X'));
 e.checkRows(g,0);assert.deepEqual(g.players.map(p=>p.hp),[2000,2000,2000]);
 assert(!g.players[0].events.some(x=>x.kind==='damage'));
});
check('3P AP 10 of a color sends 100 damage to BOTH opponents',()=>{
 const g=game();e.gain(g,0,Array.from({length:10},()=>tile('R')));
 assert.deepEqual(g.players.map(p=>p.hp),[2000,1900,1900]);
 assert.equal(g.players[0].events.filter(x=>x.kind==='attack').length,2);
});
check('3P damage tile sends 50 to BOTH opponents',()=>{
 const g=game();g.players[0].grid[19]=Array.from({length:10},(_,x)=>tile(x<6?'Y':'G',x===0?'damage':null,777));e.checkRows(g,0);
 assert.equal(g.players[1].hp,1950);assert.equal(g.players[2].hp,1950);
});
check('3P grey-zone 2 cleared rows send 2 bottom garbage rows to EACH opponent',()=>{
 const g=game();for(const y of [18,19])g.players[0].grid[y]=Array.from({length:10},(_,x)=>tile('B',x===2?'grey':null,x===2?99:null));
 e.checkRows(g,0);
 for(const p of g.players.slice(1)){
  assert.equal(p.grid.length,20);
  for(const y of [18,19]){assert.equal(p.grid[y].filter(c=>c?.c==='X').length,9);assert.equal(p.grid[y].filter(c=>c===null).length,1)}
 }
 assert.equal(g.players[0].events.filter(x=>x.kind==='garbage').length,4);
});
check('heal affects owner only, capped at 2000',()=>{
 const g=game();g.players[0].hp=1980;g.players[0].grid[19]=Array.from({length:10},(_,x)=>tile(x<5?'G':'B',x===0?'heal':null,56));
 e.checkRows(g,0);assert.deepEqual(g.players.map(p=>p.hp),[2000,2000,2000]);
});
check('one eliminated player cannot act, other two continue, winner is last alive',()=>{
 const g=game();g.players[1].hp=50;e.hurt(g,1,50,'테스트');
 assert.equal(g.state,'playing');assert.equal(g.players[1].eliminated,true);
 assert.equal(e.input(g,1,'left'),false);
 e.gain(g,0,Array.from({length:10},()=>tile('G')));
 assert.equal(g.players[1].hp,0);assert.equal(g.players[2].hp,1900);
 e.hurt(g,2,1900,'최종 공격');assert.equal(g.state,'finished');assert.equal(g.winner,0);
});
check('normal 2P last-player winner is preserved',()=>{
 const g=game(2);e.hurt(g,1,1000,'테스트');assert.equal(g.state,'finished');assert.equal(g.winner,0);
});
check('3P snapshot is complete and 60Hz live snapshot remains lightweight',()=>{
 const g=game();const snap=e.snapshot(g),live=e.liveSnapshot(g);
 assert.equal(snap.maxHp,2000);assert.equal(snap.players.length,3);assert(snap.players.every(p=>p.rows.length===20));
 assert.equal(live.players.length,3);assert(live.players.every(p=>p.rows===undefined));
});
check('3P gray-topout costs 500 to each affected living opponent',()=>{
 const g=game();g.players[1].grid[0][0]=tile('R');g.players[2].grid[0][1]=tile('B');e.addGarbage(g,0);
 assert.deepEqual(g.players.map(p=>p.hp),[2000,1500,1500]);
});
console.log('STAGE 5 3P V10.5 ENGINE ALL PASS');
