import assert from 'node:assert/strict';
import {spawn} from 'node:child_process';
import {setTimeout as delay} from 'node:timers/promises';
import {fileURLToPath} from 'node:url';
import {dirname, resolve} from 'node:path';
const port = 18887;
const child = spawn(process.execPath, ['server.js'], {cwd: resolve(dirname(fileURLToPath(import.meta.url)),'..'), env: {...process.env,PORT:String(port),RECONNECT_GRACE_MS:'1800'}, stdio: ['ignore','pipe','pipe']});
let std='';child.stdout.on('data',x=>std+=x);child.stderr.on('data',x=>std+=x);
const root=`http://127.0.0.1:${port}`;
class Peer {
  constructor(ws){this.ws=ws;this.messages=[];this.waiters=[];ws.addEventListener('message',e=>{let m;try{m=JSON.parse(e.data)}catch{return}this.messages.push(m);this.dispatch()});}
  dispatch(){for(const x of [...this.waiters]){const i=this.messages.findIndex(x.test);if(i>=0){const msg=this.messages.splice(i,1)[0];this.waiters.splice(this.waiters.indexOf(x),1);clearTimeout(x.timer);x.ok(msg)}}}
  wait(type,filter=()=>true,ms=4000){return new Promise((ok,fail)=>{const x={test:m=>m.type===type&&filter(m),ok,timer:null};x.timer=setTimeout(()=>{this.waiters=this.waiters.filter(y=>y!==x);fail(Error(`wait ${type} timed out; received: ${JSON.stringify(this.messages.slice(-5))}`))},ms);this.waiters.push(x);this.dispatch()})}
  send(o){this.ws.send(JSON.stringify(o))}
  close(){this.ws.close()}
}
async function connect(){return new Promise((ok,fail)=>{const ws=new WebSocket(`ws://127.0.0.1:${port}`);const p=new Peer(ws);ws.addEventListener('open',()=>ok(p),{once:true});ws.addEventListener('error',()=>fail(Error('WebSocket connection failed')),{once:true})})}
try {
  let alive=false;
  for(let i=0;i<50;i++){try{const r=await fetch(root+'/health');if(r.ok){alive=true;break}}catch{} await delay(100)}
  assert(alive, 'health endpoint never became reachable');
  const health=await (await fetch(root+'/health')).json();assert.equal(health.version,'10.10.0');
  const html=await (await fetch(root)).text();assert(html.includes('TRICKY'));
  const a=await connect(),b=await connect();
  // Test clock sync before joining a room.
  a.send({type:'clock_probe',at:1234.5});
  const cs=await a.wait('clock_sync');
  assert.equal(cs.at,1234.5);assert(Math.abs(Date.now()-cs.serverNow)<1000);

  a.send({type:'create',nickname:'A',name:'테스트 방',stage:'height'});
  const joinedA=await a.wait('joined');assert.equal(joinedA.room.stage,'height');assert.equal(joinedA.room.players.length,1);
  b.send({type:'join',roomId:joinedA.roomId,nickname:'B'});
  const joinedB=await b.wait('joined');assert.equal(joinedB.room.players.length,2);
  a.send({type:'ready',ready:true});b.send({type:'ready',ready:true});
  await Promise.all([a.wait('match_start'),b.wait('match_start')]);
  await delay(3400);
  a.send({type:'snapshot',data:{height:5,placed:3,falls:0,time:2,cameraY:0,bodies:[['I',2,50,0,7]],piece:null}});
  const snap=await b.wait('snapshot');assert.equal(snap.data.height,5);assert.deepEqual(snap.data.bodies[0],['I',2,50,0,7]);
  // 20Hz target: expect at least 17 out of 20 snapshots received over ~1s on loopback.
  let received=0;
  const seq=Array.from({length:20},(_,i)=>i+100);
  for(const n of seq){
   a.send({type:'snapshot',data:{height:5,placed:n,falls:0,time:n/20,cameraY:0,bodies:[['I',2,50,0,n]],piece:null}});
   await delay(53);
  }
  for(const x of [...b.messages])if(x.type==='snapshot'&&x.data.placed>=100)received++;
  assert(received>=17,`20Hz snapshot relay lost too many frames: ${received}/20`);
  a.close();
  const offline=await b.wait('room',m=>m.room.players.some(x=>x.nickname==='A'&&x.connected===false));
  assert.equal(offline.room.players.length,2,'disconnected player should retain seat during grace');
  const a2=await connect();a2.send({type:'resume',token:joinedA.resumeToken});
  const resumed=await a2.wait('resumed');assert.equal(resumed.clientId,joinedA.clientId);assert.equal(resumed.room.players.length,2);
  await b.wait('room',m=>m.room.players.every(x=>x.connected===true));
  b.send({type:'snapshot',data:{height:9,placed:5,falls:0,time:5,cameraY:20,bodies:[['T',2,50,0,2]],piece:null}});
  assert.equal((await a2.wait('snapshot',m=>m.data.height===9)).data.height,9);
  a2.send({type:'finish',height:18,placed:55});b.send({type:'finish',height:21,placed:55});
  const [resA,resB]=await Promise.all([a2.wait('match_result'),b.wait('match_result')]);assert.equal(resA.winner,joinedB.clientId);assert.equal(resB.winner,joinedB.clientId);
  a2.send({type:'leave'});b.send({type:'leave'});
  await Promise.all([a2.wait('left'),b.wait('left')]);
  const clear=await (await fetch(root+'/health')).json();assert.equal(clear.rooms,0);
  a2.send({type:'create',nickname:'A',stage:'time'});
  const ta=await a2.wait('joined');b.send({type:'join',roomId:ta.roomId,nickname:'B'});
  await b.wait('joined');a2.send({type:'ready',ready:true});b.send({type:'ready',ready:true});
  await Promise.all([a2.wait('match_start'),b.wait('match_start')]);await delay(3400);
  a2.send({type:'finish',height:18,placed:9});
  const [timeA,timeB]=await Promise.all([a2.wait('match_result'),b.wait('match_result')]);assert.equal(timeA.winner,ta.clientId);assert.equal(timeB.winner,ta.clientId);
  a2.send({type:'leave'});b.send({type:'leave'});
  await Promise.all([a2.wait('left'),b.wait('left')]);
  // Unrecovered disconnect should result in a win after grace period.
  a2.send({type:'create',nickname:'A',stage:'time'});const ca=await a2.wait('joined');
  b.send({type:'join',roomId:ca.roomId,nickname:'B'});const cb=await b.wait('joined');
  a2.send({type:'ready',ready:true});b.send({type:'ready',ready:true});
  await Promise.all([a2.wait('match_start'),b.wait('match_start')]);
  a2.close();const abandon=await b.wait('match_result',()=>true,4000);assert.equal(abandon.winner,cb.clientId);
  b.close();console.log('PASS health, clock probe, room join, 20Hz snapshots, reconnect, height result, time result, disconnect timeout');
} catch (e) {console.error('FAIL',e.stack || e,'\nSERVER OUTPUT:',std);process.exitCode=1}
finally {child.kill('SIGTERM');await delay(100)}
