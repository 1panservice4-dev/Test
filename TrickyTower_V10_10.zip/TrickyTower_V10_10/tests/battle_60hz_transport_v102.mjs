import assert from 'node:assert/strict';
import {spawn} from 'node:child_process';
import {setTimeout as delay} from 'node:timers/promises';
const port=20000+Math.floor(Math.random()*30000),base=`http://127.0.0.1:${port}`;
const srv=spawn(process.execPath,['server.js'],{cwd:new URL('..',import.meta.url).pathname,env:{...process.env,PORT:String(port)},stdio:['ignore','pipe','pipe']});
let log='';srv.stdout.on('data',x=>log+=String(x));srv.stderr.on('data',x=>log+=String(x));
class C {
 constructor(){this.msgs=[]}
 async open(){this.ws=new WebSocket(`ws://127.0.0.1:${port}/battle-ws`);this.ws.onmessage=e=>{const m=JSON.parse(e.data);m._bytes=Buffer.byteLength(e.data);m._recv=performance.now();this.msgs.push(m)};await new Promise((r,j)=>{this.ws.addEventListener('open',r,{once:true});this.ws.addEventListener('error',j,{once:true})})}
 send(v){this.ws.send(JSON.stringify(v))}
 async wait(fn,max=9000){let end=performance.now()+max;while(performance.now()<end){const m=this.msgs.find(fn);if(m)return m;await delay(12)}throw Error('wait timeout '+this.msgs.slice(-2).map(m=>m.type))}
 close(){this.ws?.close()}
}
try{
 for(let i=0;i<80;i++){try{if((await fetch(base+'/health')).ok)break}catch{}await delay(35)}
 const a=new C(),b=new C();await a.open();await b.open();
 a.send({type:'battle_create',name:'A'});const joined=await a.wait(m=>m.type==='battle_joined');
 b.send({type:'battle_join',roomId:joined.room.id,name:'B'});await b.wait(m=>m.type==='battle_joined');
 a.send({type:'battle_ready',ready:true});b.send({type:'battle_ready',ready:true});
 await a.wait(m=>m.type==='battle_state'&&m.state==='playing');await b.wait(m=>m.type==='battle_state'&&m.state==='playing');
 a.msgs.length=0;b.msgs.length=0;
 await delay(2220);
 const pairs=[a,b].map(c=>c.msgs.filter(m=>m.type==='battle_state'&&m.state==='playing'));
 for(const frames of pairs){
  assert(frames.length>=115&&frames.length<=150,`60Hz frame count ${frames.length} / 2.22s`);
  assert(frames.every((m,i)=>i===0||m.frameId>frames[i-1].frameId),'ordering');
  const full=frames.filter(m=>m.full),lite=frames.filter(m=>!m.full);
  assert(full.length>=1&&lite.length>=100,`keyframe/live ${full.length}/${lite.length}`);
  assert(full.every(m=>m.players.every(p=>p.rows.length===20&&p.events)),'keyframe preserves grid/event');
  assert(lite.every(m=>m.players.every(p=>!p.rows&&!p.events)),'lite excludes rows/event logs');
  const liteAvg=lite.reduce((sum,m)=>sum+m._bytes,0)/lite.length;
  const fullAvg=full.reduce((sum,m)=>sum+m._bytes,0)/full.length;
  assert(liteAvg<fullAvg*.75,`packet savings lite=${liteAvg} full=${fullAvg}`);
  console.log('PASS 60Hz receiver',frames.length,'in 2.22s, lite/full bytes',liteAvg.toFixed(0),fullAvg.toFixed(0),'keyframes',full.length);
 }
 a.send({type:'battle_input',seq:1,action:'drop'});
 await a.wait(m=>m.type==='battle_state'&&m.players[0].seq===1&&m.players[0].falls===1);
 await b.wait(m=>m.type==='battle_state'&&m.players[0].seq===1&&m.players[0].falls===1);
 console.log('PASS both peers receive immediate post-drop board updates');
 a.close();await b.wait(m=>m.type==='battle_state'&&m.paused===true,2600);
 const c=new C();await c.open();c.send({type:'battle_resume',roomId:joined.room.id,seatToken:joined.seatToken});
 await c.wait(m=>m.type==='battle_joined');await c.wait(m=>m.type==='battle_state'&&m.full===true&&m.players[0].rows.length===20);
 await b.wait(m=>m.type==='battle_state'&&m.paused===false);
 console.log('PASS 60Hz disconnect / resume delivers full keyframe and unpauses');
 c.close();b.close();console.log('STAGE 5 60Hz TRANSPORT ALL PASS');
}finally{srv.kill('SIGTERM')}
