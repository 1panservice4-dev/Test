import asyncio
from real_game_bridge_v82 import api,setup
from playwright.async_api import async_playwright
async def status(p):
 return await p.evaluate('''() => ({ modals:[...document.querySelectorAll('.modal.show')].map(e=>e.id),prestart:document.documentElement.classList.contains('tt-online-prestart'),
 two:window.__TT_TWO_PHASE__?.(),four:window.__TT_FOUR_PHASE__?.(),fps:document.getElementById('ttFps')?.textContent,hz:document.getElementById('ttHz')?.textContent,
 bdisplay:getComputedStyle(document.querySelector('.board-wrap')).display,fdisplay:getComputedStyle(document.getElementById('fourBoardShell')).display })''')
async def test(browser,size):
 a=api('/api/ability/create',{'max':size,'name':f'V8.2 {size}P Browser','variant':'brawl'})
 seats=[a]+[api('/api/ability/join',{'roomId':a['roomId']}) for _ in range(size-1)]
 games=[]
 try:
  for x in seats:
   p,proxy,errors=await setup(browser,x['roomId'],x['seatToken'],x['mode'],x['role'],x['variant']);games.append((p,proxy,errors))
  await asyncio.sleep(5 if size==2 else 8)
  for i,(p,_,errors) in enumerate(games):
   state=await status(p);print(f'{size} BEFORE {i}',state,errors[:2],flush=True)
   assert state['prestart'] and (state['bdisplay']=='none' if size==2 else state['fdisplay']=='none'), 'board visible prematurely'
  if size==2:
   assert all('colorModal' in m['modals'] for m in [await status(p) for p,_,_ in games])
   await games[0][0].evaluate("()=>document.getElementById('pickWhiteBtn').click()")
   await asyncio.sleep(2)
   for i,(p,_,_) in enumerate(games):
    state=await status(p);print('2 COLOR',i,state,flush=True)
    assert state['prestart'] and 'augmentModal' in state['modals'], 'ability selection not shown or board visible after color'
   for i,(p,_,_) in enumerate(games):
    await p.evaluate("()=>document.querySelector('#augmentCards [data-ability]')?.click()")
    await asyncio.sleep(1.2)
  else:
   for i,(p,_,_) in enumerate(games):
    await p.evaluate(f"()=>document.getElementById('fourPick{['Red','Blue','Yellow','Green'][i]}').click()")
    await asyncio.sleep(.6)
   await asyncio.sleep(2)
   for i,(p,_,_) in enumerate(games):
    state=await status(p);print('4 COLOR',i,state,flush=True)
    assert state['prestart'] and 'fourAbilityModal' in state['modals'], '4P ability stage missing'
   for i,(p,_,_) in enumerate(games):
    await p.evaluate("()=>document.querySelector('#fourAbilityCards .four-ability-card')?.click()")
    await asyncio.sleep(.7)
  await asyncio.sleep(4 if size==2 else 6)
  for i,(p,proxy,errors) in enumerate(games):
   state=await status(p);print(f'{size} FINAL {i}',state,'JS errors:',errors[:2], 'relay errors:',proxy.errors[:2],flush=True)
   assert not state['prestart'], 'game did not reveal after draft'
   assert state['fps'].startswith('FPS') and state['hz'].startswith('SYNC')
   assert state['bdisplay']!='none' if size==2 else state['fdisplay']!='none'
  await games[0][0].screenshot(path=f'/mnt/data/V82_{size}P_game.png')
  print('PASS',size,'P browser state stages',flush=True)
 finally:
  for p,proxy,_ in games:
   try:await proxy.cleanup();await p.close()
   except:pass
async def main():
 async with async_playwright() as pw:
  browser=await pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
  try:
   await test(browser,2)
   await test(browser,4)
  finally:await browser.close()
if __name__=='__main__':asyncio.run(main())
