import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {setTimeout as delay} from 'node:timers/promises';
const require=createRequire(import.meta.url);
const engine=require('../battle_engine.js');
const createBattleNet=require('../battle_server.js');
const actualNew=engine.newGame;
engine.newGame=(start,rng)=>{
 const g=actualNew(Date.now()+65,()=>.2);
 // Prepare a legal full row with one Gray Zone cell to force a deterministic
 // effect on the first hard drop. Other rules and the server's 60Hz path run.
 g.players[0].grid[19]=Array.from({length:10},(_,i)=>({c:i===0?'B':'R',s:i===0?'grey':null,id:i===0?444:null}));
 g.players[1].grid[19][5]={c:'G',s:null,id:555};
 return g;
};
const net=createBattleNet({send:(peer,payload)=>peer.out.push(payload)});
const clients=[0,1].map(()=>({closed:false,socket:{end(){}},out:[]}));
const last=(peer,type)=>peer.out.filter(m=>m.type===type).at(-1);
try{
 for(const c of clients)net.connected(c);
 net.message(clients[0],{type:'battle_create',name:'A',roomName:'grey'});
 const rid=last(clients[0],'battle_joined').room.id;
 net.message(clients[1],{type:'battle_join',roomId:rid,name:'B'});
 assert.equal(last(clients[1],'battle_joined').position,1);
 net.message(clients[0],{type:'battle_ready',ready:true});
 net.message(clients[1],{type:'battle_ready',ready:true});
 await delay(155);
 assert.equal(last(clients[0],'battle_state').state,'playing');
 net.message(clients[0],{type:'battle_input',action:'drop',seq:1});
 const sa=last(clients[0],'battle_state'),sb=last(clients[1],'battle_state');
 assert(sa.full&&sb.full,'gray attack must send a full authoritative keyframe');
 assert.equal(sa.players[1].rows[19].split(',').filter(c=>c==='X').length,9);
 assert.equal(sb.players[1].rows[19].split(',').filter(c=>c==='X').length,9);
 assert.equal(sb.players[1].rows[18].split(',')[5],'G');
 const events=sb.players[1].events.filter(e=>e.kind==='garbage');
 assert.equal(events.length,1);assert.equal(events[0].gap,2);
 assert.equal(sa.players[0].seq,1);assert.equal(sb.players[0].seq,1);
 console.log('PASS 2-player Stage 5 public room: hard-drop Gray Zone -> both seats get 1 authoritative colorless bottom row, 1 hole, full keyframe');
 await delay(150);
 const fullB=clients[1].out.filter(x=>x.type==='battle_state');
 assert(fullB.length>=8,'60Hz frames should continue after gray attack');
 console.log('PASS server 60Hz loop continues after Gray Zone attack:',fullB.length,'packets');
}finally{net.shutdown();engine.newGame=actualNew;}
