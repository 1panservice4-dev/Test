import asyncio
from real_game_bridge import api,setup
from playwright.async_api import async_playwright
async def main():
 async with async_playwright() as pw:
  browser=await pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
  host=api('/api/ability/create',{'max':4,'name':'4p live','variant':'brawl'})
  seats=[host]+[api('/api/ability/join',{'roomId':host['roomId']}) for _ in range(3)]
  arr=[]
  try:
   for i,s in enumerate(seats):
    arr.append(await setup(browser,s['roomId'],s['seatToken'],s['mode'],s['role'],s['variant']))
    print('page',i,'ready',flush=True)
   await asyncio.sleep(5)
   for i,(p,proxy,errors) in enumerate(arr):
    stat=await p.evaluate("()=>({modal:[...document.querySelectorAll('.modal.show')].map(n=>n.id),joined:window.__FOUR_MULTIPLAYER_CORE__?.status?.().authenticated,connected:window.__FOUR_MULTIPLAYER_CORE__?.status?.().connected})")
    print('before',i,stat,'js errors',errors[:2],flush=True)
   for i,color in enumerate(['red','blue','yellow','green']):
    p=arr[i][0]
    info=await p.evaluate('''color=>{const el=document.getElementById('fourPick'+color);const s=getComputedStyle(el);el.click();return {disabled:el.disabled,display:s.display,opacity:s.opacity}}''',color.title())
    print('COLOR',i,color,info,flush=True)
    await asyncio.sleep(.5)
   await asyncio.sleep(5)
   for i,(p,proxy,errors) in enumerate(arr):
    stat=await p.evaluate("()=>({modal:[...document.querySelectorAll('.modal.show')].map(n=>n.id),status:window.__FOUR_MULTIPLAYER_CORE__?.status?.()})")
    print('after',i,'modals',stat['modal'],'color',stat['status']['color'],'phase',stat['status']['phase'],'joined',stat['status']['authenticated'], 'participants',len(stat['status']['participants']),flush=True)
    if i==0:await p.screenshot(path='/mnt/data/V8_4P_Actual_Color_Lobby.png')
  finally:
   for p,proxy,e in arr:
    try:await proxy.cleanup();await p.close()
    except:pass
   await browser.close()
asyncio.run(main())
