from playwright.sync_api import sync_playwright
from pathlib import Path
html=(Path(__file__).resolve().parent.parent/'battle.html').read_text()
errors=[]
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
 for seat in [0,1]:
  ctx=b.new_context(viewport={'width':1366,'height':920})
  page=ctx.new_page();page.on('pageerror',lambda e:errors.append(str(e)))
  page.evaluate('''() => {Object.defineProperty(window,'sessionStorage',{configurable:true,value:{getItem:()=>null,setItem:()=>{},removeItem:()=>{}}});window._sent=[];window.WebSocket=class{static OPEN=1;constructor(url){this.url=url;this.readyState=1;queueMicrotask(()=>this.onopen?.())}send(t){window._sent.push(JSON.parse(t))}}}''')
  page.set_content(html,wait_until='load')
  room={'id':'fx-room','name':'FX 1v1','state':'playing','players':[{'id':'a','name':'Alpha','ready':True,'connected':True},{'id':'b','name':'Beta','ready':True,'connected':True}]}
  rows=[','.join('' for i in range(10)) for _ in range(20)]
  events=[
   {'id':1,'text':'한 줄 제거','kind':'line_clear','owner':0,'y':19,'counts':[4,2,1,3],'double':False,'reason':'완성'},
   {'id':2,'text':'어택포인트','kind':'ap_gain','owner':0,'counts':[4,2,1,3],'source':'line','x':4.5,'y':19},
   {'id':3,'text':'폭탄','kind':'bomb','owner':0,'x':4,'y':18,'removed':3},
   {'id':4,'text':'폭발 AP','kind':'ap_gain','owner':0,'counts':[0,1,1,1],'source':'bomb','x':4,'y':18},
   {'id':5,'text':'공격','kind':'attack','owner':0,'target':1,'color':'R','amount':100},
   {'id':6,'text':'피해','kind':'hit','target':1,'amount':100},
   {'id':7,'text':'치유','kind':'heal','owner':0,'amount':75},
   {'id':8,'text':'모래','kind':'sand','owner':1,'rows':[17,18]},
   {'id':9,'text':'더블','kind':'double','owner':1,'y':18},
   {'id':10,'text':'피해 블록','kind':'damage','owner':1,'target':0,'x':4,'y':15},
  ]
  def makeplayer(hp):return {'rows':rows,'active':None,'next':'T','hold':None,'hp':hp,'ap':[4,2,1,3],'lines':1,'topouts':0,'falls':2,'events':events,'seq':1}
  state={'type':'battle_state','roomId':'fx-room','startAt':1000,'serverAt':5000,'state':'playing','paused':False,'seconds':4,'probability':.07,'winner':None,'reason':'','players':[makeplayer(850),makeplayer(900)]}
  page.evaluate('(data) => onMessage({type:"battle_joined",room:data.room,seatId:data.seat===0?"a":"b",seatToken:"tok",position:data.seat})',{'room':room,'seat':seat})
  page.evaluate('(s) => onMessage(s)',state)
  res=page.evaluate('''() => ({n:fxBoard.length,f:fxFlying.length,last:fxLastEvent,fx:!!document.getElementById('myFx'),fin:document.getElementById('resultBanner').hidden})''')
  assert res['n']>=7 and res['f']>=5 and res['last']==10 and res['fx'] and res['fin'],res
  page.evaluate('(s) => onMessage(s)',state)
  res2=page.evaluate('''() => ({n:fxBoard.length,f:fxFlying.length})''')
  assert res2['n']==res['n'] and res2['f']==res['f'],(res,res2)
  page.wait_for_timeout(250)
  assert page.locator('#match').is_visible()
  assert page.evaluate('() => document.getElementById("battleFxWorld").width>100')
  state['state']='finished';state['winner']=0;state['reason']='2P 체력 0 · 1P 승리!'
  page.evaluate('(s) => onMessage(s)',state)
  assert page.locator('#resultBanner').is_visible()
  assert page.locator('#resultTitle').inner_text()==('승리' if seat==0 else '패배')
  assert page.locator('#matchStatus').inner_text()=='경기 종료'
  assert page.locator('#myOverlay').is_hidden() and page.locator('#opOverlay').is_hidden()
  assert '승리' not in page.locator('#resultSub').inner_text()
  page.evaluate('(s) => onMessage(s)',state)
  assert page.locator('#resultBanner .result-title').count()==1
  page.screenshot(path='/mnt/data/Tricky_Tower_V10_1_FX_Test_'+('Winner' if seat==0 else 'Loser')+'.png',full_page=True)
  print('PASS',seat,'event FX',res,'dedupe 30Hz','result shown once',page.locator('#resultTitle').inner_text())
  ctx.close()
 assert not errors,errors
 b.close()
print('PASS event driven Chromium desktop 2 perspectives with no JS exceptions')
