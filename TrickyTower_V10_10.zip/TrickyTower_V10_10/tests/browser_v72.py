"""V7.2 browser DOM regression (network is validated separately by chess_online.mjs)."""
from pathlib import Path
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1]
html=(ROOT/'Chess_Tetris_V7_2_Standalone.html').read_text(encoding='utf-8')
with sync_playwright() as p:
 browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
 page=browser.new_page(viewport={'width':1320,'height':900})
 errors=[]
 page.on('pageerror', lambda exc: errors.append(str(exc)))
 # Use inline content to avoid localhost/file: navigation blocks in the testing sandbox.
 page.set_content(html,wait_until='load')
 page.locator('#localChoice').click()
 def label(n):return page.locator('#board .sq').nth(n).get_attribute('aria-label')
 assert page.locator('#board .sq').count()==64
 assert label(0).startswith('a8 ') and label(63).startswith('h1 '), (label(0),label(63))
 assert '파랑 아래' in page.locator('#perspectiveTag').inner_text()
 # Blue makes a move; local hotseat now rotates the entire viewport for red.
 page.locator('#board .sq[aria-label="e2 P"]').click()
 page.locator('#board .sq[aria-label="e3 ."]').click()
 assert label(0).startswith('h1 ') and label(63).startswith('a8 '),(label(0),label(63))
 assert '빨강 아래' in page.locator('#perspectiveTag').inner_text()
 assert page.locator('#board .sq[aria-label="e3 P"]').count()==1
 # Red player clicks the visual location to move; coordinates still refer to the same shared board.
 page.locator('#board .sq[aria-label="e7 p"]').click()
 page.locator('#board .sq[aria-label="e6 ."]').click()
 assert label(0).startswith('a8 ') and label(63).startswith('h1 ')
 assert page.locator('#board .sq[aria-label="e6 p"]').count()==1
 print('PASS local 2P visual orientation + legal moves across both perspectives')
 # Online simulated state: distinct fixed player viewpoints; shared game coordinates are unchanged.
 page.evaluate("mode='online';roomStatus='playing';connection=true;meSide=-1;draw()")
 assert label(0).startswith('h1 ') and label(63).startswith('a8 ')
 page.screenshot(path='/mnt/data/Tricky_Tower_V7_2_Red_View.png',full_page=True)
 page.evaluate("meSide=1;draw()")
 assert label(0).startswith('a8 ') and label(63).startswith('h1 ')
 page.screenshot(path='/mnt/data/Tricky_Tower_V7_2_Blue_View.png',full_page=True)
 print('PASS simulated 2-client online viewpoints: red-bottom and blue-bottom')
 # Ensure the rook mini-guide has max 3 radius and no old 4-square destinations.
 guide=page.locator('#movementGuide .move-card').nth(2)
 assert '최대 3칸' in guide.inner_text()
 assert guide.locator('.mini-cell').count()==49
 print('PASS 7x7 rook movement guide uses three-square limit')
 assert not errors,errors
 browser.close()
