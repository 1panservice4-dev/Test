import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
const require=createRequire(import.meta.url);
const e=require('../battle_engine.js');
const test=(name,fn)=>{fn();console.log('PASS grey persistent:',name)};
const cell=(c='R',s=null,id=null)=>({c,s,id});
const game=()=>{const g=e.newGame(0,()=>.31);g.state='playing';g.clock=0;return g};
const garb=g=>g.players[0].events.filter(x=>x.kind==='garbage');
const bottom=p=>p.grid.filter(row=>row.filter(v=>v?.c==='X').length===9).length;

test('one of two future lines cleared: same gray tetromino retains its power in the surviving row',()=>{
 const g=game(),p=g.players[0],opp=g.players[1];
 p.grid[18][0]=cell('R','grey',900);
 p.grid[19]=Array.from({length:10},(_,x)=>cell(x===0?'R':'B',x===0?'grey':null,x===0?900:null));
 assert.equal(e.checkRows(g,0),1);
 assert.equal(garb(g).length,1);
 assert.equal(bottom(opp),1);
 assert(p.grid[19][0]?.s==='grey','surviving half of Gray Zone piece must keep special');
 assert.equal(p.grid[19][0].id,900,'identity must remain intact');
 // Later fill the second row, in a separate lock/clear action.
 for(let x=1;x<10;x++)p.grid[19][x]=cell('G');
 assert.equal(e.checkRows(g,0),1);
 assert.equal(garb(g).length,2,'one bottom line per completed gray row, even across time');
 assert.equal(bottom(opp),2);
 assert.equal(opp.hp,1000);
 assert.equal(opp.grid[19].filter(Boolean).length,9);
 assert.equal(opp.grid[18].filter(Boolean).length,9);
 assert.equal(opp.grid[19][3],null);
 assert.equal(opp.grid[18][3],null);
});

test('real O tetromino: two gray cells per row keep effect for later separate completion',()=>{
 const g=game(),p=g.players[0],opp=g.players[1],id=1777;
 // A genuine 2x2 O-piece, all four cells are the SAME gray special piece.
 for(const y of [18,19])for(const x of [4,5])p.grid[y][x]=cell('G','grey',id);
 for(let x=0;x<10;x++)if(x!==4&&x!==5)p.grid[19][x]=cell('Y');
 assert.equal(e.checkRows(g,0),1);
 assert.equal(garb(g).length,1);
 assert.equal(p.grid[19][4]?.s,'grey');
 assert.equal(p.grid[19][5]?.s,'grey');
 for(let x=0;x<10;x++)if(x!==4&&x!==5)p.grid[19][x]=cell('B');
 assert.equal(e.checkRows(g,0),1);
 assert.equal(garb(g).length,2);
 assert.equal(bottom(opp),2);
});

test('two rows from same tetromino cleared simultaneously send 2 rows',()=>{
 const g=game(),p=g.players[0],opp=g.players[1];
 p.grid[18]=Array.from({length:10},(_,x)=>cell('Y',x===3?'grey':null,x===3?901:null));
 p.grid[19]=Array.from({length:10},(_,x)=>cell('Y',x===3?'grey':null,x===3?901:null));
 assert.equal(e.checkRows(g,0),2);
 assert.equal(garb(g).length,2);
 assert.equal(bottom(opp),2);
});

test('gray power remains after 2 separate clears but other specials still activate once only',()=>{
 const g=game(),p=g.players[0];
 // Same piece with two gray cells and two non-gray cells is not a real spawned
 // piece, so use two separate pieces and ensure non-gray single-use unchanged.
 p.grid[18][1]=cell('B','heal',902);
 p.grid[19]=Array.from({length:10},(_,x)=>cell('G',x===1?'heal':null,x===1?902:null));
 p.hp=700;e.checkRows(g,0);
 assert.equal(p.hp,775);
 assert.equal(p.grid[19][1].s,null,'heal must still be one-shot');
 for(let x=0;x<10;x++)if(x!==1)p.grid[19][x]=cell('G');
 e.checkRows(g,0);
 assert.equal(p.hp,775,'heal must not re-trigger on later line');
 assert.equal(garb(g).length,0);
});

test('gray tile itself has no attack color; each actual clear counted once',()=>{
 const g=game(),p=g.players[0],opp=g.players[1];
 p.grid[18][0]=cell('B','grey',910);
 p.grid[19]=Array.from({length:10},(_,x)=>cell('B',x===0?'grey':null,x===0?910:null));
 e.checkRows(g,0);assert.deepEqual(p.ap,[0,10-10,0,0]); // 10 blue AP triggers 100 damage
 assert.equal(opp.hp,900);
 assert.equal(p.grid[19][0].s,'grey');
 for(let x=1;x<10;x++)p.grid[19][x]=cell('B');
 e.checkRows(g,0);
 assert.equal(garb(g).length,2);
 assert.equal(opp.hp,800,'colored gray-zone special cells count normally; colorless garbage does not');
 assert.deepEqual(opp.ap,[0,0,0,0]);
});

test('snapshot serializes surviving gray cell with z suffix after first clear',()=>{
 const g=game(),p=g.players[0];
 p.grid[18][1]=cell('R','grey',999);
 p.grid[19]=Array.from({length:10},(_,x)=>cell('R',x===1?'grey':null,x===1?999:null));
 e.checkRows(g,0);
 assert.equal(e.snapshot(g).players[0].rows[19].split(',')[1],'Rz');
});
console.log('GREY PERSISTENCE V10.4 ALL PASS');
