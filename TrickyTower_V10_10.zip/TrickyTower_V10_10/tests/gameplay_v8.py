import asyncio,json
from real_game_bridge import setup,api
from playwright.async_api import async_playwright
async def main():
 async with async_playwright() as pw:
  b=await pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
  for size in [2,4]:
   host=api('/api/ability/create',{'max':size,'variant':'brawl'})
   seats=[host]+[api('/api/ability/join',{'roomId':host['roomId']}) for _ in range(size-1)]
   lst=[]
   try:
    for s in seats:lst.append(await setup(b,s['roomId'],s['seatToken'],s['mode'],s['role'],s['variant']))
    await asyncio.sleep(6 if size==2 else 9)
    for i,(page,proxy,errors) in enumerate(lst):
     state=await page.evaluate('''()=>({topModal:[...document.querySelectorAll('.modal.show')].map(n=>n.id),two:window.__CHAOS_MULTIPLAYER_DIAGNOSTICS__?._state.two,four:window.__FOUR_MULTIPLAYER_CORE__?.status?.()})''')
     print(f'{size}P BEFORE',i,'modal',state['topModal'],'2p role',state['two']['role'] if state['two'] else None,'4p role',state['four']['mode'])
    if size==2:
     print('click 2p side choice host white')
     await lst[0][0].locator('#pickWhiteBtn').click(timeout=4000)
    else:
     print('click 4p color red/blue/yellow/green')
     for i,color in enumerate(['red','blue','yellow','green']):
      page=lst[i][0];loc=page.locator(f'#fourPick{color.title()}')
      try:await loc.click(timeout=4000)
      except Exception as e:print('click fail',color,str(e)[:250])
      await asyncio.sleep(.4)
    await asyncio.sleep(6)
    for i,(page,proxy,errors) in enumerate(lst):
     state=await page.evaluate('''()=>({modal:[...document.querySelectorAll('.modal.show')].map(n=>n.id),two:window.__CHAOS_MULTIPLAYER_DIAGNOSTICS__?._state.two,four:window.__FOUR_MULTIPLAYER_CORE__?.status?.()})''')
     print(f'{size}P AFTER',i,'modal',state['modal'],'connected:',state['two']['authenticated'] if size==2 else state['four']['connected'],'color',state['four'].get('color') if size==4 else 'two')
     if i==0:await page.screenshot(path=f'/mnt/data/V8_{size}P_After_Color.png')
   finally:
    for page,proxy,errs in lst:
     await proxy.cleanup();await page.close()
  await b.close()
asyncio.run(main())
