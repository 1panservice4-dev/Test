import assert from 'node:assert/strict';
import {spawn} from 'node:child_process';
import {setTimeout as delay} from 'node:timers/promises';
const port=14000+Math.floor(Math.random()*30000),base=`http://127.0.0.1:${port}`;
const server=spawn(process.execPath,['server.js'],{cwd:new URL('..',import.meta.url).pathname,env:{...process.env,PORT:String(port)},stdio:['ignore','pipe','pipe']});
server.on('error',err=>{console.error(err)});
let logs='';server.stdout.on('data',b=>logs+=b.toString());server.stderr.on('data',b=>logs+=b.toString());
class Client{
 constructor(){this.events=[];this.ws=null;this.listeners=[]}
 async connect(){this.ws=new WebSocket(`ws://127.0.0.1:${port}/battle-ws`);this.ws.onmessage=event=>{const m=JSON.parse(event.data);this.events.push(m);for(const l of this.listeners)l()};await new Promise((resolve,reject)=>{this.ws.addEventListener('open',resolve,{once:true});this.ws.addEventListener('error',reject,{once:true})})}
 send(obj){this.ws.send(JSON.stringify(obj))}
 async next(check,timeout=5500){let found=this.events.findIndex(check);if(found>=0)return this.events.splice(found,1)[0];return await new Promise((resolve,reject)=>{const t=setTimeout(()=>{this.listeners=this.listeners.filter(x=>x!==wake);reject(Error('Timed out waiting '+String(check)+' events: '+this.events.slice(-3).map(x=>x.type)))},timeout);const wake=()=>{let idx=this.events.findIndex(check);if(idx<0)return;clearTimeout(t);this.listeners=this.listeners.filter(x=>x!==wake);resolve(this.events.splice(idx,1)[0])};this.listeners.push(wake)})}
 clear(){this.events.length=0}
 close(){this.ws?.close()}
}
async function start(){
 try{
 for(let i=0;i<75;i++){try{if((await fetch(base+'/health')).ok)break}catch{}await delay(60)}
 const home=await (await fetch(base+'/')).text();assert(home.includes('STAGE 05'));assert(home.includes('/battle.html'));
 const battle=await (await fetch(base+'/battle.html?x=test')).text();assert(battle.includes('TETRIS BATTLE'));assert(battle.includes('width="300" height="600"'));
 assert.equal((await (await fetch(base+'/health')).json()).version,'10.10.0');
 console.log('PASS HTTP routes + 5 stages preserved');
 const a=new Client(),b=new Client();await a.connect();await b.connect();await a.next(m=>m.type==='battle_hello');await b.next(m=>m.type==='battle_hello');
 a.send({type:'battle_create',name:'호스트',roomName:'테트리스 2인'});const joinedA=await a.next(m=>m.type==='battle_joined');assert.equal(joinedA.position,0);assert.equal(joinedA.room.players.length,1);
 b.send({type:'battle_list'});let rooms=await b.next(m=>m.type==='battle_rooms'&&m.rooms.some(r=>r.id===joinedA.room.id));assert.equal(rooms.rooms[0].count,1);
 b.send({type:'battle_join',roomId:joinedA.room.id,name:'게스트'});const joinedB=await b.next(m=>m.type==='battle_joined');assert.equal(joinedB.position,1);
 console.log('PASS public room create / list / no password join');
 a.send({type:'battle_ready',ready:true});b.send({type:'battle_ready',ready:true});await a.next(m=>m.type==='battle_start');await b.next(m=>m.type==='battle_start');
 const s0=await a.next(m=>m.type==='battle_state'&&m.state==='playing',7500);const s1=await b.next(m=>m.type==='battle_state'&&m.state==='playing',7500);
 assert.equal(s0.players.length,2);assert.equal(s1.players.length,2);assert(s0.players[0].rows.length===20&&s0.players[1].rows.length===20);
 assert(s0.players.every(p=>p.rows.every(r=>r.split(',').length===10)));
 console.log('PASS two player synchronized game start + 10x20');
 a.clear();await delay(1250);let ticks=a.events.filter(m=>m.type==='battle_state').length;assert(ticks>=58&&ticks<=87,`expected ~60Hz got ${ticks}`);
 console.log('PASS authoritative 60Hz lightweight states:',ticks,'/ 1.25 s');
 a.send({type:'battle_input',action:'drop',seq:1});const droppedA=await a.next(m=>m.type==='battle_state'&&m.state==='playing'&&m.players[0].seq===1);
 assert.equal(droppedA.players[0].falls,1);assert.equal(droppedA.players[1].falls,0);
 b.send({type:'battle_input',action:'drop',seq:1});const droppedB=await b.next(m=>m.type==='battle_state'&&m.state==='playing'&&m.players[1].seq===1);
 assert.equal(droppedB.players[1].falls,1);
 console.log('PASS independent turns, server action validation');
 b.clear();a.close();const paused=await b.next(m=>m.type==='battle_state'&&m.paused===true,3000);assert(paused);
 const res=new Client();await res.connect();await res.next(m=>m.type==='battle_hello');res.send({type:'battle_resume',roomId:joinedA.room.id,seatToken:joinedA.seatToken});
 const resumed=await res.next(m=>m.type==='battle_joined');assert.equal(resumed.position,0);
 await b.next(m=>m.type==='battle_state'&&m.paused===false,3500);
 res.send({type:'battle_input',action:'left',seq:2});const inputAfter=await res.next(m=>m.type==='battle_state'&&m.players[0].seq>=2,2200);assert(inputAfter);
 console.log('PASS disconnect pauses, reconnect recovers, gameplay resumes');
 res.send({type:'battle_leave'});const ended=await b.next(m=>m.type==='battle_state'&&m.state==='finished',3000);assert.equal(ended.winner,1);
 console.log('PASS leave-forfeit result + server authority');
 b.close();res.close();console.log('BATTLE ONLINE ALL PASS');
 }finally{server.kill('SIGTERM')}
}
await start();
