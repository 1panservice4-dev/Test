import asyncio
from real_game_bridge import api,setup
from playwright.async_api import async_playwright
async def main():
 async with async_playwright() as pw:
  browser=await pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
  room=api('/api/ability/create',{'max':2,'name':'2p full gameplay'})
  other=api('/api/ability/join',{'roomId':room['roomId']})
  arr=[]
  try:
   for s in (room,other):arr.append(await setup(browser,s['roomId'],s['seatToken'],s['mode'],s['role'],s['variant']))
   await asyncio.sleep(4)
   await arr[0][0].evaluate("()=>document.getElementById('pickWhiteBtn').click()")
   await asyncio.sleep(3)
   for i,(p,proxy,err) in enumerate(arr):
    print('BEFORE 2P',i,await p.evaluate("()=>({auth:window.__CHAOS_MULTIPLAYER_DIAGNOSTICS__?._state?.two?.authenticated, cards:document.querySelectorAll('#augmentCards .card-choice').length, modals:[...document.querySelectorAll('.modal.show')].map(x=>x.id)})"),flush=True)
    await p.evaluate("()=>document.querySelector('#augmentCards .card-choice')?.click()")
    await asyncio.sleep(1.5)
   await asyncio.sleep(4)
   for i,(p,proxy,err) in enumerate(arr):
    print('AFTER 2P',i,await p.evaluate("()=>({auth:window.__CHAOS_MULTIPLAYER_DIAGNOSTICS__?._state?.two?.authenticated, version:window.__CHAOS_MULTIPLAYER_DIAGNOSTICS__?._state?.two?.stateVersion, modals:[...document.querySelectorAll('.modal.show')].map(x=>x.id), board:document.querySelectorAll('.square').length, title:document.querySelector('.status strong')?.textContent})"),'errors',err[:2],proxy.errors[:2],flush=True)
   await arr[0][0].screenshot(path='/mnt/data/V8_2P_Ability_Ready.png')
  finally:
   for p,proxy,e in arr:
    try:await proxy.cleanup();await p.close()
    except:pass
   await browser.close()
if __name__=='__main__':asyncio.run(main())
