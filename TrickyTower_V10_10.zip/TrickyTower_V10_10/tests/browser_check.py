import asyncio, subprocess, time, os, urllib.request, traceback
from playwright.async_api import async_playwright
ROOT='/mnt/data/Chess_Tetris_V6'
PORT='18965'
p=subprocess.Popen(['node','server.js'],cwd=ROOT,env={**os.environ,'PORT':PORT},stdout=subprocess.PIPE,stderr=subprocess.PIPE)
try:
 for _ in range(40):
  try:
   with urllib.request.urlopen(f'http://127.0.0.1:{PORT}/health',timeout=.5) as f:
    print('HEALTH',f.read().decode());break
  except Exception:time.sleep(.12)
 else:raise RuntimeError('no server')
 async def run():
  async with async_playwright() as pw:
   browser=await pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
   page=await browser.new_page(viewport={'width':1280,'height':950},device_scale_factor=1)
   errors=[]
   page.on('pageerror',lambda e:errors.append(str(e)))
   await page.goto(f'http://127.0.0.1:{PORT}/chess.html',wait_until='domcontentloaded',timeout=15000)
   await page.screenshot(path=ROOT+'/preview_v6_lobby.png',full_page=True)
   await page.locator('#localChoice').click()
   assert await page.locator('#board button.sq').count()==64
   assert await page.locator('#movementGuide .move-card').count()==6
   # Blue pawn at e2 -- should have available moves to d3,e3,f3 but NOT e4.
   await page.locator('button.sq[aria-label="e2 P"]').click()
   for sq in ['d3','e3','f3']:
    assert 'target' in (await page.locator('button.sq[aria-label="'+sq+' ."]').get_attribute('class'))
   assert 'target' not in (await page.locator('button.sq[aria-label="e4 ."]').get_attribute('class'))
   await page.screenshot(path=ROOT+'/preview_v6_moves.png',full_page=True)
   await page.locator('button.sq[aria-label="e3 ."]').click()
   assert '빨강 차례' in await page.locator('#turnText').inner_text()
   # Check king icon is ordinary chess symbol, and queen isn't crowned.
   king_html=await page.locator('button.sq[aria-label="e1 K"]').inner_html()
   assert '♚' in king_html
   queen_html=await page.locator('button.sq[aria-label="d1 Q"]').inner_html()
   assert '♚' not in queen_html
   await page.screenshot(path=ROOT+'/preview_v6_game.png',full_page=True)
   print('BROWSER: desktop 64 squares; 6 movement diagrams; pawn target pattern; turn transition; king shape; errors=',errors)
   assert not errors,errors
   mob=await browser.new_page(viewport={'width':390,'height':844},device_scale_factor=1)
   mobile_err=[];mob.on('pageerror',lambda e:mobile_err.append(str(e)))
   await mob.goto(f'http://127.0.0.1:{PORT}/chess.html',wait_until='domcontentloaded')
   await mob.locator('#localChoice').click()
   await mob.screenshot(path=ROOT+'/preview_v6_mobile.png',full_page=True)
   assert await mob.locator('#board button.sq').count()==64
   assert not mobile_err,mobile_err
   print('BROWSER: mobile 390px/64 square validated')
   await browser.close()
 asyncio.run(run())
finally:
 p.terminate()
 try:p.wait(timeout=3)
 except subprocess.TimeoutExpired:p.kill()
