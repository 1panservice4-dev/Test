import asyncio,os,json,time
from playwright.async_api import async_playwright
BASE=os.environ.get('BASE','http://127.0.0.1:8787')
async def main():
 async with async_playwright() as p:
  browser=await p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
  page=await browser.new_page(viewport={'width':1365,'height':900});errs=[]
  page.on('pageerror',lambda e:errs.append(str(e)))
  try:
   await page.goto(BASE+'/index.html',timeout=20000)
   print('MAIN',await page.title(),'cards',await page.locator('.stage-chooser-card').count())
   await page.screenshot(path='/mnt/data/v8_portal.png')
   await page.locator('#quickStage4').click()
   print('LOBBY',await page.url,await page.locator('input[name=party]').count())
   await page.screenshot(path='/mnt/data/v8_lobby.png')
   await page.locator('#create').click()
   await page.wait_for_url('**/ability_chess.html?*',timeout=15000)
   print('ABILITY_URL',await page.url[:120] if False else page.url[:120])
   await page.wait_for_timeout(3800)
   print('ABILITY_TITLE',await page.title(),'error',errs[:5], 'online', await page.evaluate('typeof window.__ABILITY_AUTO_TWO__'), 'has ws',await page.evaluate('!!window.Peer'))
   print('host UI',await page.locator('#multiWaitingView').get_attribute('style'))
   await page.screenshot(path='/mnt/data/v8_ability_host.png')
  except Exception as e:print('TEST ERROR',repr(e),'browser errors',errs[:10]);await page.screenshot(path='/mnt/data/v8_error.png')
  await browser.close()
asyncio.run(main())
