from pathlib import Path
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1]
html=(ROOT/'hybrid.html').read_text(encoding='utf-8')
engine=(ROOT/'hybrid_engine.js').read_text(encoding='utf-8')
page_html=html.replace('<script src="/hybrid_engine.js"></script>', '<script>'+engine+'</script>')
with sync_playwright() as pw:
 browser=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage','--disable-gpu'])
 for width in [1280,420]:
  context=browser.new_context(viewport={'width':width,'height':900});page=context.new_page()
  errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
  page.set_content(page_html,wait_until='domcontentloaded')
  page.locator('#tetrisCard').click();assert page.locator('#tetrisCard').get_attribute('aria-pressed')=='true'
  page.locator('#localBtn').click()
  assert '백 차례' in page.locator('#turnText').inner_text()
  assert '테트리스 체스' in page.locator('#perspective').inner_text()
  assert page.locator('#board button.sq').count()==64
  page.locator('[aria-label^="a1 "]').click();assert page.locator('#board .target').count()>0
  page.locator('[aria-label^="a4 "]').click()
  assert '흑 차례' in page.locator('#turnText').inner_text()
  assert '흑 진영' in page.locator('#perspective').inner_text()
  page.locator('[aria-label^="e7 "]').click();page.locator('[aria-label^="e5 "]').click()
  assert '백 차례' in page.locator('#turnText').inner_text()
  page.locator('#undoBtn').click();assert '흑 차례' in page.locator('#turnText').inner_text()
  page.locator('#restartBtn').click();assert '백 차례' in page.locator('#turnText').inner_text()
  if width==1280:
   page.screenshot(path=str(ROOT/'Stage6_Local_Board_Desktop.png'),full_page=True)
  else:
   page.screenshot(path=str(ROOT/'Stage6_Local_Board_Mobile.png'),full_page=True)
  assert not errors,errors
  print('PASS Chromium offline local '+str(width)+'px: faction picker, tetris jump, classic pawn, perspective change, undo/restart; no JS errors')
  context.close()
 # capture selection screen
 context=browser.new_context(viewport={'width':1180,'height':820});page=context.new_page();page.set_content(page_html,wait_until='domcontentloaded');page.screenshot(path=str(ROOT/'Stage6_Faction_Selection.png'),full_page=True)
 browser.close()
