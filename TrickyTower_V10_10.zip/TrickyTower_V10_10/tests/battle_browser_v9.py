from playwright.sync_api import sync_playwright
from pathlib import Path
import subprocess,time,os,json
root=Path(__file__).resolve().parent.parent
port=18894
proc=subprocess.Popen(['node','server.js'],cwd=root,env={**os.environ,'PORT':str(port)},stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
errors=[]
try:
 with sync_playwright() as p:
  browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage','--disable-web-security'])
  ca=browser.new_context(viewport={'width':1440,'height':960},device_scale_factor=1)
  cb=browser.new_context(viewport={'width':1440,'height':960},device_scale_factor=1)
  a=ca.new_page();b=cb.new_page()
  a.on('pageerror',lambda e:errors.append('A '+str(e)))
  b.on('pageerror',lambda e:errors.append('B '+str(e)))
  base=f'http://127.0.0.1:{port}'
  a.goto(base+'/battle.html',wait_until='domcontentloaded',timeout=18000);b.goto(base+'/battle.html',wait_until='domcontentloaded',timeout=18000)
  a.get_by_text('● 서버 연결',exact=True).wait_for(timeout=10000)
  b.get_by_text('● 서버 연결',exact=True).wait_for(timeout=10000)
  a.locator('#nick').fill('PlayerA');a.locator('#roomName').fill('V9 공개방');a.locator('#create').click()
  a.locator('#waiting').wait_for(state='visible',timeout=5000)
  b.locator('#nick').fill('PlayerB');b.locator('#refresh').click();b.locator('.room-card button').first.wait_for(state='visible',timeout=5000);b.locator('.room-card button').first.click()
  b.locator('#waiting').wait_for(state='visible',timeout=5000)
  a.locator('#ready').click();b.locator('#ready').click()
  a.wait_for_function("() => latest && latest.state==='playing'",timeout=8000)
  b.wait_for_function("() => latest && latest.state==='playing'",timeout=8000)
  a.keyboard.press('Space')
  a.wait_for_function("() => latest && latest.players[meIndex].falls>=1",timeout=2500)
  b.wait_for_function("() => latest && latest.players[1-meIndex].falls>=1",timeout=2500)
  a.wait_for_timeout(1250)
  # board alignment: top and height should match pixel-for-pixel.
  m=a.locator('#myBoard').bounding_box();o=a.locator('#opBoard').bounding_box()
  assert abs(m['y']-o['y'])<2,(m,o)
  assert abs(m['height']-o['height'])<2,(m,o)
  assert abs(m['width']-o['width'])<2,(m,o)
  stat=a.evaluate("() => ({fps:document.getElementById('fps').textContent,hz:document.getElementById('hz').textContent,me:meIndex,first:latest.players[meIndex].falls,opp:latest.players[1-meIndex].falls,grid:latest.players[meIndex].rows.length})")
  print('DESKTOP',stat,'alignment',m,o)
  assert stat['grid']==20 and stat['first']>=1 and stat['opp']==0
  assert int(stat['hz'].split()[0])>=22,stat
  assert int(stat['fps'].split()[0])>=20,stat
  a.screenshot(path='/mnt/data/Tricky_Tower_V9_Battle_Desktop_Preview.png',full_page=True)
  # Android-like small viewport, boards remain in same row and equal heights.
  cm=browser.new_context(viewport={'width':390,'height':844},device_scale_factor=1,is_mobile=True,has_touch=True)
  mobile=cm.new_page();mobile.on('pageerror',lambda e:errors.append('M '+str(e)))
  mobile.goto(base+'/battle.html',wait_until='domcontentloaded');mobile.wait_for_timeout(1500)
  mobile.screenshot(path='/mnt/data/Tricky_Tower_V9_Battle_Mobile_Preview.png',full_page=True)
  # Check mobile CSS directly (match hidden on this phone; sizes still computed).
  mm=mobile.locator('#myBoard').bounding_box();mo=mobile.locator('#opBoard').bounding_box()
  assert abs(mm['y']-mo['y'])<2 and abs(mm['height']-mo['height'])<2,(mm,mo)
  print('MOBILE',mm,mo)
  assert not errors,errors
  print('PASS two real Chromium browsers: public room -> 2P match -> real drop -> 30Hz HUD -> aligned boards -> mobile layout. JS errors: 0')
  browser.close()
finally:
 proc.terminate();
 try:proc.wait(timeout=5)
 except:proc.kill()
 if proc.returncode not in (0,-15,1):print('SERVER EXIT',proc.returncode)
