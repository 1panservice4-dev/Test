import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {setTimeout as delay} from 'node:timers/promises';
const require=createRequire(import.meta.url);
const engine=require('../battle_engine.js');
const networkFactory=require('../battle_server.js');
const originalNew=engine.newGame;
let game;
engine.newGame=()=>{
 game=originalNew(Date.now()+65,()=>.3);
 // One physically continuous gray tetromino has a gray cell in each of two
 // vertically adjacent rows. Only the lower row is complete at first.
 for(const x of [0,1])game.players[0].grid[18][x]={c:'R',s:'grey',id:2026};
 game.players[0].grid[19]=Array.from({length:10},(_,x)=>({c:x<=1?'R':'Y',s:x<=1?'grey':null,id:x<=1?2026:null}));
 return game;
};
const net=networkFactory({send:(peer,message)=>peer.out.push(message)});
const clients=[0,1].map(()=>({closed:false,socket:{end(){}},out:[]}));
const last=(c,type)=>c.out.filter(x=>x.type===type).at(-1);
const history=(c,type)=>c.out.filter(x=>x.type===type);
try{
 for(const c of clients)net.connected(c);
 net.message(clients[0],{type:'battle_create',name:'A',roomName:'persistent gray'});
 const roomId=last(clients[0],'battle_joined').room.id;
 net.message(clients[1],{type:'battle_join',roomId,name:'B'});
 net.message(clients[0],{type:'battle_ready',ready:true});
 net.message(clients[1],{type:'battle_ready',ready:true});
 await delay(170);
 assert.equal(last(clients[1],'battle_state').state,'playing');
 // First full-row removal through the *real game input protocol*.
 net.message(clients[0],{type:'battle_input',seq:1,action:'drop'});
 assert.equal(game.players[0].events.filter(e=>e.kind==='garbage').length,1);
 assert.equal(game.players[0].grid[19][0].s,'grey');
 assert.equal(last(clients[0],'battle_state').players[0].rows[19].split(',')[0],'Rz');
 assert.equal(last(clients[1],'battle_state').players[0].rows[19].split(',')[0],'Rz');
 assert.equal(last(clients[1],'battle_state').players[1].rows[19].split(',').filter(x=>x==='X').length,9);
 // A later, separate line completion with the surviving same special piece.
 for(let x=2;x<10;x++)game.players[0].grid[19][x]={c:'G',s:null,id:null};
 net.message(clients[0],{type:'battle_input',seq:2,action:'drop'});
 assert.equal(game.players[0].events.filter(e=>e.kind==='garbage').length,2);
 for(const peer of clients){
  const state=last(peer,'battle_state');
  assert.equal(state.full,true);
  const rows=state.players[1].rows.map(row=>row.split(','));
  assert.equal(rows[19].filter(v=>v==='X').length,9);
  assert.equal(rows[18].filter(v=>v==='X').length,9);
  assert.equal(state.players[0].seq,2);
 }
 assert(history(clients[0],'battle_state').length>2);
 await delay(140);
 assert(last(clients[0],'battle_state').frameId>1);
 console.log('PASS public 2P: gray piece survives first clear, second clear sends second bottom row, both receive same authoritative full snapshots and 60Hz stream continues');
}finally{net.shutdown();engine.newGame=originalNew;}
