import assert from 'node:assert/strict';
import {spawn} from 'node:child_process';
import {setTimeout as delay} from 'node:timers/promises';
import {fileURLToPath} from 'node:url';
import {resolve,dirname} from 'node:path';

// Run against an isolated instance: no external services or room-code input required.
const port=19271, root=`http://127.0.0.1:${port}`;
const child=spawn(process.execPath,['server.js'],{cwd:resolve(dirname(fileURLToPath(import.meta.url)),'..'),env:{...process.env,PORT:String(port)},stdio:['ignore','pipe','pipe']});
let stderr='';child.stderr.on('data',x=>stderr+=x);child.stdout.on('data',x=>stderr+=x);
const get=async path=>fetch(root+path);
const post=async(path,obj)=>{const r=await fetch(root+path,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(obj)});assert.equal(r.status,200,`${path}: HTTP ${r.status}`);return r.json()};
function event(ws,test=()=>true,limit=4000){return new Promise((ok,fail)=>{const timer=setTimeout(()=>{ws.removeEventListener('message',onMessage);fail(Error('WebSocket message timeout'))},limit);function onMessage(e){let m;try{m=JSON.parse(e.data)}catch{return}if(test(m)){clearTimeout(timer);ws.removeEventListener('message',onMessage);ok(m)}}ws.addEventListener('message',onMessage)})}
async function connect(room,seat){
 const ws=new WebSocket(`ws://127.0.0.1:${port}/ability-ws?room=${encodeURIComponent(room)}&seat=${encodeURIComponent(seat)}`);
 await new Promise((ok,fail)=>{ws.addEventListener('open',ok,{once:true});ws.addEventListener('error',()=>fail(Error('websocket open error')),{once:true})});
 // Server sends ability_ready on socket creation; it may arrive before this function resumes. Checking open is enough to validate upgrade.
 return ws;
}
try{
 let ready=false;for(let i=0;i<50;i++){try{if((await get('/health')).ok){ready=true;break}}catch{}await delay(100)}assert(ready,'server not running');
 const routes=['/','/index.html','/ability_lobby.html','/ability_chess.html?local=2','/ability_chess.html?local=4','/ability_transport.js?v=8.1','/chess.html?stage=3'];
 for(const route of routes){const r=await get(route);assert.equal(r.status,200,route);const body=await r.text();assert(!/^Not found\s*$/.test(body),route);assert(body.length>100,route);console.log('PASS GET',route)}
 for(const max of [2,4]){
  const a=await post('/api/ability/create',{name:`V8.1 ${max} player test`,max,variant:'brawl'});
  assert(a.roomId&&a.seatToken);
  const gameRoute=`/ability_chess.html?room=${encodeURIComponent(a.roomId)}&seat=${encodeURIComponent(a.seatToken)}&role=host&mode=${a.mode}`;
  const page=await get(gameRoute);assert.equal(page.status,200);const html=await page.text();assert(html.includes('entryChoiceModal'),'host game page not loaded');
  const owner=await connect(a.roomId,a.seatToken);
  owner.send(JSON.stringify({type:'peer_register',peerId:`chaos-chess-v20-37-${max===4?'four':'two'}-${a.roomId}`}));
  const registered=await event(owner,m=>m.type==='peer_registered');assert(registered.peerId.endsWith(a.roomId));
  let listing=await(await get('/api/ability/rooms')).json();assert(listing.rooms.some(x=>x.id===a.roomId),'room missing from public list after host registration');
  const guests=[];
  try{
   for(let i=0;i<max-1;i++){
     const b=await post('/api/ability/join',{roomId:a.roomId});assert(b.seatToken);
     const join=await get(`/ability_chess.html?room=${encodeURIComponent(b.roomId)}&seat=${encodeURIComponent(b.seatToken)}&role=guest&mode=${b.mode}`);
     assert.equal(join.status,200,'guest game 404');
     guests.push(await connect(b.roomId,b.seatToken));
   }
   listing=await(await get('/api/ability/rooms')).json();assert(!listing.rooms.some(x=>x.id===a.roomId),'full room still shown');
   console.log(`PASS ${max}P public create/join and game-page navigation + websocket`);
  }finally{for(const g of guests)g.close();owner.close()}
 }
 console.log('ALL V8.1 QUERY-ROUTE REGRESSION TESTS PASSED');
}catch(e){console.error('REGRESSION FAIL',e,'\nSERVER:',stderr);process.exitCode=1}
finally{child.kill('SIGTERM');await delay(120)}
