import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
const require=createRequire(import.meta.url), E=require('../hybrid_engine.js');
const found=(s,a,b,promo='')=>E.legal(s).find(m=>E.moveKey(m)===a+b+promo);
const tetris=(white=true)=>E.initial(white?'tetris':'classic',white?'classic':'tetris');
const clear=(s)=>{s.b.fill('.');s.b[E.idx('e1')]='K';s.b[E.idx('e8')]='k';s.c=0;s.ep=-1;s.t=1;return s;};
function perft(s,d){if(!d)return 1;return E.legal(s).reduce((a,m)=>a+perft(E.apply(s,m),d-1),0);}
for(let i=1;i<=3;i++)assert.equal(perft(E.initial('classic','classic'),i),[0,20,400,8902][i]);
let s=E.initial('classic','tetris');
assert.ok(found(s,'e2','e4'),'orthodox pawn two squares');
assert.equal(found(s,'e2','f3'),undefined,'orthodox pawn cannot diagonal to empty');
assert.equal(found(s,'a1','a3'),undefined,'orthodox rook cannot jump friendly pawn');
s=E.apply(s,found(s,'e2','e4'));
assert.ok(found(s,'a8','a5'),'tetris rook can jump three over pawn');
assert.equal(found(s,'a8','a4'),undefined,'tetris rook cannot jump four');
assert.ok(found(s,'e7','e6'),'tetris pawn 8-neighbor');
assert.ok(E.attacked(s,E.idx('e6'),-1),'tetris pawn can attack adjacent king/piece');
let x=tetris(true);
assert.ok(found(x,'a1','a4'),'tetris white rook three');
assert.equal(found(x,'a1','a5'),undefined);
assert.equal(found(x,'e2','e4'),undefined,'tetris pawn cannot advance two');
// Classic en passant with hostile tetris pawn still occupies a legal capture square.
s=clear(E.initial('classic','tetris'));s.b[E.idx('e5')]='P';s.b[E.idx('d7')]='p';s.t=-1;
// A custom pawn does NOT have a double move; en passant cannot be fabricated.
assert.equal(found(s,'d7','d5'),undefined);
s=clear(E.initial('classic','classic'));s.b[E.idx('e5')]='P';s.b[E.idx('d7')]='p';s.t=-1;
s=E.apply(s,found(s,'d7','d5'));assert.equal(s.ep,E.idx('d6'));
assert.ok(found(s,'e5','d6'),'classic en passant');
s=E.apply(s,found(s,'e5','d6'));assert.equal(s.b[E.idx('d5')],'.');assert.equal(s.b[E.idx('d6')],'P');
// Castling and attacked transit squares.
s=clear(E.initial('classic','tetris'));s.b[E.idx('h1')]='R';s.c=1;
assert.ok(found(s,'e1','g1'),'classic castle valid on clear path');
s.b[E.idx('f3')]='r';s.b[E.idx('e8')]='k';assert.equal(found(s,'e1','g1'),undefined,'castle across check rejected');
// Promotion requires choice and leaves correct piece.
s=clear(E.initial('classic','tetris'));s.b[E.idx('a7')]='P';s.b[E.idx('e8')]='k';
const promotion=E.legal(s).filter(m=>m[0]===E.idx('a7')&&m[1]===E.idx('a8'));
assert.equal(promotion.length,4);assert.equal(E.apply(s,promotion[0]).b[E.idx('a8')],promotion[0][2].toUpperCase());
// Tetris rook attack is blocked by nothing in front of it; long-distance attacks forbidden.
s=clear(tetris(true));s.b[E.idx('d4')]='R';s.b[E.idx('d5')]='P';
assert.ok(E.attacked(s,E.idx('d7'),1),'tetris rook jumps an intervening piece');
assert.equal(E.attacked(s,E.idx('d8'),1),false);
// Only tetris faction can win line; first 3 home ranks excluded for horizontal.
s=clear(tetris(true));s.b[E.idx('e8')]='k';
for(let c=0;c<8;c++)s.b[E.idx('abcdefgh'[c]+'2')]='P';
assert.equal(E.lineWin(s,1),null,'home rank 2 excluded');
for(let c=0;c<8;c++)s.b[E.idx('abcdefgh'[c]+'4')]='P';
assert.deepEqual(E.lineWin(s,1),{kind:'row',index:4});
s=clear(tetris(true));for(let r=1;r<=8;r++)s.b[E.idx('a'+r)]='R';
assert.deepEqual(E.lineWin(s,1),{kind:'column',index:0});
s=clear(E.initial('classic','classic'));for(let c=0;c<8;c++)s.b[E.idx('abcdefgh'[c]+'4')]='P';assert.equal(E.lineWin(s,1),null,'orthodox faction has no line victory');
// Standard black side can deliver orthodox king threat without relying on tetris moves.
s=clear(E.initial('tetris','classic'));s.b[E.idx('h4')]='q';s.b[E.idx('e1')]='K';
assert.ok(E.attacked(s,E.idx('e1'),-1),'classic queen diagonal attacks king');
// Both variants must preserve kings and never allow direct king capture.
for(let k=0;k<100;k++){
 let st=E.initial(k%2?'classic':'tetris');
 for(let n=0;n<70;n++){
  const l=E.legal(st);if(!l.length)break;
  const m=l[(n*47+k*13)%l.length];st=E.apply(st,m);
  assert.equal(st.b.filter(x=>x==='K').length,1);assert.equal(st.b.filter(x=>x==='k').length,1);
  assert.equal(E.inCheck(st,-st.t),false,'mover cannot remain in check');
  if(E.outcome(st,[]).done)break;
 }
}
console.log('PASS Stage 6 engine: orthodox perft 20/400/8902, en passant, castling, promotion, tetris movement/jump/line, 100 mixed games');
