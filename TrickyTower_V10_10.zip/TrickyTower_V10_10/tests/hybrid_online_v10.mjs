import assert from 'node:assert/strict';
import {spawn} from 'node:child_process';
import {setTimeout as pause} from 'node:timers/promises';
import {createRequire} from 'node:module';
const require=createRequire(import.meta.url);const E=require('../hybrid_engine.js');
const port=17879;const server=spawn(process.execPath,['server.js'],{cwd:new URL('..',import.meta.url).pathname,env:{...process.env,PORT:String(port)},stdio:['ignore','pipe','pipe']});
let serverOutput='';server.stdout.on('data',c=>serverOutput+=c.toString());server.stderr.on('data',c=>serverOutput+=c.toString());
const clients=[];
async function connect(){const w=new WebSocket('ws://127.0.0.1:'+port+'/hybrid-ws');const q=[];let wake=[];
 w.addEventListener('message',ev=>{const m=JSON.parse(String(ev.data));q.push(m);for(const f of [...wake])f();});
 await new Promise((ok,no)=>{w.addEventListener('open',ok,{once:true});w.addEventListener('error',no,{once:true});});
 const obj={w,q,wait(type,pred=()=>true){return new Promise((ok,no)=>{let done=false;const timer=setTimeout(()=>{if(done)return;done=true;wake=wake.filter(x=>x!==check);no(new Error('timeout '+type+' / recent '+JSON.stringify(q.map(x=>x.type)).slice(-180)));},5000);
 const check=()=>{if(done)return;const i=q.findIndex(x=>x.type===type&&pred(x));if(i<0)return;const m=q.splice(i,1)[0];done=true;clearTimeout(timer);wake=wake.filter(x=>x!==check);ok(m);};wake.push(check);check();});},send(m){w.send(JSON.stringify(m));}};
 clients.push(obj);return obj;}
async function boot(){for(let k=0;k<45;k++){try{const r=await fetch('http://127.0.0.1:'+port+'/health');if(r.ok)return;}catch{}await pause(100);}throw new Error('server not running '+serverOutput);}
async function main(){await boot();
 const home=await fetch(`http://127.0.0.1:${port}/hybrid.html?mode=test`);assert.equal(home.status,200);assert.match(await home.text(),/기본 체스/);
 const code=await fetch(`http://127.0.0.1:${port}/hybrid_engine.js`);assert.equal(code.status,200);
 for(const whiteFaction of ['classic','tetris']){
  const host=await connect(),guest=await connect();await host.wait('hybrid_rooms');await guest.wait('hybrid_rooms');
  host.send({type:'hybrid_create',faction:whiteFaction,name:'V10 테스트',nickname:'주인'});
  const hJoin=await host.wait('hybrid_joined'),hWait=await host.wait('hybrid_state',m=>m.status==='waiting');assert.equal(hJoin.side,1);assert.equal(hWait.whiteFaction,whiteFaction);
  guest.send({type:'hybrid_list'});const list=await guest.wait('hybrid_rooms',m=>m.rooms.some(x=>x.id===hJoin.roomId));
  assert.equal(list.rooms.find(x=>x.id===hJoin.roomId).availableFaction,whiteFaction==='classic'?'tetris':'classic');
  // Cannot join a full team: selecting same team must be rejected without reserving a seat.
  guest.send({type:'hybrid_join',roomId:hJoin.roomId,faction:whiteFaction});assert.match((await guest.wait('hybrid_error')).message,/선택/);
  const other=whiteFaction==='classic'?'tetris':'classic';
  guest.send({type:'hybrid_join',roomId:hJoin.roomId,faction:other,nickname:'친구'});
  const gJoin=await guest.wait('hybrid_joined');const hs=await host.wait('hybrid_state',m=>m.status==='playing'),gs=await guest.wait('hybrid_state',m=>m.status==='playing');
  assert.equal(gJoin.side,-1);assert.equal(hs.turn,1);assert.equal(gs.turn,1);assert.equal(gs.whiteFaction,whiteFaction);
  guest.send({type:'hybrid_move',move:'e7e6',seq:0});assert.match((await guest.wait('hybrid_error')).message,/상대/);
  const whiteMove=whiteFaction==='classic'?'e2e4':'a1a4';host.send({type:'hybrid_move',move:whiteMove,seq:0});
  const hAfter=await host.wait('hybrid_state',m=>m.seq===1),gAfter=await guest.wait('hybrid_state',m=>m.seq===1);assert.equal(hAfter.turn,-1);assert.equal(gAfter.turn,-1);
  const blackMove=other==='classic'?'e7e5':'a8a5';guest.send({type:'hybrid_move',move:blackMove,seq:1});
  const h2=await host.wait('hybrid_state',m=>m.seq===2),g2=await guest.wait('hybrid_state',m=>m.seq===2);assert.equal(h2.turn,1);assert.equal(g2.turn,1);
  // Duplicate/outdated moves must be rejected without desync.
  host.send({type:'hybrid_move',move:'e2e4',seq:0});assert.match((await host.wait('hybrid_error')).message,/변경/);
  await host.wait('hybrid_state',m=>m.seq===2);
  // Reconnection must restore the same side, game, and move sequence.
  guest.w.close();await host.wait('hybrid_state',m=>m.players.some(p=>p.side===-1&&!p.connected));
  const resume=await connect();await resume.wait('hybrid_rooms');resume.send({type:'hybrid_resume',token:gJoin.token});
  const rejoin=await resume.wait('hybrid_joined');assert.equal(rejoin.side,-1);
  const resumed=await resume.wait('hybrid_state',m=>m.seq===2);assert.equal(resumed.turn,1);
  host.send({type:'hybrid_resign'});await host.wait('hybrid_state',m=>m.status==='ended');await resume.wait('hybrid_state',m=>m.status==='ended');
  host.send({type:'hybrid_rematch'});resume.send({type:'hybrid_rematch'});
  await host.wait('hybrid_state',m=>m.status==='playing'&&m.seq===0&&m.game===2);await resume.wait('hybrid_state',m=>m.status==='playing'&&m.seq===0&&m.game===2);
  host.send({type:'hybrid_leave'});await host.wait('hybrid_left');await resume.wait('hybrid_state',m=>m.status==='ended');
  console.log('PASS online 2P: whiteFaction='+whiteFaction+', both turns, illegal move, reconnection, resign/rematch');
  for(const obj of [host,resume])obj.w.close();
 }
 const health=await(await fetch(`http://127.0.0.1:${port}/health`)).json();assert.equal(health.version,'10.10.0');
 console.log('PASS Stage6 server routes /hybrid.html /hybrid_engine.js and health');
}
try{await main();}finally{for(const c of clients){try{c.w.close()}catch{}}server.kill('SIGTERM');await pause(300);}
