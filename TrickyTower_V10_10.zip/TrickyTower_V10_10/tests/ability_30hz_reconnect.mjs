import assert from 'node:assert/strict';
import {spawn} from 'node:child_process';
import {setTimeout as pause} from 'node:timers/promises';
import {resolve, dirname} from 'node:path';
import {fileURLToPath} from 'node:url';
const PORT=18921, base=`http://127.0.0.1:${PORT}`;
const dir=resolve(dirname(fileURLToPath(import.meta.url)), '..');
const srv=spawn(process.execPath,['server.js'],{cwd:dir,env:{...process.env,PORT:String(PORT)},stdio:['ignore','pipe','pipe']});
let logs='';srv.stdout.on('data',x=>logs+=x);srv.stderr.on('data',x=>logs+=x);
const post=async(url,obj)=>{const resp=await fetch(base+url,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(obj)});assert.equal(resp.status,200);return resp.json()};
async function socket(room,seat){const ws=new WebSocket(`ws://127.0.0.1:${PORT}/ability-ws?room=${room}&seat=${seat}`),items=[];
 ws.addEventListener('message',e=>{try{items.push(JSON.parse(e.data))}catch{}});
 await new Promise((ok,fail)=>{ws.addEventListener('open',ok,{once:true});ws.addEventListener('error',fail,{once:true})});
 return {ws,items,send:m=>ws.send(JSON.stringify(m)),wait:async(pred,limit=4000)=>{let start=Date.now();while(Date.now()-start<limit){let i=items.findIndex(pred);if(i>=0)return items.splice(i,1)[0];await pause(10)}throw Error('wait timeout '+JSON.stringify(items.slice(-5)))}};
}
try{
 for(let i=0;i<50;i++){try{if((await fetch(base+'/health')).ok)break}catch{}await pause(60)}
 const room=await post('/api/ability/create',{max:2,name:'30Hz check'});
 const a=await socket(room.roomId,room.seatToken);const hostId=`chaos-chess-2p-${room.roomId}`;
 a.send({type:'peer_register',peerId:hostId});await a.wait(m=>m.type==='peer_registered');
 const guest=await post('/api/ability/join',{roomId:room.roomId});const b=await socket(guest.roomId,guest.seatToken);
 b.send({type:'peer_register',peerId:'guest-health-test-01'});await b.wait(m=>m.type==='peer_registered');
 const begin=Date.now();await pause(1700);
 const ticks=a.items.filter(m=>m.type==='net_tick').length;
 assert(ticks>=40&&ticks<=65,`Expected ~30Hz for 1.7sec but got ${ticks} ticks`);
 a.send({type:'net_probe',clientAt:Date.now()});const pong=await a.wait(m=>m.type==='net_probe_reply');assert(Math.abs(Date.now()-pong.serverAt)<1200);
 b.send({type:'peer_dial',channel:'test-link-1',to:hostId});await a.wait(m=>m.type==='peer_incoming');await b.wait(m=>m.type==='peer_channel_ready');await a.wait(m=>m.type==='peer_channel_ready');
 const payload={messageType:'stateSnapshot',board:'X'.repeat(390000)};
 for(let i=0;i<5;i++)a.send({type:'peer_data',channel:'test-link-1',data:payload});
 const delivered=await b.wait(m=>m.type==='peer_channel_data',5000);assert.equal(delivered.data.board.length,390000);
 assert.equal(a.ws.readyState,WebSocket.OPEN);assert.equal(b.ws.readyState,WebSocket.OPEN);
 // Reconnect the host with the SAME seat before the old socket finishes.
 const a2=await socket(room.roomId,room.seatToken);
 a2.send({type:'peer_register',peerId:hostId});await a2.wait(m=>m.type==='peer_registered');
 assert.equal(a2.ws.readyState,WebSocket.OPEN,'server rejected same-seat reauthentication');
 await a2.wait(m=>m.type==='net_tick');
 a.ws.close();b.ws.close();a2.ws.close();
 console.log(`PASS Ability Chess measured ${ticks/1.7|0}Hz transport ticks; probe; 390KB state relay; same-seat reconnect; socket stays alive.`);
}catch(e){console.error('FAIL',e,'\nSERVER',logs);process.exitCode=1}
finally{srv.kill('SIGTERM');await pause(80)}
