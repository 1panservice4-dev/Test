import asyncio
from pathlib import Path
from playwright.async_api import async_playwright
P=Path('/mnt/data/Tricky_Tower_DUEL_V8_4Stages')
async def main():
 async with async_playwright() as pw:
  b=await pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
  for f in ['index.html','ability_lobby.html','ability_chess.html']:
   page=await b.new_page(viewport={'width':1280,'height':880})
   errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
   s=(P/f).read_text()
   if f=='ability_chess.html':s=s.replace('<script src="/ability_transport.js"></script>', '<script>window.Peer=function(){}</script>')
   await page.set_content(s,wait_until='load',timeout=30000)
   await page.wait_for_timeout(500)
   print(f,'errors',errors[:5], 'title',await page.title())
   if f=='index.html':print('cards',await page.locator('.stage-chooser-card').count());await page.screenshot(path='/mnt/data/V8_Four_Stage_Lobby.png')
   if f=='ability_lobby.html':await page.screenshot(path='/mnt/data/V8_Public_Ability_Lobby.png')
   if f=='ability_chess.html':
    print('chess board',await page.locator('.square').count(), 'four board',await page.locator('#fourPlayerApp').count())
    await page.screenshot(path='/mnt/data/V8_Ability_Chess_Game.png')
   await page.close()
  await b.close()
asyncio.run(main())
