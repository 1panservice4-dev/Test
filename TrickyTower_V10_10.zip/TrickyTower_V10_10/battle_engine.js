'use strict';
/* Stage 5: authoritative 10x20 grid-only Tetris Battle simulation.
   This module has no dependence on, or effect upon, the physics in stages 1/2. */
const W=10,H=20, MAX_HP=1000, MAX_HP_3=2000;
const COLORS=['R','B','Y','G'];
const SPECIALS=['heal','sand','damage','bomb','double','grey'];
const SHAPES={
 I:[[0,1],[1,1],[2,1],[3,1]], O:[[1,0],[2,0],[1,1],[2,1]],
 T:[[1,0],[0,1],[1,1],[2,1]], J:[[0,0],[0,1],[1,1],[2,1]],
 L:[[2,0],[0,1],[1,1],[2,1]], S:[[1,0],[2,0],[0,1],[1,1]],
 Z:[[0,0],[1,0],[1,1],[2,1]]
};
const TYPES=Object.keys(SHAPES);
const blank=()=>Array.from({length:H},()=>Array(W).fill(null));
const randInt=(rng,n)=>Math.min(n-1,Math.max(0,Math.floor(rng()*n)));
const clone=o=>JSON.parse(JSON.stringify(o));
function probability(elapsedSeconds){
 if(elapsedSeconds>=130)return 1;
 if(elapsedSeconds>=105)return .70;
 if(elapsedSeconds>=75)return .45;
 if(elapsedSeconds>=45)return .25;
 if(elapsedSeconds>=30)return .15;
 return .07;
}
function rotatedTiles(tiles,rotation){
 let result=tiles.map(t=>({...t}));
 for(let z=0;z<((rotation%4+4)%4);z++)result=result.map(t=>({...t,x:-t.y,y:t.x}));
 const minX=Math.min(...result.map(t=>t.x)),minY=Math.min(...result.map(t=>t.y));
 return result.map(t=>({...t,x:t.x-minX,y:t.y-minY}));
}
function makePiece(g,kind){
 const color=COLORS[randInt(g.rng,COLORS.length)];
 const special=g.rng()<probability(Math.max(0,(g.clock-g.startAt)/1000))
  ?SPECIALS[randInt(g.rng,SPECIALS.length)]:null;
 // One falling tetromino has one uniform color and at most one special type.
 // All four cells share its identity so a clear can trigger it only once.
 const pieceId=++g.pieceSerial;
 const tiles=SHAPES[kind].map(([x,y])=>({x,y,c:color,s:special,id:pieceId}));
 return {kind,tiles,x:3,y:-2,rotation:0,id:pieceId};
}
const kindFor=g=>TYPES[randInt(g.rng,TYPES.length)];
function makePlayer(g){return {grid:blank(),active:null,next:kindFor(g),hold:null,holdUsed:false,hp:g.maxHp,eliminated:false,ap:[0,0,0,0],lines:0,topouts:0,events:[],falls:0,gravityAcc:0,seq:0};}
function newGame(startAt=Date.now()+3200,rng=Math.random,playerCount=2){
 if(![2,3].includes(playerCount))throw Error('Stage 5 supports exactly 2 or 3 players');
 const g={rng,pieceSerial:0,startAt,clock:startAt,prevAt:startAt,state:'countdown',paused:false,pausedAt:0,winner:null,reason:'',turn:0,maxPlayers:playerCount,maxHp:playerCount===3?MAX_HP_3:MAX_HP,players:[]};
 g.players=Array.from({length:playerCount},()=>makePlayer(g));return g;
}
// Attacks in three-player mode target BOTH living opponents. Eliminated players
// remain seated as spectators, but cannot be hit or send new attacks.
function opponents(g,who){return g.players.map((p,i)=>i).filter(i=>i!==who&&g.players[i].hp>0)}
function tilesFor(p,piece=p.active,x=piece?.x,y=piece?.y,r=piece?.rotation){
 if(!piece)return [];
 return rotatedTiles(piece.tiles,r).map(t=>({...t,x:t.x+x,y:t.y+y}));
}
function canPlace(p,piece,x=piece.x,y=piece.y,rotation=piece.rotation){
 return tilesFor(p,piece,x,y,rotation).every(t=>t.x>=0&&t.x<W&&t.y<H&&(t.y<0||!p.grid[t.y][t.x]));
}
function alert(g,text,meta={}){g.turn++;const event={id:g.turn,text,...meta};for(const p of g.players){p.events.push(event);if(p.events.length>40)p.events.shift()}return event}
function finish(g,winner,reason){if(g.state==='finished')return;g.state='finished';g.winner=winner;g.reason=reason;alert(g,reason);}
function hurt(g,target,dmg,reason){
 if(g.state==='finished'||!g.players[target]||g.players[target].hp<=0)return false;
 const p=g.players[target],before=p.hp;
 p.hp=Math.max(0,p.hp-dmg);
 alert(g,`${target+1}P ${reason}: -${before-p.hp} HP`,{kind:'hit',target,amount:before-p.hp});
 if(p.hp===0){
  p.eliminated=true;p.active=null;p.gravityAcc=0;
  alert(g,`${target+1}P 탈락`,{kind:'eliminated',target});
  const remaining=opponents(g,-1);
  if(remaining.length<=1)finish(g,remaining.length?remaining[0]:null,remaining.length?`${remaining[0]+1}P 최종 승리!`:'무승부');
 }
 return true;
}
function gain(g,who,tiles,multiplier=1,source={}){
 const p=g.players[who],counts=[0,0,0,0];
 for(const tile of tiles){if(!tile)continue;const i=COLORS.indexOf(tile.c);if(i>=0){counts[i]+=multiplier;p.ap[i]+=multiplier}}
 if(counts.some(Boolean))alert(g,`${who+1}P ${source.kind==='bomb'?'폭발':'줄 제거'} 어택포인트 획득`,{kind:'ap_gain',owner:who,counts,source:source.kind||'line',x:source.x??4.5,y:source.y??10});
 for(let i=0;i<4;i++)while(p.ap[i]>=10&&g.state!=='finished'){
  p.ap[i]-=10;
  for(const target of opponents(g,who)){
   if(g.state==='finished')break;
   alert(g,`${who+1}P ${COLORS[i]} 공격 → ${target+1}P`,{kind:'attack',owner:who,target,color:COLORS[i],amount:100});
   hurt(g,target,100,`${COLORS[i]} 공격`);
  }
 }
}
// Gray Zone: server-authoritative garbage is colorless, never scores AP, and
// always has exactly one gap. Each completed row containing at least one Gray
// Zone tile sends exactly one garbage row, even if several Gray Zone pieces
// contributed to that same completed row. Existing settled tiles rise 1 cell.
function addGarbage(g,who,origin={}){
 if(g.state==='finished'||!g.players[who]||g.players[who].hp<=0)return false;
 let sent=0;
 for(const target of opponents(g,who)){
  if(g.state==='finished')break;
  const p=g.players[target],gap=randInt(g.rng,W),overflow=p.grid[0].some(Boolean);
  if(overflow){
   p.topouts++;p.grid=blank();p.active=null;p.gravityAcc=0;
   hurt(g,target,500,'회색 지대 천장 초과');
   if(g.state==='finished')continue;
   if(p.hp>0)spawn(g,target);
  }
  if(p.hp<=0)continue;
  p.grid.shift();
  p.grid.push(Array.from({length:W},(_,x)=>x===gap?null:{c:'X',s:null,id:null}));
  if(p.active){
   let attempts=0;
   while(!canPlace(p,p.active,p.active.x,p.active.y,p.active.rotation)&&attempts++<=H+4)p.active.y--;
  }
  alert(g,`${who+1}P 회색 지대! ${target+1}P 바닥에 방해 줄 +1`,
   {kind:'garbage',owner:who,target,gap,rows:1,x:origin.x??4.5,y:origin.y??19});
  sent++;
 }
 return sent>0;
}
function removeLines(g,who,rows,reason){
 const p=g.players[who],unique=[...new Set(rows)].filter(y=>Number.isInteger(y)&&y>=0&&y<H).sort((a,b)=>a-b);
 if(!unique.length)return 0;
 // Take a snapshot before gravity/compaction so a bomb detonates at the correct
 // place on the original board and no tile can award AP twice.
 const selected=new Set(unique);
 // A grey garbage row must CLEAR without generating ANY outgoing attack.
 // Even the coloured tile used to plug its one-cell gap is worth zero AP.
 const lineVisuals=unique.map(y=>{
  const neutral=p.grid[y].some(t=>t?.c==='X');
  return {y,neutral,counts:neutral?[0,0,0,0]:COLORS.map(c=>p.grid[y].filter(t=>t?.c===c).length),
   double:!neutral&&p.grid[y].some(t=>t?.s==='double'),grey:!neutral&&p.grid[y].every(Boolean)&&p.grid[y].some(t=>t?.s==='grey')};
 });
 const seenSpecial=new Set(),specials=[];
 for(const y of unique)for(let x=0;x<W;x++){
  const c=p.grid[y][x];if(!c?.s||c.s==='sand')continue;
  // Offensive specials in a colourless garbage line cannot attack either.
  if(lineVisuals.find(v=>v.y===y)?.neutral&&c.s!=='heal')continue;
  const key=c.id==null?`legacy:${y}:${x}`:`piece:${c.id}`;
  if(seenSpecial.has(key))continue;
  seenSpecial.add(key);specials.push({key,id:c.id,type:c.s,x,y});
 }
 // The double effect is per cleared row, not per special cell or per piece.
 // A bomb may destroy extra tiles outside the cleared rows; those give normal AP.
 const extras=[];
 for(const b of specials.filter(s=>s.type==='bomb')){
  let removed=0;
  for(let y=Math.max(0,b.y-1);y<=Math.min(H-1,b.y+1);y++)
   for(let x=Math.max(0,b.x-1);x<=Math.min(W-1,b.x+1);x++){
    if(selected.has(y))continue; // already counted among full/sand-erased rows
    const tile=p.grid[y][x];if(tile){extras.push(tile);p.grid[y][x]=null;removed++}
   }
  alert(g,`${who+1}P 폭탄 3×3 (${removed}칸 추가 제거)`,{kind:'bomb',owner:who,x:b.x,y:b.y,removed});
 }
 for(const visual of lineVisuals){
  const y=visual.y,line=p.grid[y].filter(Boolean);
  alert(g,`${who+1}P ${reason} 줄 제거`,{kind:'line_clear',owner:who,y,counts:visual.counts,double:visual.double,reason});
  if(visual.double)alert(g,`${who+1}P 더블 ×2 발동`,{kind:'double',owner:who,y});
  if(!visual.neutral)gain(g,who,line,visual.double?2:1,{kind:'line',y,x:4.5});
 }
 if(extras.length&&g.state!=='finished')gain(g,who,extras,1,{kind:'bomb',x:specials.find(s=>s.type==='bomb')?.x??4.5,y:specials.find(s=>s.type==='bomb')?.y??10});
 for(const sp of specials){
  if(sp.type==='heal'){
   if(g.state!=='finished'){
    const before=p.hp;p.hp=Math.min(g.maxHp,p.hp+75);
    alert(g,`${who+1}P 치유 +${p.hp-before} HP`,{kind:'heal',owner:who,amount:p.hp-before,x:sp.x,y:sp.y});
   }
  }else if(sp.type==='damage'){
   if(g.state!=='finished')for(const target of opponents(g,who)){
    if(g.state==='finished')break;
    alert(g,`${who+1}P 피해 블록 → ${target+1}P`,{kind:'damage',owner:who,target,amount:50,x:sp.x,y:sp.y});
    hurt(g,target,50,'줄 제거 피해 블록');
   }
  }
 }
 // Most special tetrominoes activate at most once per piece. Gray Zone is
 // deliberately different: each completed ROW awards one garbage row, even
 // when its tiles came from a piece that triggered on a previous clear.
 // Never strip the gray effect from surviving cells of that piece.
 const consumed=new Set(specials.filter(x=>x.id!=null&&x.type!=='grey').map(x=>x.id));
 if(consumed.size)for(const row of p.grid)for(const c of row)
  if(c&&consumed.has(c.id))c.s=null;
 p.grid=[...Array.from({length:unique.length},()=>Array(W).fill(null)),...p.grid.filter((_,i)=>!selected.has(i))];
 p.lines+=unique.length;alert(g,`${who+1}P ${reason} ${unique.length}줄 제거`);
 // One full row containing Gray Zone => exactly one garbage row.
 // Several Gray Zone tiles on the SAME full row do not stack. Different
 // completed rows each send one, even if the same tetromino crosses both.
 // Bomb-only destruction never triggers Gray Zone (not a completed row).
 if(g.state!=='finished')for(const row of lineVisuals){
  if(row.grey&&g.state!=='finished')addGarbage(g,who,{x:4.5,y:row.y});
 }
 return unique.length;
}
function checkRows(g,who){
 const p=g.players[who];const full=[];
 for(let y=0;y<H;y++)if(p.grid[y].every(Boolean))full.push(y);
 return removeLines(g,who,full,'완성');
}
function spawn(g,who){
 const p=g.players[who];if(g.state==='finished'||p.hp<=0)return;
 const kind=p.next;p.next=kindFor(g);p.active=makePiece(g,kind);p.holdUsed=false;p.gravityAcc=0;
 // A new tetromino may spawn partly above the ceiling; top-out is judged at lock.
}
function lock(g,who){
 const p=g.players[who];if(!p.active||g.state==='finished')return;
 const placed=tilesFor(p),overflow=placed.some(t=>t.y<0);
 p.falls++;
 if(overflow){
  p.active=null;p.grid=blank();p.gravityAcc=0;p.topouts++;
  hurt(g,who,500,'천장 초과');
  if(g.state!=='finished')spawn(g,who);
  return;
 }
 const id=p.active.id??++g.pieceSerial;
 for(const t of placed)p.grid[t.y][t.x]={c:t.c,s:t.s,id};
 // Sand is the only special that activates on landing. It removes the rows
 // touched by this one sand tetromino immediately, even if they are incomplete.
 if(placed.some(t=>t.s==='sand')){
  const touched=placed.map(t=>t.y);
  alert(g,`${who+1}P 모래 블록 즉시 발동`,{kind:'sand',owner:who,rows:[...new Set(touched)],x:placed[0]?.x??4,y:placed[0]?.y??10});
  removeLines(g,who,touched,'모래');
 }
 if(g.state!=='finished')checkRows(g,who);
 p.active=null;
 if(g.state!=='finished')spawn(g,who);
}
function stepDown(g,who){const p=g.players[who];if(!p.active)return false;
 if(canPlace(p,p.active,p.active.x,p.active.y+1,p.active.rotation)){p.active.y++;return true}
 lock(g,who);return false;
}
function input(g,who,action){
 if(g.state!=='playing'||g.paused||g.winner!==null||!Number.isInteger(who)||who<0||who>=g.players.length||g.players[who].hp<=0)return false;
 const p=g.players[who];if(!p.active)return false;
 if(action==='left'||action==='right'){
  const dx=action==='left'?-1:1;
  if(!canPlace(p,p.active,p.active.x+dx,p.active.y,p.active.rotation))return false;
  p.active.x+=dx;return true;
 }
 if(action==='rotate'){
  if(p.active.kind==='O')return true;
  const r=(p.active.rotation+1)%4;
  for(const [dx,dy] of [[0,0],[-1,0],[1,0],[-2,0],[2,0],[0,-1],[-1,-1],[1,-1]]){
   if(canPlace(p,p.active,p.active.x+dx,p.active.y+dy,r)){
    p.active.rotation=r;p.active.x+=dx;p.active.y+=dy;return true;
   }
  }
  return false;
 }
 if(action==='down'){stepDown(g,who);p.gravityAcc=0;return true}
 if(action==='drop'){
  while(p.active&&canPlace(p,p.active,p.active.x,p.active.y+1,p.active.rotation))p.active.y++;
  lock(g,who);return true;
 }
 if(action==='hold'){
  if(p.holdUsed)return false;
  const old=p.active.kind;p.active=null;
  if(p.hold){const swap=p.hold;p.hold=old;p.active=makePiece(g,swap)}
  else{p.hold=old;spawn(g,who)}
  p.holdUsed=true;p.gravityAcc=0;return true;
 }
 return false;
}
function tick(g,at=Date.now()){
 if(g.state==='finished')return;
 if(g.paused){g.prevAt=at;return}
 g.clock=at;
 if(g.state==='countdown'){
  if(at<g.startAt)return;
  g.state='playing';g.prevAt=g.startAt;for(let i=0;i<g.players.length;i++)spawn(g,i);alert(g,'BATTLE START');
 }
 if(g.state!=='playing')return;
 const dt=Math.max(0,Math.min(200,at-g.prevAt));g.prevAt=at;
 const seconds=Math.max(0,(at-g.startAt)/1000);
 const interval=Math.max(320,760-Math.floor(seconds/25)*37);
 for(let i=0;i<g.players.length;i++){
  const p=g.players[i];if(p.hp<=0)continue;p.gravityAcc+=dt;
  let attempts=0;
  while(p.gravityAcc>=interval&&attempts++<4&&g.state==='playing'){
   p.gravityAcc-=interval;stepDown(g,i);
  }
 }
}
function setPaused(g,paused,at=Date.now()){
 if(paused&&!g.paused){g.paused=true;g.pausedAt=at}
 else if(!paused&&g.paused){const duration=Math.max(0,at-g.pausedAt);g.startAt+=duration;g.prevAt=at;g.clock=at;g.paused=false;g.pausedAt=0}
}
function serialPlayer(p){return {rows:p.grid.map(row=>row.map(c=>c?c.c+(c.s?({heal:'h',sand:'s',damage:'d',bomb:'b',double:'x',grey:'z'}[c.s]):''):'').join(',')),
 active:p.active?{kind:p.active.kind,tiles:tilesFor(p).map(t=>[t.x,t.y,t.c,t.s||''])}:null,
 next:p.next,hold:p.hold,hp:p.hp,eliminated:p.hp<=0,ap:[...p.ap],lines:p.lines,topouts:p.topouts,falls:p.falls,events:p.events.slice(-32),seq:p.seq};}
// Stage 5 60Hz transport: lightweight authoritative live state. Full grid/event
// snapshots are sent separately on a board change, start, reconnect or heartbeat.
function liveSnapshot(g,at=Date.now()){
 const seconds=Math.max(0,(g.paused?g.pausedAt:at)-g.startAt)/1000;
 return {state:g.state,paused:g.paused,seconds,probability:probability(seconds),winner:g.winner,reason:g.reason,maxHp:g.maxHp,maxPlayers:g.maxPlayers,
  players:g.players.map(p=>({active:p.active?{kind:p.active.kind,tiles:tilesFor(p).map(t=>[t.x,t.y,t.c,t.s||''])}:null,
   next:p.next,hold:p.hold,hp:p.hp,eliminated:p.hp<=0,ap:p.ap,lines:p.lines,topouts:p.topouts,falls:p.falls,seq:p.seq}))};
}
function snapshot(g,at=Date.now()){
 const seconds=Math.max(0,(g.paused?g.pausedAt:at)-g.startAt)/1000;
 return {state:g.state,paused:g.paused,seconds,probability:probability(seconds),winner:g.winner,reason:g.reason,maxHp:g.maxHp,maxPlayers:g.maxPlayers,players:g.players.map(serialPlayer)};
}
module.exports={W,H,MAX_HP,MAX_HP_3,COLORS,SPECIALS,SHAPES,probability,rotatedTiles,newGame,makePiece,tilesFor,canPlace,input,tick,spawn,lock,checkRows,removeLines,addGarbage,gain,hurt,setPaused,snapshot,liveSnapshot,blank};
