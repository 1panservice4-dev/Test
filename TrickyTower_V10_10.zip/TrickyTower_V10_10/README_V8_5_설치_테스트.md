# Tricky Tower DUEL V8.5 사용 안내

1. 기존 서버 CMD 창에서 `Ctrl+C`를 눌러 종료합니다.
2. V8.5 ZIP을 V8.4와 **다른 새 폴더**에 압축 해제합니다.
3. 그 폴더의 `start_windows.bat`을 실행해 `TRICKY TOWER ONLINE V8.5` 메시지가 표시되는지 확인합니다.
4. Chrome에서 `http://localhost:8787`을 열고 Ctrl+Shift+R로 강력 새로고침합니다.
5. 다른 PC도 기존 게임 탭을 닫고 서버 IP(`http://서버PC-IP:8787`) 또는 최신 Pinggy 주소로 새로 접속합니다.
6. 새로운 4스테이지 공개방을 만든 뒤 2인/4인 게임을 다시 시작합니다.

## 네트워크 상태 표시
- `FPS`: 브라우저 실제 렌더링 속도. 60FPS는 목표이지 고정된 실측 보증값이 아닙니다.
- `SYNC Hz`: 서버와의 가벼운 연결 상태 갱신, 기본 30Hz 목표. 체스판 전체를 초당 30번 전송하지 않습니다.
- `RTT`: 클라이언트에서 서버까지 왕복 지연 시간. 상대방까지의 총 입력 전달 지연과 다를 수 있습니다.

## 문제가 반복된다면
- **두 컴퓨터 모두 새 V8.5 페이지**인지 확인하고 새 방을 만드세요.
- Pinggy 무료 터널은 시간 제한이 있으며 종료되면 외부 연결이 끊깁니다. 이 제한은 게임 내부 수정으로 없앨 수 없습니다.
- 지연이 심하면 한 번에 여러 개의 게임 탭·서버 프로세스를 실행하지 마세요.
- 오류 재현 시 F12 → Console의 오류와 FPS/Hz/RTT를 함께 기록하면 원인 분석에 도움이 됩니다.

## 자체 자동 테스트(Node.js 22 권장)
프로젝트 폴더에서 다음 명령어를 실행할 수 있습니다:
`node tests/smoke.mjs`
`node tests/ability_30hz_reconnect.mjs`
`node tests/chess_rules.mjs`
`node tests/chess_online.mjs`

브라우저 테스트는 Python Playwright + websockets와 Chromium을 사용하는 개발 환경에서 수행했습니다. 실제 사용자 PC 전체 환경에 대한 인증은 아닙니다.
