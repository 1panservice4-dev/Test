'use strict';
/* Stage 4 room directory + PeerJS-compatible WebSocket transport.  Dedicated
   namespace: it does not modify stages 1-3, their WebSocket protocol, or chess-tetris. */
const crypto=require('node:crypto');
const {URL}=require('node:url');
module.exports=function abilityPublic({send}){
 const rooms=new Map(), roomLimit=120, maxPacket=1_800_000;
 const NET_TICK_MS=1000/30; let netTickSequence=0; // gameplay snapshots remain event-driven

 const rid=()=>{const chars='ABCDEFGHJKLMNPQRSTUVWXYZ23456789';let s;do{s=Array.from(crypto.randomBytes(6),b=>chars[b%chars.length]).join('')}while(rooms.has(s));return s};
 const token=()=>crypto.randomBytes(24).toString('base64url');
 const name=s=>String(s||'능력자 체스 공개방').trim().replace(/[<>\x00-\x1f]/g,'').slice(0,30)||'능력자 체스 공개방';
 const list=()=>[...rooms.values()].filter(r=>r.seats.size<r.max&&r.hostConnected&&Date.now()-r.created<3*3600000).map(r=>({id:r.id,name:r.name,mode:r.mode,max:r.max,count:r.seats.size,connected:[...r.seats.values()].filter(s=>s.sockets.size>0).length,variant:r.variant,created:r.created})).sort((a,b)=>b.created-a.created);
 const respond=(res,status,json)=>{res.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff','Access-Control-Allow-Origin':'same-origin'});res.end(JSON.stringify(json))};
 async function http(req,res){
  const url=new URL(req.url,'http://localhost');
  if(url.pathname==='/api/ability/rooms'&&req.method==='GET'){respond(res,200,{rooms:list()});return true}
  if(url.pathname==='/api/ability/create'||url.pathname==='/api/ability/join'){
   if(req.method!=='POST'){respond(res,405,{error:'POST 요청만 가능합니다.'});return true}
   let data='';try{for await(const part of req){data+=part;if(data.length>10000)throw Error('요청 크기 초과')}}catch{respond(res,413,{error:'요청 크기가 너무 큽니다.'});return true}
   let m={};try{m=JSON.parse(data)}catch{respond(res,400,{error:'잘못된 요청입니다.'});return true}
   if(url.pathname.endsWith('/create')){
    if(rooms.size>=roomLimit){respond(res,503,{error:'공개방이 가득 찼습니다.'});return true}
    const max=Number(m.max)===4?4:2, seat=token();
    const variant=max===4?(['brawl','points','teams'].includes(m.variant)?m.variant:'brawl'):'standard';
    const r={id:rid(),name:name(m.name),max,mode:max===4?'ability4':'ability2',variant,abilities:m.abilities!==false,clock:Number.isInteger(m.clock)&&m.clock>=0&&m.clock<=3600?m.clock:0,created:Date.now(),hostConnected:false,owner:seat,hostAbsentAt:Date.now(),seats:new Map(),peers:new Map(),channels:new Map()};
    r.seats.set(seat,{token:seat,role:'host',sockets:new Set()});rooms.set(r.id,r);
    respond(res,200,{roomId:r.id,seatToken:seat,mode:r.mode,role:'host',variant:r.variant,abilities:r.abilities,clock:r.clock});return true;
   }
   const r=rooms.get(String(m.roomId||''));
   if(!r||r.seats.size>=r.max||Date.now()-r.created>3*3600000){respond(res,409,{error:'공개방이 없거나 인원이 가득 찼습니다.'});return true}
   const seat=token();r.seats.set(seat,{token:seat,role:'guest',sockets:new Set()});
   respond(res,200,{roomId:r.id,seatToken:seat,mode:r.mode,role:'guest',variant:r.variant,abilities:r.abilities,clock:r.clock});return true;
  }
  return false;
 }
 function connected(p,requestUrl){
  const u=new URL(requestUrl,'http://localhost');const r=rooms.get(u.searchParams.get('room'));
  const seat=r?.seats.get(u.searchParams.get('seat'));
  if(!r||!seat){send(p,{type:'peer_error',errorType:'authentication',message:'방 참가 권한이 없습니다. 공개방 목록에서 다시 참가하세요.'});p.socket.end();return}
  if(seat.sockets.size>=12){send(p,{type:'peer_error',errorType:'network',message:'동일 플레이어의 연결이 너무 많습니다.'});p.socket.end();return}
  p.abilityRoom=r;p.abilitySeat=seat;p.abilityPeerId=null;seat.sockets.add(p);p.isAbility=true;
  send(p,{type:'ability_ready',mode:r.mode,role:seat.role});
 }
 function closeChannel(r,channel,who){
  if(!r.channels.has(channel.id))return;
  r.channels.delete(channel.id);
  for(const peer of [channel.a,channel.b])if(peer!==who&&!peer.closed)send(peer,{type:'peer_channel_closed',channel:channel.id});
 }
 function disconnected(p){
  const r=p.abilityRoom,seat=p.abilitySeat;if(!r||!seat)return;
  seat.sockets.delete(p);
  if(p.abilityPeerId&&r.peers.get(p.abilityPeerId)===p)r.peers.delete(p.abilityPeerId);
  for(const channel of [...r.channels.values()])if(channel.a===p||channel.b===p)closeChannel(r,channel,p);
  if(seat.token===r.owner&&!seat.sockets.size){r.hostConnected=false;r.hostAbsentAt=Date.now()}
 }
 function message(p,m){
  const r=p.abilityRoom;if(!r||!p.abilitySeat||!m||typeof m!=='object')return;
  if(m.type==='peer_register'){
   const peerId=String(m.peerId||'');if(!/^[a-zA-Z0-9_-]{5,100}$/.test(peerId)){send(p,{type:'peer_error',errorType:'invalid-id'});return}
   let hostId=r.mode==='ability4'?`chaos-chess-v20-37-four-${r.id}`:`chaos-chess-2p-${r.id}`;
   // Host identification comes from the known room suffix, irrespective of the original client prefix.
   const isHostName=peerId.endsWith('-'+r.id)&&!peerId.startsWith('guest-');
   if(isHostName&&p.abilitySeat.token!==r.owner){
    const oldOwner=r.seats.get(r.owner);
    const unavailable=[...r.peers.values()].some(peer=>peer.abilitySeat?.token===r.owner&&peer.abilityPeerId?.endsWith('-'+r.id));
    if(unavailable||!r.hostAbsentAt||Date.now()-r.hostAbsentAt<30000){send(p,{type:'peer_error',errorType:'unavailable-id'});return}
    if(oldOwner)oldOwner.role='guest';r.owner=p.abilitySeat.token;p.abilitySeat.role='host';
   }
   const previous=r.peers.get(peerId);
   // Rejoin using the same authenticated seat should replace a stale transport.
   // Never allow one seat to hijack a different player's identity.
   if(previous&&previous!==p&&!previous.closed){
     if(previous.abilitySeat?.token!==p.abilitySeat.token){
       send(p,{type:'peer_error',errorType:'unavailable-id'});return;
     }
     for(const channel of [...r.channels.values()])if(channel.a===previous||channel.b===previous)closeChannel(r,channel,previous);
     previous.abilityPeerId=null;
     try{previous.socket.end()}catch{}
   }
   if(p.abilityPeerId&&p.abilityPeerId!==peerId)r.peers.delete(p.abilityPeerId);
   p.abilityPeerId=peerId;r.peers.set(peerId,p);
   if(isHostName&&p.abilitySeat.token===r.owner){r.hostConnected=true;r.hostAbsentAt=0}
   send(p,{type:'peer_registered',peerId});return;
  }
  // Measurement and clock synchronization messages are independent of large match snapshots.
  // Reply only to this seat, never to other players.
  if(m.type==='net_probe'){
   const clientAt=Number(m.clientAt);
   if(Number.isFinite(clientAt))send(p,{type:'net_probe_reply',clientAt,serverAt:Date.now()});
   return;
  }
  if(!p.abilityPeerId)return;
  if(m.type==='peer_dial'){
   const target=r.peers.get(String(m.to||'')),cid=String(m.channel||'');
   if(!target||target.closed||!cid||cid.length>120||r.channels.has(cid)){
    send(p,{type:'peer_dial_error',channel:cid,errorType:'peer-unavailable'});return;
   }
   const metadata=m.metadata&&typeof m.metadata==='object'?m.metadata:{};
   const channel={id:cid,a:p,b:target};r.channels.set(cid,channel);
   send(target,{type:'peer_incoming',channel:cid,from:p.abilityPeerId,metadata});
   setTimeout(()=>{
    if(!r.channels.has(cid)||p.closed||target.closed)return;
    send(p,{type:'peer_channel_ready',channel:cid});send(target,{type:'peer_channel_ready',channel:cid});
   },15);return;
  }
  if(m.type==='peer_data'){
   const cid=String(m.channel||''),channel=r.channels.get(cid);
   if(!channel)return;
   const dest=channel.a===p?channel.b:channel.b===p?channel.a:null;
   if(dest&&!dest.closed)send(dest,{type:'peer_channel_data',channel:cid,data:m.data});return;
  }
  if(m.type==='peer_channel_close'){
   const channel=r.channels.get(String(m.channel||''));if(channel&&(channel.a===p||channel.b===p))closeChannel(r,channel,p);
  }
 }
 // 30Hz lightweight time/transport ticks. Do not resend entire 2P/4P chessboards
 // on each tick: chess is turn-based and a full snapshot is only needed on an action.
 const syncTick=setInterval(()=>{
   const at=Date.now(), seq=++netTickSequence;
   for(const r of rooms.values())for(const seat of r.seats.values())for(const p of seat.sockets){
     if(p.closed||!p.abilityPeerId||!p.socket.writable||p.socket.writableLength>262144)continue;
     send(p,{type:'net_tick',seq,serverAt:at});
   }
 },NET_TICK_MS);syncTick.unref();
 function shutdown(){for(const r of rooms.values())for(const p of r.peers.values())send(p,{type:'peer_error',errorType:'server-error',message:'서버 재시작 중'});}
 const cleanup=setInterval(()=>{
  const t=Date.now();for(const [id,r] of rooms){
   if(t-r.created>4*3600000||(!r.hostConnected&&t-r.created>180000&&![...r.seats.values()].some(x=>x.sockets.size))){rooms.delete(id);continue}
   // Abandoned seat reservations are cleared after the owner has been gone for 90 sec.
   for(const [key,seat] of r.seats)if(key!==r.owner&&!seat.sockets.size&&r.seats.size>1&&t-r.created>120000&&t>r.created+180000){/* retain seat to permit reconnect */}
  }
 },60000);cleanup.unref();
 return {http,connected,message,disconnected,shutdown,list};
};
