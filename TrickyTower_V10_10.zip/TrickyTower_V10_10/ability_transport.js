/* Tricky Tower public-room adapter: PeerJS-shaped API backed by the same
   Node WebSocket server. Never contacts a PeerJS signaling server. */
(()=>{'use strict';
 const uid=()=>typeof crypto.randomUUID==='function'?crypto.randomUUID():`id-${Date.now().toString(36)}-${Math.random().toString(36).slice(2)}-${Math.random().toString(36).slice(2)}`;
 const params=new URLSearchParams(location.search);
 const room=params.get('room')||'',seat=params.get('seat')||'',mode=params.get('mode')||'',role=params.get('role')||'';
 window.__PUBLIC_ABILITY_ROOM__=room;window.__PUBLIC_ABILITY_MODE__=mode;window.__PUBLIC_ABILITY_ROLE__=role;
 if(!room||!seat)return;
 class Emitter{
   constructor(){this.listeners=new Map()}
   on(name,fn){if(!this.listeners.has(name))this.listeners.set(name,new Set());this.listeners.get(name).add(fn);return this}
   off(name,fn){this.listeners.get(name)?.delete(fn);return this}
   removeListener(name,fn){return this.off(name,fn)}
   emit(name,...args){for(const fn of [...(this.listeners.get(name)||[])])try{fn(...args)}catch(err){console.error('[능력자 체스 이벤트]',name,err)}}
 }
 class DataLink extends Emitter{
  constructor(owner,peer,channel,metadata={}){super();this.owner=owner;this.peer=peer;this.connectionId=channel;this.id=channel;this.metadata=metadata;this.open=false;this._closed=false;
   const self=this;this.dataChannel=this._dc={get bufferedAmount(){return owner._socket?.bufferedAmount||0},get readyState(){return self.open?'open':self._closed?'closed':'connecting'}};}
  send(payload){if(!this.open||this._closed)return false;return this.owner._send({type:'peer_data',channel:this.id,data:payload})}
  close(){if(this._closed)return;this.owner._send({type:'peer_channel_close',channel:this.id});this._finish()}
  _finish(){if(this._closed)return;this._closed=true;this.open=false;this.owner._connections.delete(this.id);this.emit('close')}
 }
 class Peer extends Emitter{
  constructor(id,options){super();this.id=id||`guest-${uid()}`;this.open=false;this.disconnected=false;this.destroyed=false;this._socket=null;this._connections=new Map();this._retryTimer=null;this._retryCount=0;this._probeTimer=null;this._outTimer=null;this._urgent=new Map();this._states=new Map();this._queueMax=128;this._connect();}
  _connect(){if(this.destroyed||[WebSocket.OPEN,WebSocket.CONNECTING].includes(this._socket?.readyState))return;clearTimeout(this._retryTimer);this._retryTimer=null;const url=`${location.protocol==='https:'?'wss':'ws'}://${location.host}/ability-ws?room=${encodeURIComponent(room)}&seat=${encodeURIComponent(seat)}`;const ws=new WebSocket(url);this._socket=ws;
   ws.addEventListener('open',()=>{if(this.destroyed||this._socket!==ws)return;
     this._retryCount=0;this._urgent.clear();this._states.clear();this._send({type:'peer_register',peerId:this.id});
     clearInterval(this._outTimer);this._outTimer=setInterval(()=>this._flushOutgoing(),25);
     clearInterval(this._probeTimer);
     this._probeTimer=setInterval(()=>{if(this._socket===ws&&ws.readyState===WebSocket.OPEN)this._send({type:'net_probe',clientAt:Date.now()})},1500);
   });
   ws.addEventListener('message',e=>{let m;try{m=JSON.parse(e.data)}catch{return}if(this._socket!==ws||this.destroyed)return;this._handle(m)});
   ws.addEventListener('close',()=>{if(this._socket!==ws||this.destroyed)return;
    clearInterval(this._probeTimer);this._probeTimer=null;clearInterval(this._outTimer);this._outTimer=null;this._urgent.clear();this._states.clear();this.open=false;this.disconnected=true;
    for(const c of [...this._connections.values()])c._finish();this.emit('disconnected');
    if(!this.destroyed&&!this._retryTimer){const wait=Math.min(8000,500*(2**Math.min(this._retryCount++,4)));this._retryTimer=setTimeout(()=>{this._retryTimer=null;this._connect()},wait)}
   });
   ws.addEventListener('error',()=>{if(!this.destroyed)this.emit('error',{type:'network',message:'공개방 연결 오류'})});
  }
  // Stage 4: protect input commands and acknowledgements against large snapshot
  // bursts.  Defer at most the newest replaceable state while TCP is backed up.
  // A packet accepted here is eventually sent on the SAME live socket only.
  _kind(m){
    if(m.type!=='peer_data')return 'critical';
    const d=m.data||{},priority=String(d.priority||'').toLowerCase();
    if(priority==='critical'||d.requiresAck===true)return 'critical';
    if(priority==='ephemeral')return 'ephemeral';
    if(priority==='state'||['STATE_UPDATE','INTERACTION_STATE','LOBBY_STATE','stateSnapshot','interactionState','lobbyState','clockSync'].includes(d.messageType||d.type))return 'state';
    return 'critical';
  }
  _flushOutgoing(){
    const ws=this._socket;
    if(!ws||ws.readyState!==WebSocket.OPEN)return;
    try{
      let sent=0;
      for(const [key,m] of this._urgent){
        if(ws.bufferedAmount>=350000||sent++>=16)return;
        ws.send(JSON.stringify(m));this._urgent.delete(key);
      }
      for(const [key,m] of this._states){
        if(ws.bufferedAmount>=350000||sent++>=24)return;
        ws.send(JSON.stringify(m));this._states.delete(key);
      }
    }catch(e){console.warn('[ability] buffered send',e)}
  }
  _send(m){
    const ws=this._socket;
    if(ws?.readyState!==WebSocket.OPEN)return false;
    const kind=this._kind(m);
    this._flushOutgoing();
    // Do not enqueue idle cosmetic updates if the uplink is congested.
    if((ws.bufferedAmount>=350000||this._urgent.size>0||this._states.size>0)&&m.type==='peer_data'){
      if(kind==='ephemeral')return true;
      const data=m.data||{};
      if(kind==='state'){
        const key=String(m.channel)+':'+String(data.stateKey||data.messageType||data.type||'state');
        this._states.set(key,m);return true;
      }
      const key=String(m.channel)+':'+String(data.packetId||data.commandId||JSON.stringify(data).slice(0,128));
      if(this._urgent.has(key))return true;
      if(this._urgent.size>=this._queueMax)return false; // core retries instead of dropping
      this._urgent.set(key,m);return true;
    }
    try{ws.send(JSON.stringify(m));return true}catch(e){console.warn('send error',e);return false}
  }
  _handle(m){
   if(m.type==='net_tick'){window.__TT_NET_MONITOR__?.tick();return}
   if(m.type==='net_probe_reply'){window.__TT_NET_MONITOR__?.probe(m.clientAt);return}
   if(m.type==='peer_registered'){this.open=true;this.disconnected=false;this.emit('open',this.id);return}
   if(m.type==='peer_incoming'){
    if(this._connections.has(m.channel))return;
    const conn=new DataLink(this,m.from,m.channel,m.metadata||{});this._connections.set(conn.id,conn);this.emit('connection',conn);return;
   }
   if(m.type==='peer_channel_ready'){const c=this._connections.get(m.channel);if(c&&!c._closed){c.open=true;c.emit('open')}return}
   if(m.type==='peer_channel_data'){const c=this._connections.get(m.channel);if(c&&!c._closed)c.emit('data',m.data);return}
   if(m.type==='peer_channel_closed'){this._connections.get(m.channel)?._finish();return}
   if(m.type==='peer_dial_error'){const c=this._connections.get(m.channel);if(c){c.emit('error',{type:m.errorType||'peer-unavailable'});c._finish()}this.emit('error',{type:m.errorType||'peer-unavailable'});return}
   if(m.type==='peer_error'){this.emit('error',{type:m.errorType||'network',message:m.message||''});return}
  }
  connect(target,options={}){
    if(!this.open||this.destroyed)throw Error('서버 연결이 준비되지 않았습니다');
    const channel=uid(),conn=new DataLink(this,String(target),channel,options.metadata||{});this._connections.set(channel,conn);
    this._send({type:'peer_dial',channel,to:String(target),metadata:options.metadata||{}});return conn;
  }
  reconnect(){if(this.destroyed)return;
    if([WebSocket.OPEN,WebSocket.CONNECTING].includes(this._socket?.readyState))return;
    this.disconnected=false;this._connect()}

  disconnect(){if(this.destroyed)return;clearTimeout(this._retryTimer);this._retryTimer=null;clearInterval(this._probeTimer);this._probeTimer=null;clearInterval(this._outTimer);this._outTimer=null;this._urgent.clear();this._states.clear();this._socket?.close();this.disconnected=true;this.open=false;this.emit('disconnected')}
  destroy(){if(this.destroyed)return;clearTimeout(this._retryTimer);this._retryTimer=null;clearInterval(this._probeTimer);this._probeTimer=null;clearInterval(this._outTimer);this._outTimer=null;this._urgent.clear();this._states.clear();this.destroyed=true;this.open=false;for(const c of [...this._connections.values()])c._finish();try{this._socket?.close()}catch{}this.emit('close');this.listeners.clear()}
 }
 window.Peer=Peer;
 window.__ABILITY_WS_ADAPTER__={room,mode,role,transport:'same-origin WebSocket'};
})();
