from pathlib import Path
P=Path('/mnt/data/Tricky_Tower_DUEL_V8_4Stages')
server=(P/'server.js').read_text()
server=server.replace("const crypto = require('node:crypto');", "const crypto = require('node:crypto');\nconst abilityNet=require('./ability_public.js')({send:(p,m)=>send(p,m)});")
server=server.replace("const staticHtml = fs.readFileSync(path.join(__dirname,'index.html'));", "const staticHtml = fs.readFileSync(path.join(__dirname,'index.html'));\nconst abilityHtml=fs.readFileSync(path.join(__dirname,'ability_chess.html'));\nconst abilityLobby=fs.readFileSync(path.join(__dirname,'ability_lobby.html'));\nconst abilityTransport=fs.readFileSync(path.join(__dirname,'ability_transport.js'));")
server=server.replace("const server = http.createServer((req,res)=>{\n if(req.method !== 'GET')", "const server = http.createServer(async(req,res)=>{\n if(await abilityNet.http(req,res))return;\n if(req.method !== 'GET')")
server=server.replace("}else if(req.url==='/health'){", "}else if(req.url==='/ability_chess.html'){\n  res.writeHead(200,{'Content-Type':'text/html; charset=utf-8','Cache-Control':'no-store'});res.end(abilityHtml);\n }else if(req.url==='/ability_lobby.html'){\n  res.writeHead(200,{'Content-Type':'text/html; charset=utf-8','Cache-Control':'no-store'});res.end(abilityLobby);\n }else if(req.url==='/ability_transport.js'){\n  res.writeHead(200,{'Content-Type':'text/javascript; charset=utf-8','Cache-Control':'no-store'});res.end(abilityTransport);\n }else if(req.url==='/health'){")
server=server.replace("if(p.isChess)return chessNet.msg(p,m);", "if(p.isAbility)return abilityNet.message(p,m);\n if(p.isChess)return chessNet.msg(p,m);")
server=server.replace(" if(p.isChess&&p.chessRoom&&!shuttingDown)chessNet.disconnect(p);", " if(p.isAbility)abilityNet.disconnected(p);\n if(p.isChess&&p.chessRoom&&!shuttingDown)chessNet.disconnect(p);")
server=server.replace('p.buffer.length>MAX_MESSAGE*2', 'p.buffer.length>(p.isAbility?1800000:MAX_MESSAGE)*2')
server=server.replace('long>BigInt(MAX_MESSAGE)', 'long>BigInt(p.isAbility?1800000:MAX_MESSAGE)')
server=server.replace('if(len>MAX_MESSAGE)', 'if(len>(p.isAbility?1800000:MAX_MESSAGE))')
server=server.replace('if(++p.messagesInWindow>45)', 'if(++p.messagesInWindow>(p.isAbility?250:45))')
server=server.replace(" if(req.url!=='/'&&req.url!=='/ws'&&req.url!=='/chess-ws')return socket.destroy();", " const wsUrl=new URL(req.url,'http://localhost');\n if(!['/','/ws','/chess-ws','/ability-ws'].includes(wsUrl.pathname))return socket.destroy();")
server=server.replace("const p={isChess:req.url==='/chess-ws'", "const p={isAbility:wsUrl.pathname==='/ability-ws',isChess:wsUrl.pathname==='/chess-ws'")
server=server.replace("send(p,{type:'hello',id:p.id});if(p.isChess)chessNet.msg(p,{type:'chess_list'});else send(p,{type:'rooms',rooms:roomList()});", "if(p.isAbility)abilityNet.connected(p,req.url);else{send(p,{type:'hello',id:p.id});if(p.isChess)chessNet.msg(p,{type:'chess_list'});else send(p,{type:'rooms',rooms:roomList()})}")
server=server.replace("for(const p of peers){send(p,{type:'server_restarting'});", "abilityNet.shutdown();\n for(const p of peers){send(p,{type:'server_restarting'});")
server=server.replace("TRICKY TOWER ONLINE V7 ready", "TRICKY TOWER ONLINE V8 (4 stages) ready")
(P/'server.js').write_text(server)

original=Path('/mnt/data/능력자_체스_울트라_v20.40_동일코드_인증수정_완성본(1).html').read_text()
# Preserve the original ability/game engine and effects intact. Only inject the transport adapter and boot routing.
assert "MULTI.roomCode=randomRoomCode()" in original
original=original.replace('MULTI.roomCode=randomRoomCode(); MULTI.colors=', 'MULTI.roomCode=(window.__PUBLIC_ABILITY_ROOM__||randomRoomCode()); MULTI.colors=',1)
# Add auto-launch entry functions into the original two internal scripts without changing engine logic.
assert '\n    init();\n  </script>' in original
original=original.replace('\n    init();\n  </script>', '''\n    window.__ABILITY_AUTO_TWO__=async function(){
      try{document.getElementById('entryChoiceModal')?.classList.remove('show');document.getElementById('multiModal')?.classList.add('show');
        if(window.__PUBLIC_ABILITY_ROLE__==='host')await createOnlineRoom();
        else await joinOnlineRoom(window.__PUBLIC_ABILITY_ROOM__);
      }catch(error){console.error('[공개방 2인 자동 입장]',error);showToast('공개방 연결에 실패했습니다. 목록으로 돌아가 재시도하세요.');}
    };
    init();
  </script>''',1)
assert 'bind4();\nS=createState4' in original
original=original.replace('bind4();\nS=createState4', '''window.__ABILITY_AUTO_FOUR__=async function(){
  try{
    const opt=window.__PUBLIC_ABILITY_CONFIG__||{};
    NET4.pendingConfig={family:opt.variant==='teams'?'teams':'ffa',variant:opt.variant==='points'?'points':opt.variant==='teams'?'teams':'brawl',abilitiesEnabled:opt.abilities!==false,clockSeconds:Number(opt.clock)||0};
    if(window.__PUBLIC_ABILITY_ROLE__==='host')await startHostRoomCreationFour({room:window.__PUBLIC_ABILITY_ROOM__});
    else await joinFourRoom(window.__PUBLIC_ABILITY_ROOM__);
  }catch(error){console.error('[공개방 4인 자동 입장]',error);showToast4('공개방 연결에 실패했습니다. 목록으로 돌아가 재시도하세요.');}
};
bind4();
S=createState4''',1)
# disable original code-based lobby UI visually, preserve game engine and mode configuration.
css='''<style id="public-room-ui">
  .join-panel,#joinPanel,#fourJoinPanel,#showJoinBtn,#joinRoomBtn,#fourShowJoinBtn,#fourJoinRoomBtn,
  #createRoomBtn,#fourCreateRoomBtn,#copyRoomBtn,#copyWaitingCodeBtn,
  #fourRoomCode,#roomCodeText,#fourColorLobbyRoom,#waitingCode,#fourRoomInput,#roomInput,
  .waiting-code,.four-color-lobby-code,.room-code,#relayConfigDetails{display:none!important}
  .tt-return {position:fixed;top:6px;right:6px;z-index:800;padding:8px 13px;border:1px solid #8ecbff;border-radius:12px;color:#eaf6ff;background:#0c2244ed;text-decoration:none;font-size:13px;font-weight:800;box-shadow:0 8px 24px #0008}
  body{padding-top:56px!important}
</style>'''
original=original.replace('</head>',css+'</head>',1)
original=original.replace('<body>', '<body>\n<a class="tt-return" href="/ability_lobby.html">← 공개방 목록 / 4스테이지</a>',1)
# external adapter comes before first original JS script; no CDN PeerJS in multiplayer.
assert '<script>\n    /* v20.40' in original
original=original.replace('<script>\n    /* v20.40', '''<script>
 const q=new URLSearchParams(location.search);
 window.__PUBLIC_ABILITY_ROOM__=q.get('room')||'';
 window.__PUBLIC_ABILITY_ROLE__=q.get('role')||'';
 window.__PUBLIC_ABILITY_MODE__=q.get('mode')||'';
 window.__PUBLIC_ABILITY_CONFIG__={variant:q.get('variant')||'brawl',abilities:q.get('abilities')!=='off',clock:Number(q.get('clock')||0)};
</script>
<script src="/ability_transport.js"></script>
<script>
    /* v20.40''',1)
original=original.replace('</body>', '''<script>
  window.addEventListener('load',()=>{
    const mode=window.__PUBLIC_ABILITY_MODE__;
    if(mode==='ability2')setTimeout(()=>window.__ABILITY_AUTO_TWO__?.(),120);
    else if(mode==='ability4')setTimeout(()=>window.__ABILITY_AUTO_FOUR__?.(),120);
    else if(new URLSearchParams(location.search).get('local')==='4')setTimeout(()=>document.getElementById('entryFourBtn')?.click(),100);
    else setTimeout(()=>document.getElementById('entryChoiceModal')?.classList.remove('show'),150);
  });
</script>
</body>''',1)
(P/'ability_chess.html').write_text(original)
# Keep a portable copy of original with all engines and effects for offline local players; not modified.
(P/'Ability_Chess_Original_Local_v20.40.html').write_text(Path('/mnt/data/능력자_체스_울트라_v20.40_동일코드_인증수정_완성본(1).html').read_text())

index=(P/'index.html').read_text()
assert '🎮 스테이지 3개 모두 선택 가능' in index
index=index.replace('스테이지 3 · 체스 테트리스!', '스테이지 3 · 체스 테트리스, 스테이지 4 · 능력자 체스!')
index=index.replace('🎮 스테이지 3개 모두 선택 가능','🎮 4개 스테이지 모두 선택 가능')
needle='  <article class="stage-chooser-card chess-card"><span class="stage-chooser-num">STAGE 03</span>'
assert needle in index
start=index.index(needle);end=index.index('</article>',start)+len('</article>')
card='''\n  <article class="stage-chooser-card chess-card" style="background:linear-gradient(130deg,rgba(44,37,92,.94),rgba(14,48,63,.94));border-color:rgba(164,122,255,.55)">
    <span class="stage-chooser-num">STAGE 04 · NEW</span><div class="stage-chooser-icon">♛</div>
    <h3>능력자 체스 울트라</h3><p><strong>원본 v20.40</strong> · 능력 · 특수 효과 · 2인/4인 공개방 · 방 코드 입력 없음</p>
    <div class="stage-chooser-actions"><a class="stage-chooser-link" href="/ability_lobby.html" id="quickStage4">능력자 체스 입장 →</a></div>
  </article>'''
index=index[:end]+card+index[end:]
# additional accessible stage in internal single lobby
needle2='  <a href="/chess.html" id="lobbyChess"'
assert needle2 in index
start2=index.index(needle2);end2=index.index('</a>',start2)+len('</a>')
index=index[:end2]+'''\n  <a href="/ability_lobby.html" id="lobbyAbilityChess" class="mode-card" style="text-decoration:none;grid-column:1/-1;min-height:160px;border-color:#9072e9" aria-label="스테이지 4: 능력자 체스">
   <span style="font-size:33px">♛</span><h2>스테이지 4 · 능력자 체스 울트라</h2>
   <p>원본 v20.40의 모든 능력과 2인·4인 모드 · 비밀번호/방 코드 없이 공개방 선택</p>
  </a>'''+index[end2:]
(P/'index.html').write_text(index)
print('Original preserved:',len(original),'V8 index',len(index))
