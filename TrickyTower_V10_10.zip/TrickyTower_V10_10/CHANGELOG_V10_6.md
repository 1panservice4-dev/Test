# V10.6 / 스테이지 7 추가

- 기존 V10.5 게임 파일 1~6: 동일 (해시 비교 확인)
- 변경: `index.html` (7번째 카드), `server.js` (새 URL·WS 라우트), `package.json` (버전 및 검증 구성)
- 신규: `three_chess_engine.js`, `three_chess_net.js`, `three_chess.html`
- 신규 테스트: `three_chess_engine_v106.mjs`, `three_chess_online_v106.mjs`
- 기존 테스트의 고정된 `/health` 버전 기대값만 10.6.0으로 조정
- 60FPS 렌더링/60Hz 경량 동기화 목표, 체스판 전체는 수가 바뀔 때만 전달
- 3인용 체크메이트 탈락, 스테일메이트 3인 턴 건너뛰기/2인 무승부, 왕 잡기, 턴 순서, 캐슬링, 승격
