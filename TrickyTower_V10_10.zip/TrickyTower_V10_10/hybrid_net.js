'use strict';
/* Stage 6 ONLY, independent rooms and server-authoritative rules. */
const crypto=require('node:crypto');
const E=require('./hybrid_engine.js');
module.exports=function({send,peers}){
 const rooms=new Map(),tokens=new Map(),MAX_ROOMS=70,GRACE=30000;
 const rid=()=>crypto.randomBytes(5).toString('hex').toUpperCase();
 const clean=(s,d)=>String(s||d).replace(/[<>\x00-\x1f]/g,'').trim().slice(0,24)||d;
 const other=x=>x==='classic'?'tetris':'classic';
 const to=(p,m)=>{if(p&&!p.closed)send(p,m)};
 function listing(){return [...rooms.values()].filter(r=>r.status==='waiting'&&r.players.length===1).map(r=>({id:r.id,name:r.name,hostFaction:r.whiteFaction,availableFaction:other(r.whiteFaction),count:r.players.length}));}
 function listAll(){let data={type:'hybrid_rooms',rooms:listing()};for(const p of peers)if(p.isHybrid)to(p,data);}
 function state(r){const s=r.position;return {type:'hybrid_state',roomId:r.id,status:r.status,whiteFaction:r.whiteFaction,blackFaction:other(r.whiteFaction),board:s.b,turn:s.t,castling:s.c,ep:s.ep,half:s.half,full:s.full,seq:r.moves.length,moves:r.moves,ending:r.ending,game:r.game,players:r.players.map(p=>({id:p.id,nickname:p.hybridName,side:p.hybridSide,faction:E.faction(s,p.hybridSide),connected:!p.closed,rematch:!!p.hybridRematch})),claimable:s.half>=100||r.history.filter(x=>x===E.key(s)).length>=3};}
 function broadcast(r){const m=state(r);for(const p of r.players)to(p,m);}
 function finish(r,winner,reason,line=null){r.status='ended';r.ending={winner,reason,line};broadcast(r);listAll();}
 function detach(p,explicit=false){const r=p.hybridRoom;if(!r)return; if(p.hybridTimer){clearTimeout(p.hybridTimer);p.hybridTimer=null;}if(p.hybridToken)tokens.delete(p.hybridToken);p.hybridToken=null;p.hybridRoom=null;
  r.players=r.players.filter(x=>x!==p);
  if(r.players.length===0){rooms.delete(r.id);listAll();return;}
  if(r.status==='playing')finish(r,r.players[0].hybridSide,'opponent_left');
  else if(r.status==='waiting'){broadcast(r);listAll();}else broadcast(r);
 }
 function disconnected(p){if(!p.hybridRoom)return;const r=p.hybridRoom;if(p.hybridTimer)clearTimeout(p.hybridTimer);
  p.hybridTimer=setTimeout(()=>{p.hybridTimer=null;if(p.closed&&p.hybridRoom)detach(p);},GRACE);p.hybridTimer.unref?.();broadcast(r);
 }
 function joined(p,r,side){p.hybridRoom=r;p.hybridSide=side;p.hybridRematch=false;p.hybridToken=crypto.randomBytes(22).toString('base64url');tokens.set(p.hybridToken,p);
  to(p,{type:'hybrid_joined',roomId:r.id,side,token:p.hybridToken,whiteFaction:r.whiteFaction});}
 function message(p,m){if(!m||typeof m!=='object')return;const type=m.type;
  if(type==='hybrid_list'){to(p,{type:'hybrid_rooms',rooms:listing()});return;}
  if(type==='hybrid_resume'){
   const old=tokens.get(String(m.token||''));if(!old||!old.closed||!old.hybridRoom){to(p,{type:'hybrid_resume_failed'});return;}
   const r=old.hybridRoom;if(old.hybridTimer){clearTimeout(old.hybridTimer);old.hybridTimer=null;}
   p.id=old.id;p.hybridName=old.hybridName;p.hybridSide=old.hybridSide;p.hybridRoom=r;p.hybridToken=old.hybridToken;p.hybridRematch=old.hybridRematch;
   r.players=r.players.map(x=>x===old?p:x);old.hybridRoom=null;old.hybridToken=null;tokens.set(p.hybridToken,p);
   to(p,{type:'hybrid_joined',roomId:r.id,side:p.hybridSide,token:p.hybridToken,whiteFaction:r.whiteFaction});broadcast(r);return;
  }
  if(type==='hybrid_create'){
   if(p.hybridRoom)return;if(rooms.size>=MAX_ROOMS)return to(p,{type:'hybrid_error',message:'공개방이 가득 찼습니다.'});
   const f=m.faction==='tetris'?'tetris':'classic',r={id:rid(),name:clean(m.name,'체스 VS 테트리스 공개방'),whiteFaction:f,players:[p],status:'waiting',position:E.initial(f,other(f)),moves:[],history:[],ending:null,game:0};
   while(rooms.has(r.id))r.id=rid();p.hybridName=clean(m.nickname,'백 플레이어');rooms.set(r.id,r);joined(p,r,1);r.history=[E.key(r.position)];broadcast(r);listAll();return;
  }
  if(type==='hybrid_join'){
   if(p.hybridRoom)return;const r=rooms.get(String(m.roomId||''));
   if(!r||r.status!=='waiting'||r.players.length!==1)return to(p,{type:'hybrid_error',message:'참가할 수 없는 공개방입니다.'});
   const expected=other(r.whiteFaction);if(m.faction!==expected)return to(p,{type:'hybrid_error',message:`이 공개방은 ${expected==='classic'?'기본 체스':'테트리스 체스'} 진영을 선택해야 합니다.`});
   p.hybridName=clean(m.nickname,'흑 플레이어');joined(p,r,-1);r.players.push(p);r.status='playing';r.position=E.initial(r.whiteFaction,other(r.whiteFaction));r.history=[E.key(r.position)];r.moves=[];r.ending=null;r.game++;broadcast(r);listAll();return;
  }
  if(type==='hybrid_leave'){detach(p,true);to(p,{type:'hybrid_left'});return;}
  const r=p.hybridRoom;if(!r)return to(p,{type:'hybrid_error',message:'먼저 공개방에 들어가세요.'});
  if(type==='hybrid_move'){
   if(r.status!=='playing')return to(p,{type:'hybrid_error',message:'대전 중이 아닙니다.'});
   if(r.position.t!==p.hybridSide)return to(p,{type:'hybrid_error',message:'현재 상대 차례입니다.'});
   if(m.seq!==r.moves.length){to(p,{type:'hybrid_error',message:'화면 상태가 변경되어 수를 다시 확인하세요.'});broadcast(r);return;}
   const mv=E.parseMove(r.position,String(m.move||''));if(!mv)return to(p,{type:'hybrid_error',message:'현재 진영의 이동 규칙 또는 체크 방어 규칙에 맞지 않습니다.'});
   const label=E.notation(r.position,mv);r.position=E.apply(r.position,mv);r.moves.push({side:p.hybridSide,move:E.moveKey(mv),label});r.history.push(E.key(r.position));
   const out=E.outcome(r.position,r.history);if(out.done)finish(r,out.winner,out.reason,out.line);else broadcast(r);return;
  }
  if(type==='hybrid_resign'){if(r.status==='playing')finish(r,-p.hybridSide,'resign');return;}
  if(type==='hybrid_claim'){if(r.status!=='playing')return;
   const reps=r.history.filter(x=>x===E.key(r.position)).length;if(reps>=3)finish(r,0,'threefold');else if(r.position.half>=100)finish(r,0,'50move');else to(p,{type:'hybrid_error',message:'아직 무승부를 요청할 수 없습니다.'});return;
  }
  if(type==='hybrid_rematch'){if(r.status!=='ended')return;p.hybridRematch=true;
   if(r.players.length===2&&r.players.every(x=>x.hybridRematch&&!x.closed)){
    r.players.forEach(x=>x.hybridRematch=false);r.position=E.initial(r.whiteFaction,other(r.whiteFaction));r.moves=[];r.history=[E.key(r.position)];r.ending=null;r.status='playing';r.game++;
   }broadcast(r);return;
  }
 }
 return {message,disconnected,listAll};
};
