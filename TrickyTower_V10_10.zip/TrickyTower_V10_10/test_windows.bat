@echo off
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
 echo Node.js 22 or newer is required.
 pause
 exit /b 1
)
call npm test
if errorlevel 1 (
 echo [FAIL] See errors above.
 pause
 exit /b 1
)
echo [PASS] All built-in server regression tests completed.
pause
