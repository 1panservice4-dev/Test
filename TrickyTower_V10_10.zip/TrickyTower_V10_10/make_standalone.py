from pathlib import Path
import base64
P=Path('/mnt/data/Tricky_Tower_DUEL_V8_4Stages')
source=Path('/mnt/data/Tricky_Tower_DUEL_V7_2_Three_Stages_Standalone.html').read_text()
ability=Path('/mnt/data/능력자_체스_울트라_v20.40_동일코드_인증수정_완성본(1).html').read_bytes()
original_encoded=base64.b64encode(ability).decode('ascii')
source=source.replace('TRICKY TOWER DUEL V7.2 | 3개 스테이지 통합','TRICKY TOWER DUEL V8 | 4개 스테이지 통합')
source=source.replace('THREE STAGES · SINGLE & ONLINE','FOUR STAGES · SINGLE & ONLINE')
source=source.replace('스테이지 3 · 체스 테트리스!','스테이지 3 · 체스 테트리스, 스테이지 4 · 능력자 체스!')
source=source.replace('🎮 스테이지 3개 모두 선택 가능','🎮 4개 스테이지 모두 선택 가능')
source=source.replace('← 3개 스테이지로 돌아가기','← 4개 스테이지로 돌아가기')
# Add the fourth stage overlay, same pattern as existing chess-tetris overlay.
needle='<section class="portal screen" id="entryScreen"'
block='''<div id="abilityStandaloneOverlay" hidden style="position:fixed;inset:0;z-index:9999;background:#080e20;display:flex;flex-direction:column">
 <div style="flex:0 0 auto;display:flex;align-items:center;justify-content:space-between;gap:10px;padding:10px 16px;background:#172641;border-bottom:1px solid #4c6282;color:#fff;font-weight:800">
  <span>♛ STAGE 04 · 능력자 체스 울트라 2인/4인 로컬</span><button id="backFromAbility" type="button" style="border:1px solid #7d94b7;background:#304568;color:white;border-radius:11px;padding:10px 14px;font-weight:bold">← 4개 스테이지로 돌아가기</button>
 </div>
 <iframe id="localAbilityGameFrame" title="능력자 체스 원본 v20.40 로컬 2인/4인" style="flex:1;width:100%;border:0;background:#091325" loading="lazy"></iframe>
</div>
'''
assert needle in source;source=source.replace(needle,block+needle,1)
needle='<div class="stage-legacy-bar">'
start=source.index('<article class="stage-chooser-card chess-card">');end=source.index('</article>',start)+len('</article>')
card='''\n  <article class="stage-chooser-card chess-card" style="background:linear-gradient(125deg,#332454,#163850);border-color:#8668d7"><span class="stage-chooser-num">STAGE 04 · NEW</span><div class="stage-chooser-icon">♛</div><h3>능력자 체스 울트라</h3><p>원본 v20.40 · <strong>2인/4인</strong> 모드 · 모든 능력과 특수 효과 · 로컬 플레이</p><div class="stage-chooser-actions"><a class="stage-chooser-link" href="#ability" id="quickStage4">능력자 체스 입장 →</a></div></article>'''
source=source[:end]+card+source[end:]
needle=' </div>\n <div class="lobby-footer">PC 키보드'
a='''  <a href="#ability" id="lobbyAbilityChess" class="mode-card" style="text-decoration:none;grid-column:1/-1;min-height:155px;border-color:#9072e9" aria-label="스테이지 4: 능력자 체스">
   <div class="mode-head"><span class="mode-index">STAGE 04 · ABILITY CHESS ULTRA</span><span class="mode-icon">♛</span></div>
   <h2>능력자 체스 울트라</h2><p>원본 v20.40 · 모든 능력·이펙트 유지 · 로컬 2인/4인 전환 가능</p>
   <div class="mode-start">스테이지 선택 <span>➜</span></div>
  </a>
'''
assert needle in source;source=source.replace(needle,a+needle,1)
source=source.replace('#chessStandaloneOverlay[hidden]{display:none!important}', '#chessStandaloneOverlay[hidden],#abilityStandaloneOverlay[hidden]{display:none!important}\n@media(min-width:861px){.stage-chooser-grid{grid-template-columns:repeat(2,minmax(0,1fr))}}')
# Preserve the previous embedded chess-tetris and all stage 1/2 gameplay code.
more='''\n<script>
(()=>{
  const encoded=AB64;
  const frame=document.getElementById('localAbilityGameFrame');
  const overlay=document.getElementById('abilityStandaloneOverlay');
  let decoded=null;
  function open(e){if(e)e.preventDefault();if(!decoded){const bytes=Uint8Array.from(atob(encoded),c=>c.charCodeAt(0));decoded=new TextDecoder('utf-8').decode(bytes)}
    frame.srcdoc=decoded;overlay.hidden=false;document.body.style.overflow='hidden';}
  function close(){frame.removeAttribute('srcdoc');frame.src='about:blank';overlay.hidden=true;document.body.style.overflow='';}
  document.getElementById('quickStage4').addEventListener('click',open);
  document.getElementById('lobbyAbilityChess').addEventListener('click',open);
  document.getElementById('backFromAbility').addEventListener('click',close);
})();
</script>
'''.replace('AB64',repr(original_encoded))
assert '</body>' in source
source=source.replace('</body>',more+'</body>',1)
p=P/'Tricky_Tower_V8_4Stages_Local_Standalone.html';p.write_text(source)
print(p,p.stat().st_size,'preserved sources bytes',len(ability))
